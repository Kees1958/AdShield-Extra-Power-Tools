/*
 * mode-routes.js — Site-mode / filtering-mode message-route adapters
 *
 * Same three-layer split as matrix-routes.js / security-routes.js /
 * ruleset-routes.js (see matrix-routes.js's own header for the full
 * rationale):
 *   Layer 1 — message-routes.js:  POLICY
 *   Layer 2 — this file:          ADAPTER
 *   Layer 3 — mode-manager.js, site-mode-manager.js, scripting-manager.js
 *             — the actual logic
 *
 * Largest of the four route files split out of background.js so far (10
 * handlers) — this is the last piece of "target #2" (mode/security/
 * ruleset routes), after security-routes.js and ruleset-routes.js.
 *
 * refreshToolbarIconsForOpenTabs() moved here alongside its only caller
 * (handleSetFilteringModeDetails) rather than staying in background.js —
 * it had exactly one external call site, confirmed by grep before moving,
 * same verification standard as every other relocation in this series.
 *
 * Public interface — one function per MSG_* route this feature owns,
 * referenced by background.js's ROUTE_HANDLERS:
 *   handleSiteModeGet, handleSiteModeGetAll, handleSiteModeSet,
 *   handleSiteModeSetAll, handleGetFilteringMode, handleSetFilteringMode,
 *   handleGetFilteringModeDetails, handleSetFilteringModeDetails,
 *   handleGetDefaultFilteringMode, handleSetDefaultFilteringMode
 */

import { browser, localRead, localWrite } from '../data/ext.js';
import { broadcastMessage } from '../data/broadcast.js';

import {
    getDefaultFilteringMode,
    getFilteringMode,
    getFilteringModeDetails,
    setDefaultFilteringMode,
    setFilteringMode,
    setFilteringModeDetails,
} from '../core/mode-manager.js';

import {
    applySiteMode,
    getSiteMode,
    invalidateSiteModeCache,
    filteringLevelForMode,
    SITE_MODE_DEFAULT,
} from '../core/site-mode-manager.js';

import {
    registerContentScripts,
    registerSecurityContentScripts,
} from '../core/scripting-manager.js';

import { setToolbarIconForLevel } from '../core/action.js';

/******************************************************************************/

async function refreshToolbarIconsForOpenTabs() {
    const tabs = await browser.tabs.query({}).catch(reason => {
        console.error(`[uBlock-Dynamic] refreshToolbarIconsForOpenTabs/tabs.query/${reason}`);
        return [];
    });
    await Promise.all(tabs.map(async tab => {
        if ( typeof tab.id !== 'number' ) { return; }
        let hostname;
        try {
            hostname = new URL(tab.url).hostname;
        } catch {
            return;
        }
        if ( hostname === '' ) { return; }
        const level = await getFilteringMode(hostname);
        try {
            await setToolbarIconForLevel(tab.id, level);
        } catch(reason) {
            console.error(`[uBlock-Dynamic] refreshToolbarIconsForOpenTabs/setIcon/${reason}`);
        }
    }));
}

/******************************************************************************/
// 4-way site mode / allowlist
/******************************************************************************/

export async function handleSiteModeGet(request) {
    const mode = await getSiteMode(request.hostname);
    return { mode };
}

export async function handleSiteModeGetAll() {
    const all = await localRead('siteModes') ?? {};
    return all;
}

export async function handleSiteModeSet(request) {
    const { hostname, mode, tabId } = request;
    const result = await applySiteMode(hostname, mode, tabId, {
        setFilteringMode,
        registerContentScripts,
        registerSecurityContentScripts,
    });
    return result;
}

export async function handleSiteModeSetAll(request) {
    const { siteModes: newModes } = request;
    if ( newModes instanceof Object === false ) { return {}; }
    const oldModes = await localRead('siteModes') ?? {};
    await localWrite('siteModes', newModes);
    invalidateSiteModeCache();
    // BUG FIX: this used to only write storage. That left a domain
    // typed into the Allow list editor looking saved while filtering
    // stayed fully active for it — the single-site toggle path
    // (applySiteMode(), above) always calls setFilteringMode() to
    // write the actual DNR exemption rule; this bulk path never did.
    // Only touch hostnames whose mode actually changed, and re-register
    // content scripts once afterward rather than per-hostname.
    const changedHostnames = new Set(
        [ ...Object.keys(oldModes), ...Object.keys(newModes) ].filter(hostname =>
            (oldModes[hostname] ?? SITE_MODE_DEFAULT) !== (newModes[hostname] ?? SITE_MODE_DEFAULT)
        )
    );
    for ( const hostname of changedHostnames ) {
        const mode = newModes[hostname] ?? SITE_MODE_DEFAULT;
        await setFilteringMode(hostname, filteringLevelForMode(mode));
    }
    if ( changedHostnames.size > 0 ) {
        await Promise.all([
            registerContentScripts(),
            registerSecurityContentScripts(),
        ]);
    }
    // Same caveat applySiteMode() documents for the single-site path:
    // an already-open tab for a changed hostname needs a manual reload
    // to actually stop already-injected scriptlets or clear an
    // already-applied block count — this bulk path affects potentially
    // many hostnames at once, so it does not force-reload every
    // matching open tab automatically.
    return newModes;
}

/******************************************************************************/
// Filtering mode (levels)
/******************************************************************************/

export async function handleGetFilteringMode(request) {
    return getFilteringMode(request.hostname);
}

export async function handleSetFilteringMode(request) {
    const beforeLevel = await getFilteringMode(request.hostname);
    if ( request.level === beforeLevel ) { return beforeLevel; }
    const afterLevel = await setFilteringMode(request.hostname, request.level);
    await registerContentScripts();
    if ( typeof request.tabId === 'number' ) {
        setToolbarIconForLevel(request.tabId, afterLevel);
    }
    return afterLevel;
}

export async function handleGetFilteringModeDetails() {
    return getFilteringModeDetails(true);
}

export async function handleSetFilteringModeDetails(request) {
    await setFilteringModeDetails(request.modes);
    await registerContentScripts();
    const defaultFilteringMode = await getDefaultFilteringMode();
    broadcastMessage({ defaultFilteringMode });
    refreshToolbarIconsForOpenTabs();
    return getFilteringModeDetails(true);
}

export async function handleGetDefaultFilteringMode() {
    return getDefaultFilteringMode();
}

export async function handleSetDefaultFilteringMode(request) {
    const beforeLevel = await getDefaultFilteringMode();
    const afterLevel = await setDefaultFilteringMode(request.level);
    if ( afterLevel !== beforeLevel ) {
        await registerContentScripts();
    }
    return afterLevel;
}

/******************************************************************************/
