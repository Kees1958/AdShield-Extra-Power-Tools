/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * scripting-manager.js — Single owner of all browser.scripting registrations
 *
 * This is the only module that calls browser.scripting.registerContentScripts(),
 * updateContentScripts(), unregisterContentScripts(), or getRegisteredContentScripts().
 * All other modules that need content scripts registered must go through here.
 *
 * Six namespaced registration groups, each with its own prefix/id and lifecycle:
 *   ag-scriptlets-*      MAIN world     — pre-compiled per-ruleset AG scriptlet files
 *   ag-cosmetic-*        ISOLATED world — pre-compiled per-ruleset cosmetic CSS files
 *   sec-*                MAIN world     — security toggle scriptlets (inline code)
 *   ubol-cookie-clicker  ISOLATED world — user-created consent-click rules (ONE
 *                                        directive, not per-ruleset — see that
 *                                        section's own header below)
 *   ubol-autodeny        MAIN world     — "Never consent" generic auto-deny
 *                                        action bundle (v8.2), registered ONLY
 *                                        while a session is active (D11) — see
 *                                        that section's own header below
 *   css-user             ISOLATED world — one directive, user-picked/imported
 *                                        cosmetic CSS rules (js/scripting/css-user.js);
 *                                        built by filter-manager.js's
 *                                        registerCustomFilters(), diffed and
 *                                        applied by this module's own
 *                                        registerCustomFiltersDirective() (v9.4.9)
 *
 * Public interface:
 *   registerContentScripts()          — (re)registers custom filter + toolbar scripts;
 *                                       also re-diffs sec-, ag-scriptlets-,
 *                                       ag-cosmetic-, ubol-cookie-clicker,
 *                                       ubol-autodeny, and css-user groups —
 *                                       each independently, via its own
 *                                       existing-vs-wanted check (no shared
 *                                       wipe-and-rebuild; see v9.4.9 porting
 *                                       note at this function's own definition
 *                                       for why that changed)
 *   registerScriptletContentScripts() — registers/updates ag-scriptlets-* group
 *   registerCosmeticContentScripts()  — registers/updates ag-cosmetic-* group
 *   registerSecurityContentScripts()  — registers/updates sec-* group;
 *                                       called by background.js when a security toggle changes
 *   registerCookieClickerContentScripts() — registers/updates the
 *                                       ubol-cookie-clicker script;
 *                                       called by js/workflow/cookie-clicker-routes.js
 *                                       whenever a consent-click rule is
 *                                       added/deleted/cleared
 *   registerCookieClickerAutoDenyContentScripts() — registers/updates the
 *                                       ubol-autodeny script; called by
 *                                       js/core/cookie-clicker-autodeny-
 *                                       manager.js's startAutoDeny()/
 *                                       restoreNow() (init/release, D11)
 *   getRegisteredContentScripts()     — returns all registered script IDs
 *   pruneCSSCache()                   — trims session CSS cache
 *   getScriptingManagerLockState()    — debugging aid: snapshot of both
 *                                       locks' phase/heldSince (see below)
 *
 * Concurrency: every one of the four functions above that touches
 * browser.scripting shares one in-module mutex (withRegistrationLock(),
 * defined just below the imports) so their check-then-act sequences can
 * never interleave with each other or with the six-group re-diff batch
 * inside registerContentScripts(). See that constant's comment for the
 * specific race this fixes.
 *
 * ── STATE / GUARDS (uBol-stripped-code-review.md §1 retrofit) ───────────────
 *
 * This module owns no session with phases (unlike block-monitor.js) — every
 * exported function is a standalone, idempotent registration pass over
 * whatever browser.scripting/DNR state exists *right now*. What it does own
 * is concurrency control, via two independent lock instances (both created
 * from js/util/async-lock.js's createLock() — see that module for the
 * queueing/state-vector mechanism itself; deliberately not merged into one
 * lock — see each instance's own comment at its declaration for exactly
 * what it guards and why they're kept separate):
 *
 *   registrationLock (withRegistrationLock())
 *     General mutex around every browser.scripting.* call in this module —
 *     registerScriptletContentScripts(), registerCosmeticContentScripts(),
 *     registerSecurityContentScripts(), the six-group re-diff batch inside
 *     registerContentScripts.register() (v9.4.9: no longer a wipe-and-
 *     rebuild — see that function's own porting note), and the two generic
 *     registerContentScriptsSafely()/unregisterContentScriptsByIds()
 *     primitives used by privacy-inspector.js. Non-reentrant by design.
 *
 *   pendingOpLock (registerContentScripts.pendingOp)
 *     Narrower: serializes successive calls to registerContentScripts()
 *     itself (the exported entry point), so two full re-registration passes
 *     triggered back-to-back (e.g. two rapid permission changes) queue
 *     rather than race each other's browser.scripting.* calls.
 *
 * ── OBSERVABILITY ────────────────────────────────────────────────────────────
 * Each lock instance's phase/heldSince is inspectable via its own
 * getState() — see getScriptingManagerLockState() at the end of this file,
 * which exposes both. See js/util/async-lock.js for how that state vector
 * is maintained (try/finally around each queued call).
 *
 * ── WHY THIS FILE ISN'T SPLIT FURTHER (uBol-stripped-code-review.md §1) ──────
 * This file's sections are now clearly labeled (Content-script registration
 * mutex / Scriptlet / Cosmetic / Security / Session CSS cache / Main
 * orchestration / Introspection / Debugging), and the generic mutex has
 * already been extracted to js/util/async-lock.js. Splitting the three
 * registration kinds (scriptlet/cosmetic/security) into separate files was
 * considered and deliberately NOT done — assessed and rejected, not simply
 * unconsidered:
 *
 *   1. The shared registrationLock is the entire point of this file's
 *      concurrency model. If each split-out file created its own
 *      createLock() instance instead of importing one shared instance, the
 *      mutual-exclusion guarantee would silently break — each would queue
 *      independently, reintroducing the exact race this lock exists to
 *      prevent, with no error to catch it.
 *   2. registerContentScripts.register() calls the three *Impl functions
 *      directly, bypassing their lock-acquiring public wrappers, to avoid
 *      deadlocking on a lock it already holds. Splitting means each file
 *      would need to export both its guarded public function AND its raw,
 *      lock-bypassing internal — a much easier place to call the wrong one
 *      from the wrong context than when it's one comment in one file.
 *   3. SCRIPTLET_CS_PREFIX / COSMETIC_CS_PREFIX / SECURITY_CS_PREFIX /
 *      COOKIE_CLICKER_CS_ID cross-reference each other ("must not
 *      collide") — an invariant that's easy to see in one file, easy to
 *      silently violate across several.
 *   4. No test suite: a working, subtle, concurrency-critical file is
 *      exactly the wrong place to take on structural risk for a cosmetic
 *      (fewer-lines-per-file) benefit.
 *
 * Revisit if a genuinely new registration kind is added that does NOT need
 * to share registrationLock — that would be a natural, lower-risk seam.
 * ─────────────────────────────────────────────────────────────────────────────
 */


import {
    browser,
    sessionKeys, sessionRead, sessionRemove,
    localRead, localWrite, localRemove,
} from '../data/ext.js';

import { getFilteringModeDetails } from './mode-manager.js';
import { securityConfig } from '../data/config.js';
import { getEnabledRulesets } from './static-rulesets.js';
import { registerCustomFilters, CSS_USER_CS_ID } from './filter-manager.js';
import { prepareSecurityScriptletDirectives, buildSiteModeMatchScope } from './compiled-filters.js';
import { registerJob } from '../data/alarms.js';
import { registerToolbarIconToggler } from './action.js';
import { createLock } from '../util/async-lock.js';

/******************************************************************************/
// Content-script registration mutex
//
// Every function below that does a check-then-act sequence against
// browser.scripting (getRegisteredContentScripts() -> decide -> register /
// update / unregister) — plus the six-group re-diff batch in
// registerContentScripts.register() — must run through withRegistrationLock()
// so none of them can ever interleave. Chrome's scripting API has no atomic
// "diff and apply" primitive: without this, two such sequences running close
// together can race (one sees an id as "existing" and schedules an update,
// the other's unregister/rebuild removes that id first), producing errors
// like "Script with ID '…' does not exist or is not fully registered".
//
// Non-reentrant by design: registerContentScripts.register() already holds
// this lock for its whole six-group re-diff batch, so it calls the six
// *Impl-style functions directly — never their public, lock-acquiring
// wrappers — to avoid deadlocking on this same queue.
//
// The mutex mechanism itself (queueing + phase-tagged state vector) now
// lives in js/util/async-lock.js — see that file's header for why it moved
// out. withRegistrationLock() is kept as a thin delegating wrapper (rather
// than replacing every call site below with registrationLock.withLock(...))
// so this extraction touches nothing else in this file.
const registrationLock = createLock('scripting-manager/registrationLock');
function withRegistrationLock(fn) {
    return registrationLock.withLock(fn);
}

// Porting note (v9.5.1, item 2 — batch browser.scripting (un)registration
// instead of one call per directive): shared by the three registration
// functions below that each independently looped calling
// registerContentScripts([directive])/updateContentScripts([directive])
// once per ruleset — found in the identical shape three separate times
// in this file before being consolidated here.
//
// Splits `wanted` into updates-vs-new against the caller's own
// `existingMap`, then issues AT MOST ONE updateContentScripts() call and
// AT MOST ONE registerContentScripts() call for the whole batch, instead
// of one of each per directive. Both native calls are atomic across
// their own array argument — one bad directive rejects the WHOLE call,
// same documented atomicity as updateDynamicRules() elsewhere in this
// codebase — so on rejection, this falls back to one call per directive
// for JUST that batch, reproducing the exact original per-item behavior
// (and per-item error labels) as a safety net. Batching never trades
// away the "one bad ruleset can't block its siblings" guarantee the
// original per-item loop had.
//
// wanted: array of directives this call wants registered/updated.
// existingMap: Map<id, existingDirective> — the caller's own
// already-queried existing-registration snapshot (unchanged: this
// helper doesn't query browser.scripting itself, it only decides
// update-vs-register and issues the calls).
// options.updateErrorLabel / registerErrorLabel / postDuplicateUpdateLabel:
// console.error() labels, kept per-caller so a failure still reads as
// coming from "security" vs "cosmetic" vs the plain scriptlet path, same
// as when each site logged its own label inline.
// options.retryDuplicateAsUpdate: preserves a pre-existing defensive
// retry specific to the security-registration call site (a "duplicate
// script id" error on register is retried as an update) — a race guard
// against a registration left over from just before a version update
// that Chrome hasn't finished clearing yet. Only ever true for that one
// caller; false (the default) for the other two, which never had this
// retry to begin with.
async function registerOrUpdateContentScripts(wanted, existingMap, options = {}) {
    const {
        updateErrorLabel = '[uBlock-Dynamic] updateContentScripts:',
        registerErrorLabel = '[uBlock-Dynamic] registerContentScripts:',
        postDuplicateUpdateLabel = '[uBlock-Dynamic] registerContentScripts (post-duplicate update):',
        retryDuplicateAsUpdate = false,
    } = options;

    const toUpdate = [];
    const toRegisterNew = [];
    for ( const directive of wanted ) {
        (existingMap.has(directive.id) ? toUpdate : toRegisterNew).push(directive);
    }

    if ( toUpdate.length > 0 ) {
        try {
            await browser.scripting.updateContentScripts(toUpdate);
        } catch {
            // Whole-batch rejection: fall back to one call per directive
            // for JUST this batch — exact original per-item behavior.
            for ( const directive of toUpdate ) {
                await browser.scripting.updateContentScripts([ directive ]).catch(reason => {
                    console.error(updateErrorLabel, directive.id, reason);
                });
            }
        }
    }

    if ( toRegisterNew.length > 0 ) {
        try {
            await browser.scripting.registerContentScripts(toRegisterNew);
        } catch (reason) {
            const message = String(reason?.message ?? reason);
            if ( retryDuplicateAsUpdate && toRegisterNew.length === 1 && /duplicate script id/i.test(message) ) {
                // Preserves the exact original single-directive defensive
                // retry (security's own pre-existing race guard) for the
                // common case where the batch collapses to one directive.
                await browser.scripting.updateContentScripts(toRegisterNew).catch(updateReason => {
                    console.error(postDuplicateUpdateLabel, toRegisterNew[0].id, updateReason);
                });
                return;
            }
            for ( const directive of toRegisterNew ) {
                try {
                    await browser.scripting.registerContentScripts([ directive ]);
                } catch (itemReason) {
                    const itemMessage = String(itemReason?.message ?? itemReason);
                    if ( retryDuplicateAsUpdate && /duplicate script id/i.test(itemMessage) ) {
                        await browser.scripting.updateContentScripts([ directive ]).catch(updateReason => {
                            console.error(postDuplicateUpdateLabel, directive.id, updateReason);
                        });
                    } else {
                        console.error(registerErrorLabel, directive.id, itemReason);
                    }
                }
            }
        }
    }
}

/******************************************************************************/
// Scriptlet content script registration
// Pre-compiled per-ruleset scriptlet JS files are registered as static content
// scripts in the MAIN world — no userScripts API or "Allow User Scripts" needed.
/******************************************************************************/

// Prefix for scriptlet content script IDs so they can be selectively updated
const SCRIPTLET_CS_PREFIX = 'ag-scriptlets-';

// Porting note (v9.4.9, item 4): module-level cache for
// /rulesets/scriptlet-files.json — this file is static (only changes when
// a new extension version ships), so re-fetching and re-parsing it on
// every registerScriptletContentScriptsImpl() call (which, per item 1,
// can now happen often) was pure waste. Safe to lose on SW restart —
// cheap to reload once on the next call, same posture as any other
// "acceptable to lose, rebuilt on demand" in-memory cache in this file
// (see e.g. the CSS cache pruned by pruneCSSCache() below).
let scriptletFilesCache = null;

// How often the session CSS cache is pruned (see pruneCSSCache() below).
// Was previously the literal `15 * 60 * 1000` duplicated identically in two
// places in this file (uBol-stripped-code-review.md §2) — named once here
// so the two call sites can never drift out of sync with each other.
const CSS_CACHE_PRUNE_INTERVAL_MS = 15 * 60 * 1000;

// Rulesets whose scriptlet and cosmetic content scripts are always registered,
// regardless of the user's language filter selection.
//
// ── CRITICAL MAINTENANCE RULE ────────────────────────────────────────────────
// Any ruleset that should always be active MUST appear in ALL THREE places:
//   1. Here in ALWAYS_ON_RULESETS (so scriptlet + cosmetic scripts are registered)
//   2. manifest.json  rule_resources[]  with  "enabled": true
//   3. static-rulesets.js  STATIC_RULESET_IDS[]
//
// Omitting a ruleset from this set causes its scriptlet and cosmetic files to be
// silently skipped by registerScriptletContentScripts() and
// registerCosmeticContentScripts() — the rules load but never fire.
// This was the root cause of the cookies/annoyances filter silent-drop bug.
// ─────────────────────────────────────────────────────────────────────────────
const ALWAYS_ON_RULESETS = new Set([
    'ruleset_kees1958',
    // Add future always-on rulesets here (e.g. cookies, annoyances).
    // Each addition must also be reflected in manifest.json and static-rulesets.js.
]);

export async function registerScriptletContentScripts() {
    return withRegistrationLock(registerScriptletContentScriptsImpl);
}
async function registerScriptletContentScriptsImpl(precomputedScope) {
    // BUG FIXED: this previously always used matches: ['*://*/*'] with no
    // site-mode awareness at all — identical in kind to the cosmetic-
    // filter bug fixed just below, and to the one buildSiteModeMatchScope()
    // was originally introduced to fix for security scriptlets (see that
    // function's own comment in compiled-filters.js). Turning a site OFF
    // (or pausing filtering everywhere via temp-disable-manager.js) never
    // actually stopped AdGuard-style scriptlet filters from running on
    // that site — only DNR network blocking and the Security & Privacy
    // sec-* toggles were ever gated by filtering mode. Reusing the same
    // buildSiteModeMatchScope() the security scriptlets already rely on,
    // rather than a third, separately-maintained copy of this logic.
    //
    // Porting note (v9.4.9, item 3): precomputedScope, if provided by the
    // orchestrator (register(), below), is used instead of calling
    // buildSiteModeMatchScope() again — this function is ALSO called
    // independently (registerScriptletContentScripts(), its exported
    // wrapper, has many callers outside the orchestrator's batch — see
    // that helper's own comment for why a shared context object would be
    // wrong here), so those callers still compute it themselves exactly
    // as before (precomputedScope is undefined for them).
    const { matches: siteModeMatches, excludeMatches: siteModeExcludes } = precomputedScope ?? await buildSiteModeMatchScope();
    if ( siteModeMatches.length === 0 ) {
        // Reverse mode with no basic-mode exceptions at all: nowhere to
        // inject — same early-return prepareSecurityScriptletDirectives()
        // uses for the identical case.
        return browser.scripting.unregisterContentScripts({
            ids: (await browser.scripting.getRegisteredContentScripts())
                .filter(s => s.id.startsWith(SCRIPTLET_CS_PREFIX))
                .map(s => s.id),
        }).catch(() => {});
    }

    const enabledRulesets = await getEnabledRulesets();

    let scriptletFiles;
    if ( scriptletFilesCache !== null ) {
        scriptletFiles = scriptletFilesCache;
    } else {
        try {
            const resp = await fetch(browser.runtime.getURL('/rulesets/scriptlet-files.json'));
            scriptletFiles = await resp.json();
            scriptletFilesCache = scriptletFiles;
        } catch {
            return;
        }
    }

    const toRegister = [];

    for ( const { id, file } of scriptletFiles ) {
        if ( !ALWAYS_ON_RULESETS.has(id) && !enabledRulesets.has(id) ) { continue; }
        const directive = {
            id: `${SCRIPTLET_CS_PREFIX}${id}`,
            js: [ `/${file}` ],
            matches: siteModeMatches,
            world: 'MAIN',
            allFrames: true,
            runAt: 'document_start',
        };
        if ( siteModeExcludes.length > 0 ) {
            directive.excludeMatches = siteModeExcludes;
        }
        toRegister.push(directive);
    }

    let existing = [];
    try {
        existing = await browser.scripting.getRegisteredContentScripts({
            ids: scriptletFiles.map(f => `${SCRIPTLET_CS_PREFIX}${f.id}`),
        });
    } catch {
        existing = [];
    }

    const existingMap = new Map(existing.map(s => [s.id, s]));
    const wantedIds = new Set(toRegister.map(s => s.id));

    const toRemove = [...existingMap.keys()].filter(id => !wantedIds.has(id));
    if ( toRemove.length ) {
        await browser.scripting.unregisterContentScripts({ ids: toRemove }).catch(() => {});
    }

    // Porting note (v9.5.1, item 2): was a per-directive loop calling
    // updateContentScripts([directive])/registerContentScripts([directive])
    // once per ruleset — see registerOrUpdateContentScripts()'s own
    // comment above for the full accounting.
    await registerOrUpdateContentScripts(toRegister, existingMap, {
        updateErrorLabel: '[uBlock-Dynamic] updateContentScripts:',
        registerErrorLabel: '[uBlock-Dynamic] registerContentScripts:',
    });
}

/******************************************************************************/
// Cosmetic content script registration
//
// Storage-backed path, wired 7.7.9, made the SOLE path 7.7.10 (the old
// embedded-blob format and its runtime rollback flag were removed once
// informal real-world verification — repeated fresh loads on real sites
// with confirmed cosmetic rules, forbes.com/cnn.com, reviewed frame-by-
// frame via phone slow-motion camera, no flash observed — gave enough
// confidence to commit. This was NOT the originally-planned automated
// DevTools frame-capture test; see CHANGELOG.md's 7.7.9 AND 7.7.10
// entries for the full history and honest caveat on what "verified"
// means here. If cosmetic filters are ever found to visibly flash on
// screen before hiding, on any page, this is the first place to look —
// mitigation now means reverting to the 7.7.9 zip (which still has the
// rollback flag) rather than flipping a switch in this version.
//
// Per-ruleset registration loads FOUR small shared/tiny files instead of
// one large embedded-blob file:
//   css-api.js       — self.cssAPI.insert(), messages the background to
//                       call browser.scripting.insertCSS() (SAME file for
//                       every ruleset — shared, not duplicated per-ruleset)
//   isolated-api.js  — self.isolatedAPI (hostname-walk, binarySearch())
//                       (SAME file for every ruleset)
//   <id>-cosmetic-loader.js — ONE LINE, per-ruleset: sets
//                       self.specificImports=['<id>'] so the shared
//                       css-specific.js below knows which
//                       chrome.storage.local key is this registration's
//                       own data
//   css-specific.js  — reads chrome.storage.local['css.specific.<id>'],
//                       applies matching selectors (SAME file for every
//                       ruleset)
// Order matters: css-api.js/isolated-api.js populate self.cssAPI/
// self.isolatedAPI, the loader sets self.specificImports, THEN
// css-specific.js runs and consumes all three — see that file's own top
// of file for why.
//
// The old embedded-blob generator (buildCosmeticFile() in tools/build-
// rulesets.mjs) still exists and still runs on every build — but only to
// produce test-fixtures/legacy-cosmetic/, ground truth for tools/check-
// cosmetic-specific-format-equivalence.mjs (complete-check.mjs step 16).
// It is NOT shipped in the extension and NOT consulted by this function
// — see that generator's own comment for why it's kept at all.
/******************************************************************************/

const COSMETIC_CS_PREFIX = 'ag-cosmetic-';

// Porting note (v9.4.9, item 4): same treatment as scriptletFilesCache
// above, for /rulesets/cosmetic-files.json — see that variable's own
// comment.
let cosmeticFilesCache = null;

// Single source for the two files shared, unmodified, across every
// cosmetic-ruleset registration — declared once here rather than
// re-literaled at registerCosmeticContentScriptsImpl()'s directive-
// building call site, per this project's own "declare once" convention.
const COSMETIC_SPECIFIC_SHARED_JS = Object.freeze([
    '/js/scripting/css-api.js',
    '/js/scripting/isolated-api.js',
]);
const COSMETIC_SPECIFIC_READER_JS = '/js/scripting/css-specific.js';

// Storage-key namespace this function owns for the GUARD logic below
// (init / clear-and-release — see the two loops inside
// registerCosmeticContentScriptsImpl() that use these). Must exactly
// match css-specific.js's own hardcoded `css.specific.${rulesetId}` read
// — see that constant's twin in tools/build-rulesets.mjs's
// COSMETIC_SPECIFIC_CONFIG for the same value declared build-side, with
// the same "must match exactly" warning.
const COSMETIC_SPECIFIC_STORAGE_PREFIX = 'css.specific.';
const COSMETIC_SPECIFIC_VERSION_FIELD = 'v';
// Single local-storage key tracking which css.specific.* entries THIS
// function has ever written — lets the RELEASE guard below delete exactly
// the stale ones on a ruleset toggle/removal without a full
// chrome.storage.local scan (which would also touch unrelated keys, e.g.
// user custom-rule storage, that this function has no business reading).
const COSMETIC_SPECIFIC_REGISTRY_KEY = '__uBolCssSpecificRegistry';

export async function registerCosmeticContentScripts() {
    return withRegistrationLock(registerCosmeticContentScriptsImpl);
}
async function registerCosmeticContentScriptsImpl(precomputedScope) {
    // BUG FIXED: same class of bug as registerScriptletContentScriptsImpl()
    // just above — matches: ['*://*/*'] with no site-mode awareness meant
    // cosmetic (CSS-hiding) filters kept running on a site the user had
    // explicitly turned OFF, and kept running everywhere during a
    // temp-disable-manager.js pause. See that function's comment for the
    // full history; same fix, same shared buildSiteModeMatchScope().
    //
    // Porting note (v9.4.9, item 3): same precomputedScope treatment as
    // registerScriptletContentScriptsImpl() just above — see that
    // function's own comment.
    const { matches: siteModeMatches, excludeMatches: siteModeExcludes } = precomputedScope ?? await buildSiteModeMatchScope();
    if ( siteModeMatches.length === 0 ) {
        return browser.scripting.unregisterContentScripts({
            ids: (await browser.scripting.getRegisteredContentScripts())
                .filter(s => s.id.startsWith(COSMETIC_CS_PREFIX))
                .map(s => s.id),
        }).catch(() => {});
    }

    const enabledRulesets = await getEnabledRulesets();

    let cosmeticFiles;
    if ( cosmeticFilesCache !== null ) {
        cosmeticFiles = cosmeticFilesCache;
    } else {
        try {
            const resp = await fetch(browser.runtime.getURL('/rulesets/cosmetic-files.json'));
            cosmeticFiles = await resp.json();
            cosmeticFilesCache = cosmeticFiles;
        } catch {
            return;
        }
    }

    // Every entry SHOULD carry specificDataFile/loaderFile (build-rulesets.mjs
    // always writes them now) — the `Boolean(...)` check stays as a real
    // guard, not decoration, against a stale/partial rulesets/ directory
    // (e.g. a build interrupted mid-run) rather than silently registering
    // a broken directive with undefined path segments in its `js` array.
    const wantedEntries = cosmeticFiles.filter(({ id, specificDataFile, loaderFile }) =>
        (ALWAYS_ON_RULESETS.has(id) || enabledRulesets.has(id)) &&
        Boolean(specificDataFile) && Boolean(loaderFile)
    );

    const toRegister = wantedEntries.map(entry => {
        const directive = {
            id: `${COSMETIC_CS_PREFIX}${entry.id}`,
            js: [ ...COSMETIC_SPECIFIC_SHARED_JS, `/${entry.loaderFile}`, COSMETIC_SPECIFIC_READER_JS ],
            matches: siteModeMatches,
            world: 'ISOLATED',
            allFrames: true,
            runAt: 'document_start',
        };
        if ( siteModeExcludes.length > 0 ) {
            directive.excludeMatches = siteModeExcludes;
        }
        return directive;
    });

    // ── GUARD: init — ensure chrome.storage.local has fresh data for every
    // ruleset about to be registered. Version-checked
    // (COSMETIC_SPECIFIC_VERSION_FIELD, stamped at build time from the
    // data's own content) so a registration pass triggered by something
    // unrelated (a site-mode change, a different ruleset's toggle) doesn't
    // re-fetch/re-write data that hasn't actually changed since last time.
    const registry = await localRead(COSMETIC_SPECIFIC_REGISTRY_KEY).catch(() => undefined) ?? {};
    const nextRegistry = { ...registry };
    for ( const entry of wantedEntries ) {
        if ( registry[entry.id] === entry.v ) { continue; } // already current
        try {
            const resp = await fetch(browser.runtime.getURL(`/${entry.specificDataFile}`));
            const data = await resp.json();
            await localWrite(`${COSMETIC_SPECIFIC_STORAGE_PREFIX}${entry.id}`, data);
            nextRegistry[entry.id] = data[COSMETIC_SPECIFIC_VERSION_FIELD] ?? entry.v;
        } catch (reason) {
            console.error(`[uBlock-Dynamic] cosmetic specific-data init (${entry.id}):`, reason);
            // Leave nextRegistry[entry.id] as whatever it was — a failed
            // write must not be recorded as if it succeeded, or a real
            // future data change for this ruleset could be skipped by the
            // version check above.
        }
    }

    // ── GUARD: clear/release — any ruleset this function has EVER written
    // storage-backed data for, but that is no longer wanted this pass
    // (disabled, or missing required build fields), gets its
    // chrome.storage.local entry removed and its registry entry dropped.
    // Prevents storage.local from silently accumulating cosmetic data for
    // rulesets the user long ago turned off.
    const wantedRulesetIds = new Set(wantedEntries.map(e => e.id));
    const staleIds = Object.keys(registry).filter(id => !wantedRulesetIds.has(id));
    if ( staleIds.length > 0 ) {
        await localRemove(staleIds.map(id => `${COSMETIC_SPECIFIC_STORAGE_PREFIX}${id}`)).catch(() => {});
        for ( const id of staleIds ) { delete nextRegistry[id]; }
    }
    if ( staleIds.length > 0 || wantedEntries.some(e => registry[e.id] !== nextRegistry[e.id]) ) {
        await localWrite(COSMETIC_SPECIFIC_REGISTRY_KEY, nextRegistry).catch(() => {});
    }

    let existing = [];
    try {
        existing = await browser.scripting.getRegisteredContentScripts({
            ids: cosmeticFiles.map(f => `${COSMETIC_CS_PREFIX}${f.id}`),
        });
    } catch {
        existing = [];
    }

    const existingMap = new Map(existing.map(s => [s.id, s]));
    const wantedIds = new Set(toRegister.map(s => s.id));

    const toRemove = [...existingMap.keys()].filter(id => !wantedIds.has(id));
    if ( toRemove.length ) {
        await browser.scripting.unregisterContentScripts({ ids: toRemove }).catch(() => {});
    }

    // Porting note (v9.5.1, item 2): was a per-directive loop calling
    // updateContentScripts([directive])/registerContentScripts([directive])
    // once per ruleset — see registerOrUpdateContentScripts()'s own
    // comment above for the full accounting.
    await registerOrUpdateContentScripts(toRegister, existingMap, {
        updateErrorLabel: '[uBlock-Dynamic] updateContentScripts (cosmetic):',
        registerErrorLabel: '[uBlock-Dynamic] registerContentScripts (cosmetic):',
    });
}

/******************************************************************************/
// Cookie/consent-clicker content script registration
//
// See COOKIE-CLICKER-DESIGN.md for the full design history. ONE small,
// this-project-owned content script (js/scripting/cookie-clicker-click.js
// — NOT AdGuard's `trusted-click-element`, see that design doc's "The
// 'trusted-' scriptlet question — resolved" section for why that trust
// tier was never actually needed) is registered ISOLATED-world,
// allFrames: true — the concrete, specific fix for the exact bug the
// design doc diagnosed in the ORIGINAL (picker-based) attempt at this
// feature: without allFrames: true, a script can only ever run in a
// page's top frame, and most real cookie-consent platforms (OneTrust,
// Cookiebot, Quantcast, TrustArc, etc.) render their actual "Accept"
// button inside a cross-origin iframe. allFrames: true means this script
// runs SEPARATELY, natively, inside every frame — including third-party
// CMP iframes — so it never needs to reach across the cross-origin
// boundary at all (impossible) — the click code is just already there,
// in the same origin as the button. Same fix shape as
// registerScriptletContentScriptsImpl()/registerCosmeticContentScriptsImpl()
// just above, applied to a brand new registration group instead of an
// existing one.
//
// Unlike scriptlets/cosmetic rules (bundled filter-list data, baked into
// per-ruleset files at build time), cookie-clicker rules are entirely
// user-created (via the picker, js/scripting/cookie-clicker-picker.js)
// and few in number — tens, not thousands — so there's no per-ruleset
// sharding here: ONE content-script directive, registered whenever ANY
// rule exists anywhere, unregistered (RELEASE guard) the moment none do.
// The script itself reads the flat rule set straight from
// chrome.storage.local at injection time (see that file's own header)
// and filters to whatever's relevant to its own frame — mirroring how
// css-specific.js reads its own storage-backed data at injection time,
// just without that file's per-ruleset sharding/build-time-generation
// step, since there's no build step for user-created rules.
/******************************************************************************/

// Must not collide with SCRIPTLET_CS_PREFIX ('ag-scriptlets-'),
// COSMETIC_CS_PREFIX ('ag-cosmetic-'), SECURITY_CS_PREFIX ('sec-'), or
// AUTO_DENY_CS_ID ('ubol-autodeny') — same cross-reference invariant this
// file's header warns about. Not a prefix (only ever one directive, not
// one per ruleset) but named with the same 'CS_ID' suffix convention for
// readability at the call sites below.
const COOKIE_CLICKER_CS_ID = 'ubol-cookie-clicker';

// STORAGE KEY — must match js/core/cookie-clicker-rules.js's own
// STORAGE_KEY constant (that file owns every WRITE to this key; this
// function only ever READS it, to answer "is there anything to
// register?"). Also must match js/scripting/cookie-clicker-click.js's
// own hardcoded read of the same key. Three independent copies of one
// string is one more than ideal, but the three files live in different
// execution contexts (service worker / service worker / content script)
// with no shared import surface between the last one and the other two —
// same constraint COSMETIC_SPECIFIC_STORAGE_PREFIX's own "must match
// exactly" comment already documents for the identical problem.
const COOKIE_CLICKER_STORAGE_KEY = 'cookieClicker.rules';

async function hasAnyCookieClickerRulesStored() {
    // (v8.6.16) Restored — DPG Media's built-in rule is back (per
    // explicit clarification: it belongs in the always-on manual
    // cookie-clicker system, not Worry-free/auto-deny) — at least one
    // site always has real rules now, independent of anything the user
    // has ever created via the picker. Kept as an explicit constant here
    // (duplicated, not shared — no import surface between this service-
    // worker file and the injected content script, same posture as
    // COOKIE_CLICKER_STORAGE_KEY's own "three independent copies"
    // comment just above) rather than silently deleting the RELEASE
    // guard below — if every built-in is ever removed, flipping this
    // back to false restores the original "off by default" behavior
    // automatically.
    const HAS_BUILTIN_COOKIE_CLICKER_RULES = true;
    if ( HAS_BUILTIN_COOKIE_CLICKER_RULES ) { return true; }
    const stored = await localRead(COOKIE_CLICKER_STORAGE_KEY).catch(() => undefined);
    if ( typeof stored !== 'object' || stored === null ) { return false; }
    return Object.values(stored).some(siteRules => Array.isArray(siteRules) && siteRules.length > 0);
}

export async function registerCookieClickerContentScripts() {
    return withRegistrationLock(registerCookieClickerContentScriptsImpl);
}
async function registerCookieClickerContentScriptsImpl(precomputedScope) {
    // Same site-mode / temp-disable gating as scriptlets and cosmetic
    // rules just above — a site the user turned OFF, or a global
    // temp-disable pause, must stop the consent-clicker too, not just
    // DNR network blocking.
    //
    // Porting note (v9.4.9, item 3): same precomputedScope treatment as
    // registerScriptletContentScriptsImpl() above — see that function's
    // own comment.
    const { matches: siteModeMatches, excludeMatches: siteModeExcludes } = precomputedScope ?? await buildSiteModeMatchScope();

    // RELEASE guard: nowhere left to inject into (site-mode scope empty)
    // — unregister rather than leave a permanently-registered-but-never-
    // matching script behind. The "no rules anywhere" half of this guard
    // is now permanently false in practice (DPG Media's built-in rule —
    // see hasAnyCookieClickerRulesStored()'s own comment), so this now
    // registers whenever the site-mode scope is non-empty, effectively
    // always — the per-site "nothing to do here" check still lives
    // inside cookie-clicker-click.js itself, same as it always did for
    // the many sites that were never matched even when this guard was
    // still meaningfully conditional.
    const hasRules = siteModeMatches.length > 0 && await hasAnyCookieClickerRulesStored();
    if ( hasRules === false ) {
        return browser.scripting.unregisterContentScripts({
            ids: [ COOKIE_CLICKER_CS_ID ],
        }).catch(() => {}); // benign: not currently registered is expected on most installs
    }

    const directive = {
        id: COOKIE_CLICKER_CS_ID,
        js: [
            '/js/scripting/isolated-api.js',    // self.isolatedAPI — same shared file cosmetic rules use, for topHostname/thisHostname (document.location.ancestorOrigins-based, works inside cross-origin iframes)
            '/js/scripting/cookie-clicker-click.js',
        ],
        matches: siteModeMatches,
        world: 'ISOLATED',
        allFrames: true,
        // 'document_idle' (not 'document_start' like scriptlets/security,
        // which need to run BEFORE page scripts to intercept APIs) — a
        // consent banner's own DOM usually doesn't exist yet at
        // document_start, and this script's job is purely to find/click
        // an already-rendered element, not to race the page's own
        // scripts. The click interpreter's own MutationObserver-based
        // wait-and-click (see that file) still covers a banner that
        // renders even later than document_idle, so this is a
        // "reasonable default start point", not a hard timing
        // requirement.
        runAt: 'document_idle',
    };
    if ( siteModeExcludes.length > 0 ) {
        directive.excludeMatches = siteModeExcludes;
    }

    let existing = [];
    try {
        existing = await browser.scripting.getRegisteredContentScripts({
            ids: [ COOKIE_CLICKER_CS_ID ],
        });
    } catch {
        existing = [];
    }

    if ( existing.length > 0 ) {
        await browser.scripting.updateContentScripts([ directive ]).catch(reason => {
            console.error('[uBlock-Dynamic] updateContentScripts (cookie-clicker):', reason);
        });
    } else {
        await browser.scripting.registerContentScripts([ directive ]).catch(reason => {
            console.error('[uBlock-Dynamic] registerContentScripts (cookie-clicker):', reason);
        });
    }
}

/******************************************************************************/
// Never-consent / cookie-clicker auto-deny content script registration
// (v8.2)
//
// A generic, unattended "auto-deny" action bundle (js/scripting/autodeny-
// snippets.generated.js — vendored, build-time-compiled from DDG's
// autoconsent eval-snippets, see that file's own header) registered
// MAIN-world, allFrames: true (consent banners routinely render inside
// cross-origin CMP iframes, same reasoning as the cookie-clicker group
// just above), document_idle + the bundle's own internal retry/poll (D4
// — CMP globals like window.Didomi/window.Cookiebot may not exist yet at
// document_start).
//
// Registration-presence IS the on/off switch itself (D11) — NOT a
// priority/skip-flag check inside the bundle. Default state is fully
// unregistered: zero bytes reach any page until a session is actually
// started via js/core/cookie-clicker-autodeny-manager.js's
// startAutoDeny(). Called from exactly two places: startAutoDeny() (init)
// and restoreNow() (release) — no third call site, mirroring the cookie-
// clicker group's own two-call-site convention.
/******************************************************************************/

// Must not collide with SCRIPTLET_CS_PREFIX ('ag-scriptlets-'),
// COSMETIC_CS_PREFIX ('ag-cosmetic-'), SECURITY_CS_PREFIX ('sec-'), or
// COOKIE_CLICKER_CS_ID ('ubol-cookie-clicker') — same cross-reference
// invariant this file's header warns about.
const AUTO_DENY_CS_ID = 'ubol-autodeny';

// STORAGE KEY — must match js/core/cookie-clicker-autodeny-manager.js's
// own STORAGE_KEY constant (that module owns every WRITE to this key;
// this function only ever READS it, to answer "is a session active?").
// Read directly here, rather than importing getAutoDenyState() from that
// module, deliberately — the same choice COOKIE_CLICKER_STORAGE_KEY just
// above already makes for the identical reason: importing a core/ module
// that itself imports THIS module's own registration function back would
// be a circular import. One more independent copy of one string, same
// "must match exactly" posture as COOKIE_CLICKER_STORAGE_KEY.
const AUTO_DENY_STORAGE_KEY = 'cookieClicker.autoDeny';

async function isAutoDenySessionActive() {
    const stored = await localRead(AUTO_DENY_STORAGE_KEY).catch(() => undefined);
    if ( typeof stored !== 'object' || stored === null ) { return false; }
    // Self-heal is getAutoDenyState()'s job (path 2, see that module's own
    // header) — this function is a cheap, read-only "is it plausibly on"
    // check for registration purposes only, so a session whose expiry has
    // technically already passed but hasn't yet been read/self-healed is
    // still treated as active for one extra registration pass at most;
    // getAutoDenyState()'s own self-heal (called on every popup poll, and
    // on the alarm firing) is what actually tears the registration back
    // down moments later via restoreNow()'s own release call. Never a
    // permanent leak — just a harmless few-second-wide race window.
    return stored.active === true;
}

export async function registerCookieClickerAutoDenyContentScripts() {
    return withRegistrationLock(registerCookieClickerAutoDenyContentScriptsImpl);
}
async function registerCookieClickerAutoDenyContentScriptsImpl(precomputedScope) {
    // Porting note (v9.4.9, item 3): same precomputedScope treatment as
    // registerScriptletContentScriptsImpl() above — see that function's
    // own comment.
    const { matches: siteModeMatches, excludeMatches: siteModeExcludes } = precomputedScope ?? await buildSiteModeMatchScope();

    // RELEASE guard (D11) — checked BEFORE anything else touches
    // browser.scripting, so the overwhelmingly common case (feature never
    // turned on) costs one cheap storage read and injects nothing —
    // literally zero bytes reach any page, not "injected but inert".
    const active = siteModeMatches.length > 0 && await isAutoDenySessionActive();
    if ( active === false ) {
        return browser.scripting.unregisterContentScripts({
            ids: [ AUTO_DENY_CS_ID ],
        }).catch(() => {}); // benign: not currently registered is the expected default
    }

    const directive = {
        id: AUTO_DENY_CS_ID,
        js: [ '/js/scripting/autodeny-snippets.generated.js' ],
        matches: siteModeMatches,
        world: 'MAIN',
        allFrames: true,
        runAt: 'document_idle', // D4 — bundle's own retry/poll still covers a CMP global that appears even later
    };
    if ( siteModeExcludes.length > 0 ) {
        directive.excludeMatches = siteModeExcludes;
    }

    let existing = [];
    try {
        existing = await browser.scripting.getRegisteredContentScripts({
            ids: [ AUTO_DENY_CS_ID ],
        });
    } catch {
        existing = [];
    }

    if ( existing.length > 0 ) {
        await browser.scripting.updateContentScripts([ directive ]).catch(reason => {
            console.error('[uBlock-Dynamic] updateContentScripts (autodeny):', reason);
        });
    } else {
        await browser.scripting.registerContentScripts([ directive ]).catch(reason => {
            console.error('[uBlock-Dynamic] registerContentScripts (autodeny):', reason);
        });
    }
}

/******************************************************************************/
// Security scriptlet content script registration
// Security toggle scriptlets (blockWebRTC, blockWebGL,
// blockAlertDialogs, blockConfirmDialogs, blockObfuscatedEval, blockAdultFingerprinting)
// are registered as MAIN-world content scripts via browser.scripting —
// no userScripts permission needed, same path as AG ruleset scriptlets above.
//
// Directives are prepared by compiled-filters.js (pure data layer).
// This function owns all browser.scripting calls for the sec-* namespace.
/******************************************************************************/

// Must not collide with SCRIPTLET_CS_PREFIX ('ag-scriptlets-') or
// COSMETIC_CS_PREFIX ('ag-cosmetic-').
const SECURITY_CS_PREFIX = 'sec-';

// Concurrent callers now queue behind the shared withRegistrationLock() above
// instead of a bespoke local guard — see that constant's comment for why a
// guard scoped to only this function was never enough to prevent the race.
export async function registerSecurityContentScripts() {
    return withRegistrationLock(registerSecurityContentScriptsImpl);
}

async function registerSecurityContentScriptsImpl(precomputedScope) {
    // isWorryFreeActive: reuses isAutoDenySessionActive() (defined below,
    // same file) — the identical cycle-free-read pattern already
    // established for this exact class of problem, not a second copy of
    // the same idea. Threaded into prepareSecurityScriptletDirectives()
    // as a parameter — see that function's own comment in
    // compiled-filters.js on why it doesn't read this itself.
    // (v8.5.8) Same gating as ruleset-manager.js's own copy of this
    // computation — worryFreeSecurityProtectionsEnabled applied once,
    // here, so every worryFreeOverride entry in compiled-filters.js's
    // SECURITY_SCRIPTLETS reads the already-gated result.
    const sessionActive = await isAutoDenySessionActive();
    const isWorryFreeActive = sessionActive && securityConfig.worryFreeSecurityProtectionsEnabled !== false;
    // isWorryFreeAntiFingerprintActive — deliberately its OWN gate, not
    // folded into isWorryFreeActive above (that one is tied to
    // worryFreeSecurityProtectionsEnabled, an unrelated Security &
    // Privacy tab master switch) — see compiled-filters.js's own comment
    // on why this stays separate. Reuses the same sessionActive read
    // rather than calling isAutoDenySessionActive() a second time.
    const isWorryFreeAntiFingerprintActive = sessionActive && securityConfig.worryFreeAntiFingerprintEnabled === true;
    // Porting note (v9.4.9, item 3): precomputedScope threaded through as
    // prepareSecurityScriptletDirectives()'s own third parameter — see
    // that function's comment in compiled-filters.js.
    const directives = await prepareSecurityScriptletDirectives(isWorryFreeActive, isWorryFreeAntiFingerprintActive, precomputedScope);
    const wantedIds  = new Set(directives.map(d => d.id));

    // Query only IDs in the sec-* namespace to avoid touching sibling groups.
    let existing = [];
    try {
        existing = await browser.scripting.getRegisteredContentScripts();
        existing = existing.filter(s => s.id.startsWith(SECURITY_CS_PREFIX));
    } catch {
        existing = [];
    }
    const existingMap = new Map(existing.map(s => [ s.id, s ]));

    // Remove scripts whose toggle was turned off.
    const toRemove = [ ...existingMap.keys() ].filter(id => !wantedIds.has(id));
    if ( toRemove.length ) {
        await browser.scripting.unregisterContentScripts({ ids: toRemove }).catch(reason => {
            console.error('[uBlock-Dynamic] security unregisterContentScripts:', reason);
        });
    }

    // Porting note (v9.5.1, item 2): was a per-directive loop calling
    // updateContentScripts([directive])/registerContentScripts([directive])
    // once per ruleset, with a defensive fallback for the exact race the
    // in-flight guard above is meant to prevent (a registration left
    // over from just before a version update that Chrome hasn't
    // finished clearing yet — see the MDN note quoted in background.js's
    // syncScriptRegistrations): a "duplicate script id" error on
    // register retried as an update instead of just logging and leaving
    // that scriptlet unregistered. retryDuplicateAsUpdate preserves this
    // exact race guard — see registerOrUpdateContentScripts()'s own
    // comment above for the full accounting, including why this is the
    // only one of the three callers that needs it.
    await registerOrUpdateContentScripts(directives, existingMap, {
        updateErrorLabel: '[uBlock-Dynamic] security updateContentScripts:',
        registerErrorLabel: '[uBlock-Dynamic] security registerContentScripts:',
        postDuplicateUpdateLabel: '[uBlock-Dynamic] security registerContentScripts (post-duplicate update):',
        retryDuplicateAsUpdate: true,
    });
}

/******************************************************************************/
// Session CSS cache helpers (see also pruneCSSCache() further below, which
// bounds this cache's size on the CSS_CACHE_PRUNE_INTERVAL_MS timer).

async function resetCSSCache() {
    const keys = await sessionKeys();
    return sessionRemove(keys.filter(a => a.startsWith('cache.css.')));
}

/******************************************************************************/
// Main orchestration — full re-registration pass, triggered on startup and
// whenever filtering-mode/ruleset/permission state changes elsewhere.

// Issue: Safari appears to completely ignore excludeMatches
// https://github.com/radiolondra/ExcludeMatches-Test

// The mutex mechanism itself now lives in js/util/async-lock.js (see
// registrationLock above for the same extraction). .pendingOp is still
// assigned on every call — not just returned — so anything that reads this
// property later (see mode-manager.js's own comment citing this exact
// "function-as-namespace" convention) keeps seeing a live, correct promise.
const pendingOpLock = createLock('scripting-manager/registerContentScripts.pendingOp');

// Porting note (v9.4.9, item 1): registerCustomFilters() in
// filter-manager.js now returns its directive (or undefined) instead of
// pushing into a shared toAdd array that used to be registered in one
// unconditional batch after this module's now-removed blanket
// unregisterContentScripts() wipe. This is the existing-vs-wanted diff that
// directive never had — same shape as registerCookieClickerContentScriptsImpl()
// above (getRegisteredContentScripts check, then updateContentScripts/
// registerContentScripts/unregisterContentScripts as appropriate). Called
// from inside registerContentScripts.register()'s own withRegistrationLock()
// batch, alongside the other five groups — not exported, not meant to be
// called independently, since `directive` must already reflect the current
// filteringModeDetails computed earlier in that same registration cycle.
async function registerCustomFiltersDirective(directive) {
    let existing = [];
    try {
        existing = await browser.scripting.getRegisteredContentScripts({
            ids: [ CSS_USER_CS_ID ],
        });
    } catch {
        existing = [];
    }

    if ( directive === undefined ) {
        if ( existing.length > 0 ) {
            await browser.scripting.unregisterContentScripts({
                ids: [ CSS_USER_CS_ID ],
            }).catch(() => {}); // benign: not currently registered is expected on most installs
        }
        return;
    }

    if ( existing.length > 0 ) {
        await browser.scripting.updateContentScripts([ directive ]).catch(reason => {
            console.error('[uBlock-Dynamic] updateContentScripts (css-user):', reason);
        });
    } else {
        await browser.scripting.registerContentScripts([ directive ]).catch(reason => {
            console.error('[uBlock-Dynamic] registerContentScripts (css-user):', reason);
        });
    }
}

export async function registerContentScripts() {
    if ( browser.scripting === undefined ) { return false; }
    registerContentScripts.pendingOp = pendingOpLock.withLock(
        ( ) => registerContentScripts.register()
    );
    return registerContentScripts.pendingOp;
}
registerContentScripts.pendingOp = Promise.resolve();

registerContentScripts.register = async function register() {
    const filteringModeDetails = await getFilteringModeDetails();
    const context = {
        filteringModeDetails,
    };

    const [ customFiltersDirective ] = await Promise.all([
        registerCustomFilters(context),
        registerToolbarIconToggler(context),
    ]);

    // Porting note (v9.4.9, item 3): computed ONCE here instead of once
    // per affected group below (5 independent calls to an identical
    // result otherwise — pure waste, worse now that item 1 above means
    // this whole batch runs on every registration cycle rather than
    // being defeated by a blanket wipe regardless). Passed as
    // precomputedScope to each of the 5 functions that used to call
    // buildSiteModeMatchScope() themselves; their own public wrappers
    // (registerScriptletContentScripts() etc. — called independently
    // from many places outside this batch, see e.g.
    // cookie-clicker-routes.js, security-routes.js, temp-disable-
    // manager.js) still compute it themselves when called that way,
    // since those call sites pass no argument at all — see each
    // function's own comment. registerCustomFiltersDirective() above is
    // NOT included: its directive comes from registerCustomFilters(),
    // which uses filteringModeDetails directly and never calls
    // buildSiteModeMatchScope() at all.
    const siteModeScope = await buildSiteModeMatchScope();

    // Porting note (v9.4.9, item 1, step 2): the blanket
    // unregisterContentScripts() (no ids filter) that used to run here was
    // removed — it defeated every group's own existing-vs-wanted diff
    // below by wiping everything unconditionally on every call, regardless
    // of what actually changed. Verified safe to remove only after
    // confirming, group by group, that each of the six calls below already
    // has a complete self-contained diff: an explicit unregister path for
    // "no longer wanted" (not just a register/update path for "wanted"),
    // so nothing depends on this wipe for its own removal anymore.
    // withRegistrationLock() is kept regardless — its job (serializing
    // this batch against any group's own public wrapper being called
    // independently elsewhere, e.g. registerCookieClickerContentScripts()
    // called directly from cookie-clicker-routes.js) is unrelated to
    // whether a wipe used to precede it.
    await withRegistrationLock(async ( ) => {
        // Re-register/re-diff all six groups. Bug fix (v3.21): previously
        // only security scriptlets were re-registered here, so the
        // AdGuard scriptlet/cosmetic injection layer silently dropped out
        // on every permission change, filtering-mode change, picker rule
        // addition, and sandbox save — anything that calls
        // registerContentScripts() outside of SW startup or a ruleset toggle
        // (the only two places that previously called these two functions).
        // DNR network-level blocking was unaffected; only the JS-injected
        // scriptlet/cosmetic layer silently stopped working until the next SW
        // restart or ruleset toggle brought it back.
        //
        // registerCustomFiltersDirective() (v9.4.9, item 1, step 1) added
        // as a sixth group — previously this directive was batch-registered
        // separately, after this whole locked block, via the now-removed
        // toAdd/context.toAdd mechanism.
        await Promise.all([
            registerSecurityContentScriptsImpl(siteModeScope),
            registerScriptletContentScriptsImpl(siteModeScope),
            registerCosmeticContentScriptsImpl(siteModeScope),
            registerCookieClickerContentScriptsImpl(siteModeScope),
            registerCookieClickerAutoDenyContentScriptsImpl(siteModeScope),
            registerCustomFiltersDirective(customFiltersDirective),
        ]);
    });

    await Promise.all([
        resetCSSCache(),
        registerJob('pruneCSSCache', Date.now() + CSS_CACHE_PRUNE_INTERVAL_MS),
    ]);

    return true;
};

/******************************************************************************/
// Introspection

export async function getRegisteredContentScripts() {
    const scripts = await browser.scripting.getRegisteredContentScripts();
    return scripts.map(a => a.id);
}

/******************************************************************************/
// Generic, lock-guarded register/unregister primitives for modules outside
// this one that still need to register their own content scripts (currently:
// js/core/privacy-inspector.js's probe/bridge pair). Keeps this module the
// sole direct caller of browser.scripting.*, per the header comment, while
// still letting callers build their own directives — and, critically, keeps
// them inside withRegistrationLock() so they can't race the six-group
// re-diff batch in registerContentScripts.register() the way an unguarded
// direct call would.
/******************************************************************************/

export async function registerContentScriptsSafely(directives) {
    return withRegistrationLock(async ( ) => {
        try {
            await browser.scripting.registerContentScripts(directives);
            return { ok: true };
        } catch (reason) {
            console.error('[uBlock-Dynamic] registerContentScriptsSafely:', reason);
            return { ok: false, error: String(reason?.message ?? reason) };
        }
    });
}

export async function unregisterContentScriptsByIds(ids) {
    return withRegistrationLock(async ( ) => {
        try {
            await browser.scripting.unregisterContentScripts({ ids });
        } catch {
            // Benign: ids not currently registered is an expected outcome
            // here (e.g. first-ever registration, or already torn down).
        }
        return { ok: true };
    });
}

/******************************************************************************/
// Session CSS cache pruning (bounds the cache resetCSSCache() clears in bulk
// — see that function further above).

export async function pruneCSSCache() {
    registerJob('pruneCSSCache', Date.now() + CSS_CACHE_PRUNE_INTERVAL_MS);
    const MAX_CACHE_ENTRY_LOW = 256;
    const MAX_CACHE_ENTRY_HIGH = MAX_CACHE_ENTRY_LOW +
        Math.max(Math.round(MAX_CACHE_ENTRY_LOW / 8), 8);
    const keys = await sessionKeys() || [];
    const cacheKeys = keys.filter(a => a.startsWith('cache.css.'));
    if ( cacheKeys.length < MAX_CACHE_ENTRY_HIGH ) { return; }
    const entries = await Promise.all(cacheKeys.map(async a => {
        const entry = await sessionRead(a) || {};
        entry.key = a;
        return entry;
    }));
    entries.sort((a, b) => b.t - a.t);
    sessionRemove(entries.slice(MAX_CACHE_ENTRY_LOW).map(a => a.key));
}

/******************************************************************************/
// Debugging

// Debugging aid only — not used by any other module's actual control flow,
// so it can never become a hidden coupling. Delegates to each lock's own
// getState() (js/util/async-lock.js), which already returns a snapshot, not
// the live object. See the OBSERVABILITY note near the top of this file.
export function getScriptingManagerLockState() {
    return {
        registrationLock: registrationLock.getState(),
        pendingOp:        pendingOpLock.getState(),
    };
}

/******************************************************************************/
