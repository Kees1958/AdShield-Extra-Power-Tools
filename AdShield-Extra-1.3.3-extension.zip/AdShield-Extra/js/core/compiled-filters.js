/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2026-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * compiled-filters.js — custom-scriptlet-selector DNR rule compilation
 *
 * Public interface:
 *   updateCompiledFilters()                — compiles scriptlet-shaped site.*
 *                                            custom-filter selectors (getUserList(),
 *                                            below) via offscreen document; saves
 *                                            only DNR rules (network + cosmetic
 *                                            rules). Scriptlet rules (+js()) are
 *                                            compiled but their output is
 *                                            intentionally discarded — the
 *                                            userScripts permission has been
 *                                            removed in v3.12.
 *   prepareSecurityScriptletDirectives()   — builds browser.scripting directive objects for all
 *                                            enabled security toggle scriptlets (pure data, no
 *                                            API calls). Consumed by scripting-manager.js.
 *
 * State owned:
 *   pendingRegister {Promise} — serialises concurrent compile calls; lost on SW restart (safe)
 */


// Imported (subscribed) filter lists had no reachable UI to add one (that
// lived in the removed Filter lists tab), so all of that integration has
// been removed here too. BRAVE VARIANT (v1.0.0) — the free-text ABP-import
// sandbox editor this module used to also compile is gone entirely (no
// surviving UI, no message route); only the scriptlet-shaped subset of
// site.* custom-filter selectors is compiled now — see getUserList() below.

import {
    localRead,
    localRemove,
    localWrite,
    runtime,
} from '../data/ext.js';

import {
    closeOffscreenDocument,
    createOffscreenDocument,
} from '../data/ext-offscreen.js';

import {
    getAllCustomFilters,
} from './filter-manager.js';

import {
    isScriptlet,
} from '../util/utils.js';

import { dnr } from '../data/ext-compat.js';
import { securityConfig, securityAllowlist } from '../data/config.js';
import { getFilteringModeDetails } from './mode-manager.js';
import { getFamiliarTlds } from './worry-free-familiar-tld-manager.js';

/******************************************************************************/

// Parse allowlist string → match patterns for content script excludeMatches.
// Comment lines (starting with '#') and blank lines must be dropped as whole
// LINES before any whitespace splitting — otherwise words inside a comment
// sentence (e.g. "# Microsoft SSO / SharePoint / Office 365") get parsed as
// if they were hostnames, including stray '/' tokens that produce invalid
// empty-host match patterns like '*:////*'.
function allowlistToExcludeMatches(str) {
    if ( !str ) { return []; }
    const hostnames = str.split(/\r\n|\r|\n/)
        .map(line => line.trim())
        .filter(line => line.length > 0 && !line.startsWith('#'))
        .flatMap(line => line.split(/[\s,]+/))
        .map(h => h.trim().toLowerCase())
        .filter(h => h.length > 0);
    // Convert hostnames to match patterns covering http/https + all subdomains.
    return hostnames.flatMap(hn => [
        `*://${hn}/*`,
        `*://*.${hn}/*`,
    ]);
}

/******************************************************************************/

// ── Security scriptlet registry ───────────────────────────────────────────────
//
// Each entry maps one securityConfig toggle to a MAIN-world content script
// injected at <all_urls> / document_start via browser.scripting. The actual
// code for each scriptlet lives in its own standalone file under
// js/security/{id}.js — see prepareSecurityScriptletDirectives() below, which
// builds `js: ['/js/security/${s.id}.js']` directly from each entry's `id`.
// Standalone files, not inline {code} strings, because
// browser.scripting.registerContentScripts requires a file path in MV3
// (inline {code} objects aren't accepted), and because keeping each
// scriptlet in its own file avoids re-embedding regex literals that Brave's
// inline-code validator rejects.
//
// Fields:
//   key {string} — securityConfig property name
//   id  {string} — stable content script id AND filename stem
//                   (js/security/{id}.js) — must be unique, never reuse

const SECURITY_SCRIPTLETS = [
    {
        // Removes hyperlink-auditing ping targets while preserving normal link navigation.
        key: 'blockPings',
        id:  'sec-pings',
        // worryFreeOverride (v8.4.7) — extended from the original 2
        // (blockAdultNoEval/blockAdultFingerprinting, v8.3.12) to all 8
        // Security & Privacy toggles per explicit request: every one of
        // this dashboard's protections should be active for the
        // duration of a Worry-free session, not just the adult-site
        // pair. Same mechanism throughout — never writes securityConfig
        // itself, only affects whether the scriptlet is REGISTERED
        // right now; the person's own stored on/off setting is
        // untouched and reverts the moment the session ends.
        worryFreeOverride: true,
    },
    // ── safe browsing mode toggles (v3.6.4) ──────────────────────────────────
    {
        // Silences window.alert() — used by tech-support fraud sites to lock the
        // browser.  Proxies alert → console.info; spoofs .toString() so
        // native-code checks pass.  Source: scriptlets.js alertBuster.
        //
        // BRAVE VARIANT — key merged with sec-dialogbuster's own entry
        // below into one setting (blockDialogSpam), per explicit request:
        // "Block alert, confirm and prompt scam" is one checkbox now, not
        // two. Still two separate scriptlets (alert vs. confirm/prompt
        // are different APIs with different signatures) — just one
        // config key toggling both.
        key: 'blockDialogSpam',
        id:  'sec-alertbuster',
        worryFreeOverride: true, // v8.4.7 — see blockPings' own comment above
    },
    {
        // Silences window.confirm() → false and window.prompt() → null.
        // Tech-support fraud sites loop these dialogs to lock the browser.
        // Returning false/null is always the safe/cancel outcome.
        // Source: scriptlets.js dialogBuster.
        key: 'blockDialogSpam',
        id:  'sec-dialogbuster',
        worryFreeOverride: true, // v8.4.7 — see blockPings' own comment above
    },
    {
        // Blocks eval() calls whose payload matches known obfuscation signatures.
        // Clean payloads (webpack HMR, REPL, Monaco) pass through unaffected.
        // Note: Cloudflare bot-challenge pages use packed eval — add to allowlist
        // if affected (e.g. challenges.cloudflare.com).
        //
        // Converted from corelibs prevent-eval-if to inline IIFE because the
        // corelibs function body contains regex literals that Brave rejects when
        // injected into registerContentScripts inline code.
        key: 'blockObfuscatedEval',
        id:  'sec-noeval',
        // BRAVE VARIANT — worryFreeGatedOptOut, not worryFreeOverride:
        // this only ever applies DURING an active Worry-free session
        // (Privacy & Security tab's Group 3, "enabled by default in
        // worry-free mode") — the checkbox is a genuine opt-out (see
        // prepareSecurityScriptletDirectives() below), not a manual
        // always-on switch.
        worryFreeGatedOptOut: true,
    },
    {
        // Strict eval blocker limited to the configured adult-site match list.
        // BRAVE VARIANT — worryFreeGatedOptOut, not worryFreeOverride
        // (was worryFreeOverride v8.3.12 through the Brave-variant
        // Privacy & Security tab redesign; corrected after explicit
        // clarification: moved into the "Very low website breakage risk
        // enhancements (enabled by default in Worry-free mode)" group
        // specifically because this should ONLY ever apply during an
        // active Worry-free session, not stay active all the time once
        // checked). See prepareSecurityScriptletDirectives() below.
        // Never writes securityConfig itself — the person's own stored
        // setting (on or off) is untouched; this only affects whether
        // the scriptlet is REGISTERED right now.
        key: 'blockAdultNoEval',
        id:  'sec-adult-noeval',
        worryFreeGatedOptOut: true,
    },
    {
        // Applies fingerprinting-detection mitigations directly,
        // unconditionally, on the same curated high-risk site list
        // blockAdultNoEval already uses
        // (SECURITY_SCRIPTLET_BUILTIN_MATCHES.blockAdultFingerprinting —
        // same underlying ADULT_SITE_MATCHES constant, not a second list):
        // canvas/WebGL, navigator.plugins, battery status, timezone, audio,
        // WebRTC. Categories chosen per JShelter's own classification
        // (canvas, WebGL, battery status, timezone, and audio are all
        // established fingerprinting vectors in the literature, not just
        // the "big 3"; see CHANGELOG). Deliberately excludes
        // non-fingerprinting categories (beacon, permissions, clipboard,
        // idle, NFC) — those are separate privacy concerns, not
        // identity-revealing signals, and are left to Privacy Inspector's
        // per-site, evidence-based Select flow instead.
        // hardwareConcurrency, deviceMemory, maxTouchPoints, connection,
        // and getGamepads are ALSO excluded — all legitimately used by
        // widespread, unrelated-to-fingerprinting code; blocking two of
        // them confirmed broke real sites. Battery status is kept:
        // Firefox/Safari removed that API entirely, precisely because it's
        // a precise fingerprint with no comparable legitimate use.
        // Timezone and audio were previously excluded too — re-added,
        // tested, confirmed not breaking sites. Timezone's earlier
        // interceptor didn't return anything (resolvedOptions() came back
        // `undefined`, breaking real sites' language detection off
        // `.locale`) — that was a bug in the interceptor, not a reason to
        // avoid timezone; this version returns the real resolved options
        // unchanged except `timeZone`. Audio only intercepts
        // OfflineAudioContext/webkitOfflineAudioContext, never
        // AudioContext/webkitAudioContext — offline contexts never reach
        // real speaker output, so real playback keeps working. Canvas,
        // audio, and WebRTC below are modeled on/consistent with this
        // project's own real prevent-canvas/nowebrtc corelib scriptlets —
        // degrade gracefully (spec-legal null / no-op stub) instead of
        // throwing, unlike an earlier version of this file.
        key: 'blockAdultFingerprinting',
        id:  'sec-adult-fingerprint',
        // BRAVE VARIANT — worryFreeGatedOptOut, not worryFreeOverride —
        // same correction and same reasoning as blockAdultNoEval's own
        // entry above.
        worryFreeGatedOptOut: true,
    },
    {
        // BRAVE VARIANT — Privacy & Security tab's "Low website breakage
        // risk enhancements" group, 4th row. Reuses the EXACT same
        // sec-adult-fingerprint scriptlet as blockAdultFingerprinting
        // above (same protections: canvas/WebGL, navigator.plugins,
        // battery status, timezone, audio, WebRTC — see that entry's own
        // comment for the full per-vector reasoning), just scoped
        // differently: not a fixed high-risk site list, but every domain
        // OUTSIDE the familiar-TLD list (see worry-free-familiar-tld-
        // manager.js), matching the SCP privacy/security items' own
        // "safe regions" scoping. Registration id (sec-scp-fingerprint)
        // is deliberately its own value, distinct from
        // blockAdultFingerprinting's (sec-adult-fingerprint) — Chrome's
        // registerContentScripts() requires unique ids, and both these
        // directives can be simultaneously active — but scriptFile below
        // points both at the SAME underlying script file; one real
        // implementation, two independently-scoped registrations of it.
        // matches/excludeMatches for THIS specific key are computed
        // dynamically in prepareSecurityScriptletDirectives() below from
        // the current familiar-TLD list, not from
        // SECURITY_SCRIPTLET_BUILTIN_MATCHES/_EXCLUDES (both static
        // tables — the familiar-TLD list is user-editable, so a static
        // entry there would go stale the moment someone edits their TLD
        // list).
        key: 'blockScpFingerprint',
        id:  'sec-scp-fingerprint',
        scriptFile: 'sec-adult-fingerprint',
        worryFreeGatedOptOut: true,
    },
    // ── Worry-free-only anti-fingerprint pair (timezone + battery) ──────────
    // Added per explicit request, directly informed by a real discussion of
    // which of the ORIGINAL removed global anti-fingerprint layer's five
    // protections (nowebrtc/prevent-canvas/tz-fingerprint/idle/nfc — see
    // CHANGELOG's 8.4.6/8.6.0 entries) actually carry real-world
    // fingerprinting-defense value: idle and NFC are both explicitly
    // classified above as "separate privacy concerns, not identity-
    // revealing signals" (permission-gated, can't be read silently), while
    // battery is the strongest of the five (the exact reasoning that kept
    // it in blockAdultFingerprinting above) and timezone is a real,
    // established vector. WebGL/canvas (the one that broke nytimes.com,
    // per CHANGELOG's 8.5.5/8.6.0 entries) is deliberately NOT part of this
    // narrower pair.
    //
    // Unlike every other entry in this list, these two have NO independent
    // securityConfig[s.key] on/off state of their own — there is no
    // Security & Privacy tab checkbox for them. They exist ONLY as a
    // Worry-free-session effect, gated by `worryFreeAntiFingerprintOverride`
    // (a distinct field from `worryFreeOverride` above, checked against
    // `isWorryFreeAntiFingerprintActive` — a SEPARATE parameter from
    // `isWorryFreeActive`, not the same gate the other six entries use) —
    // see prepareSecurityScriptletDirectives() below and
    // scripting-manager.js's own computation of both booleans.
    {
        key: 'worryFreeAntiFingerprintEnabled',
        id:  'sec-tz-fingerprint',
        worryFreeAntiFingerprintOverride: true,
    },
    {
        key: 'worryFreeAntiFingerprintEnabled',
        id:  'sec-battery',
        worryFreeAntiFingerprintOverride: true,
    },
];

// ── directive builder ─────────────────────────────────────────────────────────

// All security scriptlets are written as standalone files in js/security/.
// browser.scripting.registerContentScripts expects js as an array of file
// path strings — inline {code} objects are not supported in Brave MV3.

// ── Built-in default exclusions ─────────────────────────────────────────────
//
// Separate from securityAllowlist (user-editable, per-toggle hostname list —
// see allowlistToExcludeMatches above): these are baked-in defaults, merged
// with whatever the user adds themselves, not shown/editable in the
// dashboard. Declared here, in one place, with the reasoning for each entry,
// per this project's config-in-one-place convention (see dnr-budgets.js).
//
// blockObfuscatedEval (sec-noeval): ASP.NET pages commonly deliver base64-
// encoded ViewState and other framework-generated inline scripts that trip
// this scriptlet's atob()/packer-style heuristics (see sec-noeval.js) as a
// false positive, breaking login/postback functionality. Excluded by URL
// path pattern, not hostname, since this needs to apply across every
// ASP.NET site, not a fixed list of them. Case variants included because
// Chrome match-pattern path matching is case-sensitive and login paths are
// capitalized inconsistently across sites (login/Login/LOGIN).
//
// blockWebGL (sec-canvas): a small, deliberately non-exhaustive list of
// mainstream services where WebGL is core rendering, not decoration —
// verified via each service's own documentation before adding, not assumed:
//   - figma.com: "Figma is built using WebGL... you will need to have this
//     enabled to use Figma" (Figma's own help docs) — the app doesn't
//     degrade without it, it fails to render at all.
//   - maps.google.com / earth.google.com: Google's Maps JavaScript API
//     WebGL Overlay View is the current rendering path for the vector
//     basemap and 3D buildings (Google's own developer docs).
// This can't be exhaustive — most other legitimate WebGL usage happens on
// the long tail of the web via generic libraries (Mapbox/MapLibre/Three.js)
// embedded in thousands of individual sites, which no hardcoded list can
// capture. For anything beyond this baseline, use the dashboard's per-
// toggle allowlist (securityAllowlist) instead of expecting this list to
// grow indefinitely.
//
// NOTE — orphaned, flagged for follow-up: js/security/sec-canvas.js
// (blockWebGL) and js/security/sec-nowebrtc.js (blockWebRTC) are complete,
// real scriptlet files on disk, but neither has a SECURITY_SCRIPTLETS entry,
// a securityConfig default, or a dashboard checkbox — so neither is ever
// registered or runs. The WEBGL_EXCLUDES list this paragraph describes was
// never added either. Not touched here since wiring up two new toggles is
// a feature decision, not a docs/dead-code cleanup — see chat for options.
//
// blockObfuscatedEval (sec-noeval), continued: streaming-media and gaming
// platforms commonly eval large first-party bundles (player/DRM/anti-cheat
// code) that legitimately contain long base64 blobs or char-code-encoded
// strings — the same shape the tightened v6.1.3 heuristic in sec-noeval.js
// still has to allow real obfuscated payloads to resemble. Confirmed false
// positive: youtube.com (see sec-noeval.js changelog note). Excluded by
// hostname, since — unlike the ASP.NET case — this genuinely is a fixed,
// curated set of specific platforms, not a pattern that applies site-wide.
// Deliberately non-exhaustive, same convention as the WebGL reasoning
// above: for anything else, use the dashboard's per-toggle allowlist
// (securityAllowlist) instead of expecting this list to grow indefinitely.
const STREAMING_GAMING_EXCLUDES = [
    // video streaming
    '*://youtube.com/*', '*://*.youtube.com/*',
    '*://netflix.com/*', '*://*.netflix.com/*',
    '*://primevideo.com/*', '*://*.primevideo.com/*',
    '*://disneyplus.com/*', '*://*.disneyplus.com/*',
    '*://hulu.com/*', '*://*.hulu.com/*',
    '*://max.com/*', '*://*.max.com/*',
    '*://twitch.tv/*', '*://*.twitch.tv/*',
    // gaming platforms
    '*://store.steampowered.com/*', '*://*.steampowered.com/*',
    '*://steamcommunity.com/*', '*://*.steamcommunity.com/*',
    '*://epicgames.com/*', '*://*.epicgames.com/*',
    '*://battle.net/*', '*://*.battle.net/*',
    '*://xbox.com/*', '*://*.xbox.com/*',
];

const SECURITY_SCRIPTLET_BUILTIN_EXCLUDES = {
    blockObfuscatedEval: [
        '*://*/*login*', '*://*/*Login*', '*://*/*LOGIN*',
        '*://*/*.aspx*',
        ...STREAMING_GAMING_EXCLUDES,
    ],
};

// Shared high-risk ("adult") site match list — single source of truth,
// reused by both blockAdultNoEval (strict eval block) and
// blockAdultFingerprinting (all fingerprinting-detection mitigations). Keep
// this as the one place either toggle's site coverage is defined; adding a
// site here extends both toggles at once, exactly as intended.
//
// v8.3.6 — expanded from 12 to 23 domains, sourced from Semrush Traffic
// Analytics' "Most Visited Adult Websites in the World" ranking (July
// 2026, semrush.com/trending-websites/global/adult) plus cross-referenced
// competitor-comparison data for tnaflix.com. Deliberately curated, not a
// raw copy of Semrush's own "Adult" industry category — that category
// also includes general platforms that merely host some adult content
// (patreon.com, deviantart.com, yandex.com.tr, rutube.ru, dlsite.com) and
// unrelated tools misclassified alongside them (thepiratebay.org,
// similarsites.com, downloadhelper.net) — none of those belong in a list
// meant to scope "this domain IS an adult site," so they were excluded
// rather than included for a rounder count. Also deliberately did NOT
// pad this list with mirror/clone domains found while researching further
// (xnxx.tv, xnxx2.com, xnxx3.com, xnxx.health, xhaccess.com, etc.) —
// functionally near-duplicates of xnxx.com/xvideos.com of uneven
// provenance and quality, not a real expansion of distinct coverage.
const ADULT_SITE_MATCHES = [
    '*://pornhub.com/*', '*://*.pornhub.com/*',
    '*://xhamster.com/*', '*://*.xhamster.com/*',
    '*://xvideos.com/*', '*://*.xvideos.com/*',
    '*://xnxx.com/*', '*://*.xnxx.com/*',
    '*://eporner.com/*', '*://*.eporner.com/*',
    '*://redtube.com/*', '*://*.redtube.com/*',
    '*://tube8.com/*', '*://*.tube8.com/*',
    '*://xgroovy.com/*', '*://*.xgroovy.com/*',
    '*://xgroovy.tv/*', '*://*.xgroovy.tv/*',
    '*://youporn.com/*', '*://*.youporn.com/*',
    '*://spankbang.com/*', '*://*.spankbang.com/*',
    '*://porntrex.com/*', '*://*.porntrex.com/*',
    '*://onlyfans.com/*', '*://*.onlyfans.com/*',
    '*://theporndude.com/*', '*://*.theporndude.com/*',
    '*://xvideos.es/*', '*://*.xvideos.es/*',
    '*://xhamsterlive.com/*', '*://*.xhamsterlive.com/*',
    '*://fpo.xxx/*', '*://*.fpo.xxx/*',
    '*://qorno.com/*', '*://*.qorno.com/*',
    '*://pornpics.com/*', '*://*.pornpics.com/*',
    '*://f95zone.to/*', '*://*.f95zone.to/*',
    '*://xhamster19.com/*', '*://*.xhamster19.com/*',
    '*://beeg.com/*', '*://*.beeg.com/*',
    '*://tnaflix.com/*', '*://*.tnaflix.com/*',
    // DELIBERATE EXCEPTION (v8.4.10) — coveryourtracks.eff.org is EFF's own
    // fingerprinting-test tool, not an adult site. Added here specifically
    // so it gets the exact same full protection set (blockAdultNoEval +
    // all 6 blockAdultFingerprinting vectors) as the sites above during a
    // Worry-free session, replacing an earlier, narrower dedicated
    // scriptlet set that only covered a subset (see CHANGELOG for what
    // that was and why it was replaced). If this list is ever renamed
    // away from "adult" to something more general, this entry is exactly
    // why the more general name would already fit better.
    '*://coveryourtracks.eff.org/*', '*://*.coveryourtracks.eff.org/*',
];

const SECURITY_SCRIPTLET_BUILTIN_MATCHES = {
    blockAdultNoEval:         ADULT_SITE_MATCHES,
    blockAdultFingerprinting: ADULT_SITE_MATCHES,
};

// Builds the base matches/excludeMatches for ALL security scriptlets from
// the current per-site filtering mode (siteModes / filteringModeDetails —
// see js/core/site-mode-manager.js and mode-manager.js), so that disabling
// uBOL-stripped for a site also disables every security scriptlet on that
// site, not just DNR-based blocking.
//
// BUG FIXED: prepareSecurityScriptletDirectives() previously had NO
// awareness of per-site OFF mode at all — it only excluded hostnames from
// securityAllowlist (the manually-typed per-toggle list) and, since 4.1.4,
// SECURITY_SCRIPTLET_BUILTIN_EXCLUDES. Content-script registration via
// chrome.scripting is not gated by DNR rule priority the way network
// blocking is, so the site-mode "OFF" allowAllRequests DNR rule (see
// ruleset-manager.js's filteringModesToDNR) had zero effect on these
// scriptlets — e.g. the obfuscated-eval blocker kept running and could
// still hang a login page's inline script even with uBOL-stripped
// explicitly disabled for that site.
//
// Mirrors filteringModesToDNR's own none/basic duality (core/ruleset-
// manager.js) rather than inventing different reverse-mode semantics here:
// normally `none` (OFF-mode hostnames) becomes excludeMatches against an
// <all_urls> base; in reverse mode (`none` contains the 'all-urls'
// sentinel — filtering OFF everywhere by default), `basic` (the explicit
// exception hostnames) becomes the matches list directly instead.
export async function buildSiteModeMatchScope() {
    const { none, basic } = await getFilteringModeDetails();
    function toHostPatterns(hostnames) { return [ ...hostnames ].flatMap(hn => [ `*://${hn}/*`, `*://*.${hn}/*` ]); }

    if ( none.has('all-urls') ) {
        // basic always carries a bookkeeping 'all-urls' member (see
        // filter-manager.js's registerCustomFilters() for the full
        // explanation and the real bug this same leak caused there).
        // Harmless here specifically — toHostPatterns() doesn't special-
        // case that string, so it just generates one unmatchable
        // '*://all-urls/*' pattern entry — but stripped anyway for
        // consistency with the one place this actually mattered.
        const realBasic = [ ...basic ].filter(hn => hn !== 'all-urls');
        return { matches: toHostPatterns(realBasic), excludeMatches: [] };
    }
    return { matches: [ '<all_urls>' ], excludeMatches: toHostPatterns(none) };
}

// isWorryFreeActive (v8.3.12) — passed in by the caller (scripting-
// manager.js's registerSecurityContentScriptsImpl()) rather than read
// here, deliberately: this module stays a pure data layer (no Chrome API
// calls, no storage I/O — see this file's own header), and importing
// cookie-clicker-autodeny-manager.js's getAutoDenyState() directly would
// create a circular dependency anyway (that module already imports FROM
// scripting-manager.js, which imports FROM this file — see js/core/
// worry-free-extra-manager.js's own header for the identical problem,
// solved the identical way, when this same class of cycle came up there).
//
// isWorryFreeAntiFingerprintActive — a SEPARATE gate from isWorryFreeActive
// above, deliberately not folded into it: the timezone/battery pair's own
// toggle lives in the Filter (block) lists panel, independent of
// worryFreeSecurityProtectionsEnabled (the Security & Privacy tab's own
// master switch, which gates isWorryFreeActive). Conflating the two would
// make this new toggle silently depend on that unrelated one being left
// on — see the SECURITY_SCRIPTLETS entries themselves for the full
// reasoning.
// Porting note (v9.4.9, item 3): third parameter, precomputedScope, added
// — used instead of calling buildSiteModeMatchScope() below if provided.
// This function has exactly one caller (registerSecurityContentScriptsImpl()
// in scripting-manager.js), so passing this as a plain optional parameter
// is safe; a shared context object would NOT be, since several of the
// OTHER functions independently calling buildSiteModeMatchScope() (see
// that function's own comment) are also called on their own from many
// places outside the orchestrator's batch — this one just happens to have
// a single caller today.
async function prepareSecurityScriptletDirectives(isWorryFreeActive = false, isWorryFreeAntiFingerprintActive = false, precomputedScope) {
    const active = SECURITY_SCRIPTLETS.filter(s => {
        if ( s.worryFreeAntiFingerprintOverride === true ) {
            // No independent on/off state of their own — see this
            // entry's own comment above. Active ONLY during an active,
            // opted-in Worry-free session, never otherwise.
            return isWorryFreeAntiFingerprintActive === true;
        }
        // BRAVE VARIANT — worryFreeGatedOptOut: only ever active during
        // Worry-free (unlike worryFreeOverride below, this has no
        // "manually always-on" path at all) — the checkbox is a genuine
        // opt-out of the gated behavior, not an independent switch. See
        // this entry's own comment in SECURITY_SCRIPTLETS above.
        if ( s.worryFreeGatedOptOut === true ) {
            return isWorryFreeActive === true && securityConfig[s.key] !== false;
        }
        return securityConfig[s.key] === true ||
            (isWorryFreeActive === true && s.worryFreeOverride === true);
    });
    if ( active.length === 0 ) { return []; }

    const { matches: siteModeMatches, excludeMatches: siteModeExcludes } = precomputedScope ?? await buildSiteModeMatchScope();
    // Reverse mode with no basic-mode exceptions at all: nowhere to inject.
    if ( siteModeMatches.length === 0 ) { return []; }

    // BRAVE VARIANT — blockScpFingerprint's own exclude list, computed
    // once per call (not per-directive — nothing else needs it), only
    // when that entry is actually active, to avoid the extra
    // localRead() familiar-TLD lookup on every single call to this
    // function for every OTHER, unrelated security scriptlet. Converts
    // each familiar TLD into a '*.tld*'-style exclude pattern, the same
    // wildcard shape worry-free-familiar-tld-manager.js's own DNR rules
    // already use for the identical "familiar region" concept — one
    // TLD-to-URL-pattern convention across both mechanisms, not two.
    let scpFingerprintExcludes = null;
    if ( active.some(s => s.key === 'blockScpFingerprint') ) {
        const tldsText = await getFamiliarTlds();
        scpFingerprintExcludes = tldsText.split(/[,\s]+/)
            .map(t => t.trim().toLowerCase())
            .filter(t => t !== '')
            .map(t => `*://*.${t}/*`);
    }

    const directives = [];
    for ( const s of active ) {
        const directive = {
            id: s.id,
            world: 'MAIN',
            allFrames: true,
            js: [ `/js/security/${s.scriptFile ?? s.id}.js` ],
            runAt: 'document_start',
            matches: SECURITY_SCRIPTLET_BUILTIN_MATCHES[s.key] ?? siteModeMatches,
        };
        const excl = [
            ...siteModeExcludes,
            ...(SECURITY_SCRIPTLET_BUILTIN_EXCLUDES[s.key] ?? []),
            ...allowlistToExcludeMatches(securityAllowlist[s.key]),
            ...(s.key === 'blockScpFingerprint' ? scpFingerprintExcludes : []),
        ];
        if ( excl.length > 0 ) {
            directive.excludeMatches = excl;
        }
        directives.push(directive);
    }
    return directives;
}
/******************************************************************************/

// How long to wait for the offscreen document to finish compiling filters
// before giving up. Generous on purpose: this runs rarely (only when the
// compiled custom-filter selectors actually change) and involves
// fetching/bundling several support files (see toMv3Data() in
// offscreen/compile-filters.js).
const OFFSCREEN_COMPILE_TIMEOUT_MS = 60000;

/******************************************************************************/


/******************************************************************************/

async function getUserList() {
    const customFilters = await getAllCustomFilters();
    const lines = [];
    for ( const [ hostname, selectors ] of customFilters ) {
        for ( const selector of selectors ) {
            if ( isScriptlet(selector) === false ) { continue; }
            lines.push(`${hostname}##${selector}`);
        }
    }
    return lines.join('\n').trim();
}

/******************************************************************************/

async function parseRawFilters() {
    const {
        promise: offscreenPromise,
        resolve: offscreenResolve,
    } = Promise.withResolvers();
    function handler(request, sender, callback) {
        if ( typeof request !== 'object' ) { return; }
        switch ( request?.what ) {
        case 'compileFilters:getResourceTypes':
            callback(Object.values(dnr.ResourceType));
            break;
        case 'compileFilters:getUserList':
            getUserList().then(text => {
                callback(text);
            });
            return true;
        case 'compileFilters:result':
            offscreenResolve(request);
            break;
        default:
            break;
        }
    }
    runtime.onMessage.addListener(handler);
    let timeoutId;
    const {
        promise: timeoutPromise,
        resolve: timeoutResolve,
    } = Promise.withResolvers();
    timeoutId = self.setTimeout(timeoutResolve, OFFSCREEN_COMPILE_TIMEOUT_MS);
    try {
        const [ result ] = await Promise.all([
            Promise.race([ offscreenPromise, timeoutPromise ]),
            createOffscreenDocument('/js/offscreen/compile-filters.html'),
        ]);
        return result;
    } catch {
    } finally {
        self.clearTimeout(timeoutId);
        runtime.onMessage.removeListener(handler);
        await closeOffscreenDocument();
    }
}

/******************************************************************************/

// prepareUserScripts / saveUserScripts / readUserScripts removed in v3.12.
// getUserList() (above) only produces DNR rules (network/cosmetic only)
// from this offscreen compile. This offscreen compiler's own MAIN/ISOLATED
// scriptlet-shaped output is unused — that shape was for chrome.userScripts
// registration, and the userScripts permission has been removed from the
// manifest.
//
// This does NOT mean scriptlet rules go unsupported: the scriptlet-shaped
// selectors getUserList() feeds in here (`hostname##name(args)` lines built
// from site.* custom-filter entries) are ALSO independently dispatched by
// the separate custom-scriptlets.js pipeline via chrome.scripting.executeScript
// — see that file's header. The two pipelines read the same source data for
// two different purposes: this one only cares about any DNR-compilable
// network-rule side effects; custom-scriptlets.js is what actually runs the
// scriptlet.

/******************************************************************************/

async function saveSandboxDnrRules(rules) {
    const storageId = 'sandboxFilters.dnrRules';
    const beforeRules = await localRead(storageId);
    const afterRules = rules?.length && rules;
    const modified = JSON.stringify(afterRules) !== JSON.stringify(beforeRules);
    if ( modified === false ) { return false; }
    if ( Array.isArray(afterRules) ) {
        await localWrite(storageId, afterRules);
    } else {
        await localRemove(storageId);
    }
    return true;
}

/******************************************************************************/

// update() — compile the scriptlet-shaped site.* selectors getUserList()
// returns and save DNR rules only. MAIN/ISOLATED scriptlet output from this
// offscreen compiler is intentionally ignored (userScripts permission
// removed, v3.12) — but scriptlet rules themselves ARE dispatched, via the
// separate custom-scriptlets.js/executeScript pipeline described above.
async function update() {
    const hasUserFilters = await getUserList().then(a => Boolean(a));

    let result;
    if ( hasUserFilters ) {
        result = await parseRawFilters();
        if ( Boolean(result) === false ) { return; }
    }

    await saveSandboxDnrRules(result?.sandbox?.dnrRules);
}

/******************************************************************************/

// This recompiles the scriptlet-shaped selectors and saves DNR rules.
export async function updateCompiledFilters() {
    pendingRegister = pendingRegister.then(( ) => update());
    return pendingRegister;
}

// prepareSecurityScriptletDirectives is consumed by scripting-manager.js,
// which owns all browser.scripting registrations (single registration layer).
export { prepareSecurityScriptletDirectives };

/******************************************************************************/

// `pendingRegister` is a promise chain used as a serialisation lock — it
// prevents concurrent compile/register calls from interleaving.
let pendingRegister = Promise.resolve();
