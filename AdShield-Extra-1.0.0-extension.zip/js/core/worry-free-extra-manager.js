/*******************************************************************************

    uBlock-Stripped-Dynamic — Worry-free extra suppression rule manager

    Manages ELEVEN independent session-scoped chrome.declarativeNetRequest
    suppression rules, in TWO different shapes:

    UNCONDITIONAL (six rules, v8.5.8 split / v8.6.12 sixth added) — plain
    `condition: {}` allow at WORRY_FREE_EXTRA_ALLOW_PRIORITY (150). Safe
    ONLY because these six are gated behind just TWO real settings
    (worryFreeBlocklistEnabled, worryFreeSecurityTldProtectionsEnabled —
    v8.6.13 consolidation), never independently toggleable one-by-one —
    an unconditional allow doesn't distinguish "the requests THIS item
    would have blocked" from "everything at this priority tier or below",
    so if these were each independently toggleable, turning one off could
    silently suppress its siblings too. See js/data/config.js's own
    header on worryFreeBlocklistEnabled for the full incident history.

    DOMAIN-SCOPED (five rules, v9.1.4) — condition.requestDomains set to
    exactly that item's own ruleset's domain list, read at runtime from
    the bundled ruleset JSON (same fetch(runtime.getURL(...)) pattern
    static-block-check.js already established — C21, reused not
    reinvented). Because each of these five's suppression rule can only
    ever match its OWN domains, they're safe to make independently
    toggleable (five separate settings) without the cross-contamination
    risk the six unconditional rules above have — this is the actual fix
    for that bug class, not just avoiding it by keeping things grouped.

    Design: present by default (normal browsing), absent for the
    duration of an active Worry-free/"Never consent" session AND the
    corresponding setting being enabled — matching
    js/core/cookie-clicker-autodeny-manager.js's own active/inactive
    state, since that IS the same session.

    Session rules reset to empty on a genuine browser restart (MDN: "not
    persisted across browser sessions") — unlike this session's own
    Worry-free active/inactive state, which DOES persist (chrome.
    storage.local, via cookie-clicker-autodeny-manager.js). That means a
    real restart can leave the two out of sync (rule gone, but a session
    was still supposed to be active, or vice versa) — reconcile(), below,
    is the one place that re-derives the correct rule state FROM the
    persisted session state, called at every point that could plausibly
    have left them mismatched (extension start, browser startup, and
    directly from every session state transition) rather than assumed
    correct from whatever ran last.

*******************************************************************************/

import { dnr } from '../data/ext-compat.js';
import { browser } from '../data/ext.js';
import {
    WORRY_FREE_3PBLOCK_RULES_BASE_ID, WORRY_FREE_TLDALLOW_RULES_BASE_ID,
    WORRY_FREE_DOWNLOADBLOCK_RULES_BASE_ID, WORRY_FREE_DOWNLOAD_TLDALLOW_RULES_BASE_ID,
    WORRY_FREE_ADGUARD_TRACKING_RULES_BASE_ID, WORRY_FREE_EASYLIST_ADSERVERS_RULES_BASE_ID,
    WORRY_FREE_PETERLOWE_RULES_BASE_ID, WORRY_FREE_DISCONNECT_OTHER_RULES_BASE_ID,
    WORRY_FREE_EXTRA_ALLOW_PRIORITY,
} from './dnr-budgets.js';
import { securityConfig } from '../data/config.js';
// Deliberately NOT importing getAutoDenyState() from
// cookie-clicker-autodeny-manager.js here — that module needs to call
// INTO this one (onWorryFreeSessionStart/End, from its own startAutoDeny/
// cancelAutoDeny/expireAutoDeny), and a reverse import back would be a
// genuine circular dependency (core/cookie-clicker-autodeny-manager.js
// -> core/worry-free-extra-manager.js -> core/cookie-clicker-autodeny-
// manager.js). reconcile() below takes the active state as a parameter
// instead — callers that already sit above both modules in the layering
// (js/workflow/*) fetch it once and pass it in.

/******************************************************************************/
// Config — declared once, here.
/******************************************************************************/

// The six unconditional-suppression items — UNCHANGED shape, still only
// ever gated behind the same two grouped settings. Do NOT add a new
// entry here with its own independent settingKey — see this file's own
// header for why that combination is unsafe. New independently-
// toggleable items belong in SCOPED_SUPPRESSION_RULES below instead.
const SUPPRESSION_RULES = [
    { id: WORRY_FREE_3PBLOCK_RULES_BASE_ID,  settingKey: 'worryFreeSecurityTldProtectionsEnabled' },
    { id: WORRY_FREE_TLDALLOW_RULES_BASE_ID, settingKey: 'worryFreeSecurityTldProtectionsEnabled' },
    { id: WORRY_FREE_DOWNLOADBLOCK_RULES_BASE_ID,     settingKey: 'worryFreeSecurityTldProtectionsEnabled' },
    { id: WORRY_FREE_DOWNLOAD_TLDALLOW_RULES_BASE_ID, settingKey: 'worryFreeSecurityTldProtectionsEnabled' },
];

// The four domain-scoped, independently-toggleable items (was five —
// ruleset_ghostery_other removed entirely, see CHANGELOG).
// `rulesetPath` points at the bundled static ruleset JSON whose domains
// this suppression rule must mirror exactly — see getRulesetRequestDomains()
// below. Each has its OWN settingKey (see config.js).
const SCOPED_SUPPRESSION_RULES = [
    { id: WORRY_FREE_ADGUARD_TRACKING_RULES_BASE_ID,  settingKey: 'worryFreeAdguardTrackingEnabled',   rulesetPath: '/rulesets/ruleset_adguard_tracking_servers.json' },
    { id: WORRY_FREE_EASYLIST_ADSERVERS_RULES_BASE_ID, settingKey: 'worryFreeEasylistAdserversEnabled', rulesetPath: '/rulesets/ruleset_easylist_adservers.json' },
    { id: WORRY_FREE_PETERLOWE_RULES_BASE_ID,          settingKey: 'worryFreePeterloweEnabled',         rulesetPath: '/rulesets/ruleset_peterlowe.json' },
    { id: WORRY_FREE_DISCONNECT_OTHER_RULES_BASE_ID,   settingKey: 'worryFreeDisconnectOtherEnabled',   rulesetPath: '/rulesets/ruleset_disconnect_other.json' },
];

/******************************************************************************/
// Domain lookup for the scoped suppression rules — reads the actual
// bundled ruleset JSON at runtime (fetch(runtime.getURL(...)), same
// pattern static-block-check.js already established for exactly this
// kind of "read a shipped ruleset file's own rules" need — C21, reused
// not reinvented). Cached per path: the bundled file's content never
// changes at runtime, only between builds, so one fetch per session is
// enough.
/******************************************************************************/

const rulesetDomainsCache = new Map();  // path -> string[] (or null on failure)

async function getRulesetRequestDomains(rulesetPath) {
    if ( rulesetDomainsCache.has(rulesetPath) ) {
        return rulesetDomainsCache.get(rulesetPath);
    }
    let domains = null;
    try {
        const res = await fetch(browser.runtime.getURL(rulesetPath));
        const rules = await res.json();
        const set = new Set();
        for ( const rule of rules ) {
            if ( rule.action?.type !== 'block' ) { continue; }
            for ( const d of (rule.condition?.requestDomains ?? []) ) { set.add(d); }
        }
        domains = [ ...set ];
    } catch (reason) {
        console.error(`[uBlock-Dynamic] worry-free-extra-manager/getRulesetRequestDomains(${rulesetPath}):`, reason);
    }
    rulesetDomainsCache.set(rulesetPath, domains);
    return domains;
}

/******************************************************************************/

function buildUnconditionalSuppressionRule(id) {
    return {
        id,
        priority: WORRY_FREE_EXTRA_ALLOW_PRIORITY,
        action: { type: 'allow' },
        // Unconditional — matches every request. Safe specifically because
        // its priority (150) only reaches high enough to outrank the
        // reserved tier (100/110) and nothing above it (normal filter
        // lists sit at 1 000), AND because these six are never
        // independently toggleable — see this file's own header.
        condition: {},
    };
}

// Scoped variant — condition.requestDomains limits this allow rule to
// EXACTLY the domains its own ruleset blocks, so turning this one item
// off can never suppress a sibling item's blocking too. Returns null if
// the domain list couldn't be read (caller must treat that as "leave
// this rule's state alone this pass" — see reconcile() below).
async function buildScopedSuppressionRule(id, rulesetPath) {
    const domains = await getRulesetRequestDomains(rulesetPath);
    if ( domains === null || domains.length === 0 ) { return null; }
    return {
        id,
        priority: WORRY_FREE_EXTRA_ALLOW_PRIORITY,
        action: { type: 'allow' },
        condition: { requestDomains: domains },
    };
}

async function presentSuppressionRuleIds() {
    let rules = [];
    try {
        rules = await dnr.getSessionRules();
    } catch {
        return null; // couldn't determine — reconcile() treats this as "do nothing"
    }
    const ids = new Set([
        ...SUPPRESSION_RULES.map(s => s.id),
        ...SCOPED_SUPPRESSION_RULES.map(s => s.id),
    ]);
    return new Set(rules.filter(r => ids.has(r.id)).map(r => r.id));
}

/******************************************************************************/
// Public interface
/******************************************************************************/

// Called directly from startAutoDeny() — the session is becoming active
// RIGHT NOW. For each item, the suppression rule comes off ONLY if its
// own setting is currently enabled (default true) — if the person turned
// one off, that item simply never activates for this session, same as if
// it didn't exist.
//
// BUG FIX (v8.6.6): this used to build addRules/removeRuleIds purely
// from `securityConfig[settingKey]`, with no check for what dnr.
// getSessionRules() actually had registered. If a suppression rule that
// "should be (re-)added" per settings was already present — plausible
// any time this ran without a matching prior removal, e.g. after a
// stale/mismatched state from an earlier session — the blind add threw
// "Rule with id N does not have a unique ID." reconcileWorryFree
// ExtraSuppressionRule() below already solves exactly this (it diffs
// against presentSuppressionRuleIds() before deciding what to touch);
// this is that same target state (`isActive: true`), so delegating to
// it (C21 — reuse the proven fix already in this file) removes the
// duplicated, buggy logic instead of patching it a second time.
export async function onWorryFreeSessionStart() {
    return reconcileWorryFreeExtraSuppressionRule(true, 'onWorryFreeSessionStart');
}

// Called directly from cancelAutoDeny()/expireAutoDeny() — the session
// just ended, so every suppression rule must go back on immediately,
// regardless of each item's own setting (nothing from this tier should
// ever be active outside a session).
//
// BUG FIX (v8.6.6): same defect and same fix shape as onWorryFree
// SessionStart() above — this used to unconditionally push all five
// rules into addRules with no removeRuleIds and no presence check,
// which throws the identical "not a unique ID" error the moment any of
// the five is already registered. `isActive: false` here makes every
// rule's shouldBePresent true regardless of settingKey — same end
// target as the original unconditional add — but now diffed safely
// against what's actually present first.
export async function onWorryFreeSessionEnd() {
    return reconcileWorryFreeExtraSuppressionRule(false, 'onWorryFreeSessionEnd');
}

// Re-derives the correct rule state from the persisted session state (and,
// while active, each item's own setting) and fixes any mismatch. Takes
// `isActive` as a parameter rather than fetching it itself — see this
// file's own header on why (avoiding a circular import with cookie-
// clicker-autodeny-manager.js). Called at extension start and at browser
// startup — the two points a genuine browser restart (which wipes session
// rules, but not the persisted active/inactive state) could plausibly
// have left the two out of sync. Idempotent and safe to call at any other
// time too (a plain SW wakeup, where session rules already survived
// correctly, costs one no-op read-and-compare).
//
// `label` (optional, defaults to this function's own name) lets
// onWorryFreeSessionStart()/onWorryFreeSessionEnd() above delegate here
// while keeping their own, caller-specific console.error prefix — so a
// future error still says which entry point triggered it, not just
// "reconcile", even though there's now only one real implementation.
export async function reconcileWorryFreeExtraSuppressionRule(isActive, label = 'reconcile') {
    const present = await presentSuppressionRuleIds();
    if ( present === null ) { return; } // couldn't read session rules — leave alone
    const addRules = [];
    const removeRuleIds = [];

    for ( const { id, settingKey } of SUPPRESSION_RULES ) {
        const shouldBePresent = isActive !== true || securityConfig[settingKey] === false;
        const isPresent = present.has(id);
        if ( shouldBePresent && !isPresent ) { addRules.push(buildUnconditionalSuppressionRule(id)); }
        else if ( !shouldBePresent && isPresent ) { removeRuleIds.push(id); }
    }

    // Scoped rules need an async domain lookup per item — done in
    // parallel, same reasoning as static-block-check.js's own
    // Promise.all over its bundled-file reads.
    await Promise.all(SCOPED_SUPPRESSION_RULES.map(async ({ id, settingKey, rulesetPath }) => {
        const shouldBePresent = isActive !== true || securityConfig[settingKey] === false;
        const isPresent = present.has(id);
        if ( shouldBePresent && !isPresent ) {
            const rule = await buildScopedSuppressionRule(id, rulesetPath);
            // null means the domain list couldn't be read this pass —
            // leave this one rule's state alone rather than add a
            // suppression rule with no domains (which would suppress
            // nothing, silently making this item behave as if its
            // setting were off without actually reflecting that anywhere).
            if ( rule !== null ) { addRules.push(rule); }
        } else if ( !shouldBePresent && isPresent ) {
            removeRuleIds.push(id);
        }
    }));

    if ( addRules.length === 0 && removeRuleIds.length === 0 ) { return; }
    try {
        await dnr.updateSessionRules({ addRules, removeRuleIds });
    } catch (reason) {
        console.error(`[uBlock-Dynamic] worry-free-extra-manager ${label}:`, reason);
    }
}
