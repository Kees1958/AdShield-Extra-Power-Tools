import { sendMessage } from '../js/data/ext.js';
import { qs$ } from '../js/ui/dom.js';

/******************************************************************************/
// Static ruleset toggles + language filter dropdown
/******************************************************************************/

import {
    MSG_GET_ENABLED_RULESETS,
    MSG_SET_RULESET_ENABLED,
} from '../js/data/message-types.js';

// The 7 always-on "Built-in filter lists" ruleset ids — every one has its
// own hardcoded checkbox row directly in dashboard.html now (BRAVE
// VARIANT: all filters always-on, no session-scoping), so this is no
// longer an id->label map for dynamically rendering rows — just the set
// updateDefaultFiltersSummary() below sums over. 'ruleset_badfilter_
// quickfixes' is deliberately NOT included here — it has no checkbox row
// in the DOM at all (see dashboard.html's own comment on this), so
// nothing would ever query it anyway.
const DEFAULT_FILTER_IDS = [
    'ruleset_disconnect_other',
    'ruleset_adguard_antiadblock',
    'ruleset_antiadmiral',
];

/******************************************************************************/

/******************************************************************************/
// Default filter rows + aggregate "N domains blocked with N rules" summary
/******************************************************************************/

// ruleset-details.json is a build-time-generated, bundled extension file
// (tools/build-rulesets.mjs writes it fresh every build — domainCount/
// paramCount/ruleCount are real numbers from what was actually shipped,
// not estimated) — fetched directly via its extension-relative path
// since dashboard.html is itself an extension page (no web_accessible_
// resources entry needed; that's only required for a regular web page to
// reach an extension file, not for the extension's own pages).
//
// BUG FIX (v9.2.0): initRulesetToggles() and initWorryFreeToggles() both
// call this independently, fired at module scope without awaiting each
// other — genuinely concurrent. The previous version marked the cache
// "ready" (rulesetDetailsById = new Map()) BEFORE the fetch actually
// completed, so whichever caller's own await landed second saw an
// already-non-null (but still empty) Map and returned it immediately —
// permanently reading 0 for every count, with nothing to ever retry it.
// Fixed by caching the in-flight PROMISE itself (same pattern static-
// block-check.js's buildPromise already uses for this exact "concurrent
// callers share one fetch pass" shape — C21, reused not reinvented):
// every caller awaits the SAME promise, so nobody can observe a
// not-yet-populated result.
let rulesetDetailsPromise = null;

async function loadRulesetDetails() {
    if ( rulesetDetailsPromise !== null ) { return rulesetDetailsPromise; }
    rulesetDetailsPromise = (async () => {
        const map = new Map();
        try {
            const resp = await fetch('../rulesets/ruleset-details.json');
            const list = await resp.json();
            for ( const entry of list ) {
                map.set(entry.id, entry);
            }
        } catch (reason) {
            console.error('[uBlock-Dynamic] filter-manager-ui/loadRulesetDetails:', reason);
        }
        return map;
    })();
    return rulesetDetailsPromise;
}

// Render one default-filter row — plain checkbox + label, same markup
// shape as the Worry-free section's static rows (not the toggle-switch
// styling — that's kept only for language filters, which are dynamically
// added/removed from a dropdown and pair naturally with a switch + remove
// button; these 7 are permanent, always-visible rows, so a plain
// checkbox matches the rest of this panel instead).
// Sums rawLineCount/ruleCount across only the CURRENTLY-ENABLED default
// filters (not all 7 unconditionally) — "blocked" should reflect what's
// actually active right now, and this is meant to double as a live
// debugging aid: toggle a list off, watch the totals drop, confirm which
// source a given number of lines/rules came from. Deliberately
// rawLineCount, NOT domainCount — see this function's own inline comment
// below for why domainCount was misleading for a list like AdGuard Base.
async function updateDefaultFiltersSummary() {
    const el = qs$('#defaultFiltersSummary');
    if ( !el ) { return; }
    const details = await loadRulesetDetails();
    let rawLines = 0;
    let rules = 0;
    for ( const id of DEFAULT_FILTER_IDS ) {
        const cb = document.querySelector(`.ruleset-toggle[data-ruleset="${id}"]`);
        if ( !cb || cb.checked !== true ) { continue; }
        const entry = details.get(id);
        if ( !entry ) { continue; }
        rawLines += entry.rawLineCount ?? 0;
        rules    += entry.ruleCount ?? 0;
    }
    // "Raw filter lines" vs "DNR rules" — deliberately NOT domainCount,
    // per explicit request: domainCount only counts the coalesced-
    // domain-shaped subset of rules (ruleset_adguard_base has 8,949 DNR
    // rules but only 1,314 domainCount, since most of its rules are
    // per-URL-path patterns, not plain domain blocks — domainCount was
    // silently understating it). rawLineCount is honest for ANY list
    // shape: every non-comment, non-header line actually fetched from
    // upstream, computed once at build time (tools/build-rulesets.mjs),
    // never re-derived here.
    el.textContent = `Total of ${rawLines.toLocaleString()} raw filter lines blocked with ` +
        `DNR ${rules.toLocaleString()} rules `;
    // Native title-attribute tooltip — same mechanism matrix/matrix-
    // panel.js already uses for its own hover explanations (td.title =
    // ...), not a custom dropdown component (C21: reused, not a second,
    // different-looking mechanism for the same job).
    const marker = document.createElement('span');
    marker.className = 'static-filter-footnote-marker';
    marker.textContent = '.';
    marker.title = 'Included default lists are well curated ad and tracking-network block lists which are not listed in Brave\'s own Shields.';
    el.appendChild(marker);
}

/******************************************************************************/

async function initRulesetToggles() {
    const enabled = await sendMessage({ what: MSG_GET_ENABLED_RULESETS });
    const enabledSet = new Set(Array.isArray(enabled) ? enabled : []);

    updateDefaultFiltersSummary();

    // Core static filter checkboxes (always-visible rows in HTML)
    for ( const cb of document.querySelectorAll('.ruleset-toggle') ) {
        cb.checked  = enabledSet.has(cb.dataset.ruleset);
        cb.disabled = false;

        cb.addEventListener('change', async () => {
            cb.disabled = true;
            await sendMessage({
                what:    MSG_SET_RULESET_ENABLED,
                id:      cb.dataset.ruleset,
                enabled: cb.checked,
            });
            cb.disabled = false;
            // Every .ruleset-toggle on this page is one of the 7
            // Built-in filter list rows now (BRAVE VARIANT — no other
            // checkbox on this pane uses this class), so this always
            // has something to recompute.
            updateDefaultFiltersSummary();
        });
    }
}

initRulesetToggles();

// "Block login-with" — feature removed entirely in v8.5.7, per explicit
// request (see CHANGELOG). Previously (v8.3.16) only its manual checkbox
// had been removed while the underlying toggle stayed driven
// automatically by Worry-free mode; now the whole mechanism is gone —
// see js/core/ruleset-manager.js and js/core/dnr-budgets.js's
// LOGIN_WITH_RULES_RETIRED_BASE_ID for the migration cleanup this left
// behind for existing installs.

/******************************************************************************/
// Worry-free section checkboxes (v8.5.8: generalized from the single
// "Enable ... at browser startup" wiring, v8.5.5, to cover all four rows
// now that each is independently toggleable; a 5th row —
// worryFreeAntiFingerprintEnabled — added later, default OFF unlike the
// others) — all five are plain securityConfig keys, all reuse the
// existing getSecurityConfig/setSecurityConfig message routes rather
// than new plumbing per checkbox. Each one's own default already lives
// in config.js itself — this function just reflects whatever that
// default (or the person's own saved choice) is, never assumes one here.
/******************************************************************************/

const WORRY_FREE_TOGGLE_IDS = [
    [ 'worryFreeSecurityProtectionsToggle', 'worryFreeSecurityProtectionsEnabled' ],
    [ 'worryFreeSecurityTldProtectionsToggle', 'worryFreeSecurityTldProtectionsEnabled' ],
    [ 'worryFreeAntiFingerprintToggle', 'worryFreeAntiFingerprintEnabled' ],
    [ 'startWorryFreeOnBrowserStartupToggle', 'startWorryFreeOnBrowserStartup' ],
];

// BRAVE VARIANT — WORRY_FREE_BLOCKLIST_RULESET_IDS / updateWorryFreeFiltersSummary()
// removed entirely: AdGuard tracking servers, Easylist adservers, Peter
// Lowe's, and Disconnect all moved to the always-on "Built-in filter
// lists" section (see updateDefaultFiltersSummary() above, which now
// covers all 7 lists) per explicit request — nothing left in the
// Worry-free settings section has a domainCount/ruleCount to summarize,
// so #worryFreeFiltersSummary was removed from dashboard.html too.

async function initWorryFreeToggles() {
    const config = await sendMessage({ what: 'getSecurityConfig' });
    for ( const [ elementId, settingKey ] of WORRY_FREE_TOGGLE_IDS ) {
        const cb = qs$(`#${elementId}`);
        if ( !cb ) { continue; }
        cb.checked = config?.[settingKey] === true;
        cb.addEventListener('change', async ( ) => {
            cb.disabled = true;
            try {
                await sendMessage({ what: 'setSecurityConfig', key: settingKey, value: cb.checked });
            } finally {
                cb.disabled = false;
            }
        });
    }

    // TLD-protection row's hover tooltip — native title attribute on the
    // (*) marker, same mechanism matrix/matrix-panel.js already uses for
    // its own hover explanations, replacing both the old inline sub-
    // bullet list and the separate bottom footnote paragraph.
    const tldLabel = qs$('#worryFreeSecurityTldProtectionsLabel');
    if ( tldLabel ) {
        tldLabel.title = 'Blocks: third-party code (scripts and frames), and downloads, from domains outside the familiar/low-risk TLD list below. Edit that list directly to change which regions count as familiar.';
        tldLabel.style.cursor = 'help';
    }

    initWorryFreeTldEditor();
}

/******************************************************************************/
// Familiar-TLD editor — Cancel / restore TLD's / update TLD's.
/******************************************************************************/

// lastSavedText tracks what's actually persisted (not necessarily what's
// in the textarea right now) — Cancel reloads THIS, not the computed
// default, so an uncommitted edit can be discarded without losing a
// previously saved custom list. Module-scope, not a DOM data-attribute:
// simpler than round-tripping through the textarea's own value for a
// plain string only this one function needs.
let lastSavedTldsText = '';

async function initWorryFreeTldEditor() {
    const textarea = qs$('#worryFreeTldTextarea');
    const cancelBtn = qs$('#worryFreeTldCancelBtn');
    const restoreBtn = qs$('#worryFreeTldRestoreBtn');
    const updateBtn = qs$('#worryFreeTldUpdateBtn');
    if ( !textarea || !cancelBtn || !restoreBtn || !updateBtn ) { return; }

    lastSavedTldsText = await sendMessage({ what: 'getWorryFreeFamiliarTlds' }) ?? '';
    textarea.value = lastSavedTldsText;

    function setButtonsDisabled(disabled) {
        cancelBtn.disabled = disabled;
        restoreBtn.disabled = disabled;
        updateBtn.disabled = disabled;
    }

    cancelBtn.addEventListener('click', () => {
        // Discards any uncommitted edit — reloads the last SAVED value,
        // not the built-in default (that's restoreBtn's job below).
        textarea.value = lastSavedTldsText;
    });

    restoreBtn.addEventListener('click', async () => {
        setButtonsDisabled(true);
        try {
            const defaultText = await sendMessage({ what: 'restoreWorryFreeFamiliarTlds' });
            lastSavedTldsText = defaultText ?? '';
            textarea.value = lastSavedTldsText;
        } finally {
            setButtonsDisabled(false);
        }
    });

    updateBtn.addEventListener('click', async () => {
        setButtonsDisabled(true);
        try {
            const savedText = await sendMessage({ what: 'setWorryFreeFamiliarTlds', text: textarea.value });
            lastSavedTldsText = savedText ?? '';
            // Reflects back the normalized form (lowercased, deduped,
            // comma-joined) rather than leaving the person's raw typed
            // text in place — confirms what was actually saved.
            textarea.value = lastSavedTldsText;
        } finally {
            setButtonsDisabled(false);
        }
    });
}

initWorryFreeToggles();
