/*
 * domain-rule-detail.js — On-demand raw rule lookup for one domain
 *
 * Public interface:
 *   getDomainRuleDetail(domain) — scans every ENABLED static ruleset's
 *                                 compiled JSON, returns every rule that
 *                                 mentions this domain, as plain data
 *                                 (no priority/allow-override resolution
 *                                 — see below for why)
 *
 * WHY THIS EXISTS
 * matrix-panel.js's SHOW BLOCKED/ALLOWED view answers one coarse
 * question per domain: "is the whole domain blocked?" (see
 * static-block-check.js). That's wrong for a domain like xHamster's
 * phncdn.com, which has THREE narrow block rules on specific paths and
 * FOUR allow rules on other specific paths/domains under it — a single
 * yes/no can't represent that, and answering it correctly would require
 * real DNR-equivalent matching (urlFilter wildcards/anchors, priority
 * ordering, domainType) — a substantially larger undertaking, discussed
 * and deliberately deferred (see CHANGELOG). This module is the
 * DELIBERATELY SIMPLER first step of that: on click (Matrix panel's new
 * expand-row column), fetch every rule that MENTIONS this domain and let
 * the person read them directly — no attempt to compute a final verdict.
 * Cheap because it's on-demand (one domain, one click), not run
 * continuously across live traffic — same "expensive-but-accurate on
 * click, not always-on" reasoning already agreed for this feature.
 *
 * MATCHING HEURISTIC (deliberately permissive, not a real DNR matcher):
 * a rule "mentions" a domain if the domain is in its requestDomains
 * array (the coalesced-rule form — see static-block-check.js's own
 * requestDomains fix for why this matters), OR its urlFilter contains
 * the domain as a substring (covers both bare ||domain^ rules AND
 * path-specific ones like "phncdn.com, wildcard, pics/skins path"). This is
 * intentionally loose — a false-positive match (a rule that happens to
 * contain the domain string but wouldn't really apply) is an acceptable
 * cost for a "show me everything relevant, let the person judge" tool;
 * a false negative (hiding a genuinely relevant rule) is not.
 *
 * NOT included, on purpose, for this first pass:
 *   - priority ordering / resolving which rule actually wins
 *   - initiatorDomains/excludedInitiatorDomains matching against the
 *     CURRENT page (shown as raw data, not evaluated)
 *   - resourceType matching against what was actually observed
 * All of the above are exactly the "substantially larger undertaking"
 * scoped out of this pass — see CHANGELOG for the fuller discussion.
 */

import { browser } from '../data/ext.js';
import { getEnabledRulesets } from './static-rulesets.js';

/******************************************************************************/

// Deliberately NOT cached like static-block-check.js's blockedDomains —
// this runs once per explicit user click on one domain, not continuously
// across live traffic, so there's no repeated-cost problem to solve by
// caching, and caching would need its own invalidation story (ruleset
// toggles, etc.) for a feature that doesn't need it.
export async function getDomainRuleDetail(domain) {
    if ( typeof domain !== 'string' || domain === '' ) { return []; }
    const needle = domain.toLowerCase();

    const manifest = browser.runtime.getManifest();
    const resources = manifest.declarative_net_request?.rule_resources ?? [];
    const enabledIds = await getEnabledRulesets();

    const matches = [];

    await Promise.all(
        resources
            .filter(r => enabledIds.has(r.id))
            .map(async r => {
                try {
                    const res = await fetch(browser.runtime.getURL(r.path));
                    const rules = await res.json();
                    for ( const rule of rules ) {
                        const cond = rule.condition ?? {};
                        const requestDomains = Array.isArray(cond.requestDomains) ? cond.requestDomains : [];
                        const urlFilter = typeof cond.urlFilter === 'string' ? cond.urlFilter : '';
                        const mentionsDomain =
                            requestDomains.includes(needle) ||
                            urlFilter.toLowerCase().includes(needle);
                        if ( !mentionsDomain ) { continue; }
                        matches.push({
                            ruleset: r.id,
                            action: rule.action?.type ?? 'unknown',
                            priority: rule.priority ?? null,
                            urlFilter: urlFilter || null,
                            // Only surfaced when the coalesced array is
                            // small enough to be meaningful context —
                            // a 3000-domain array being "the pattern"
                            // for a match is noise, not signal.
                            requestDomainsCount: requestDomains.length > 0 ? requestDomains.length : null,
                            resourceTypes: cond.resourceTypes ?? null,
                            excludedResourceTypes: cond.excludedResourceTypes ?? null,
                            initiatorDomains: cond.initiatorDomains ?? null,
                            excludedInitiatorDomains: cond.excludedInitiatorDomains ?? null,
                            domainType: cond.domainType ?? null,
                        });
                    }
                } catch {
                    // One unreadable/malformed ruleset file shouldn't take
                    // down the whole lookup — skip it, keep the rest.
                }
            })
    );

    // Highest priority first — not a resolved verdict (see header), just
    // the most useful reading order for a person scanning the list by
    // hand, since a higher-priority rule is the one more likely to
    // actually matter if there's a conflict.
    matches.sort((a, b) => (b.priority ?? 0) - (a.priority ?? 0));
    return matches;
}
