/*
 * sec-dialogbuster.js — Security scriptlet: blockConfirmDialogs toggle
 *
 * Silences window.confirm() -> false and window.prompt() -> null.
 * Tech-support fraud sites loop these dialogs to lock the browser; false and
 * null are always the safe/cancel outcome for the calling page.
 * Source: originally scriptlets.js dialogBuster (uBO-lite resources).
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 *
 * Uses const/let, not var: this whole file's body sits inside the
 * (function(){...})() IIFE below, so each re-injection gets a fresh
 * function scope — no top-level redeclaration hazard to guard against.
 */
'use strict';
(function(){'use strict';
            function _makeDialogProxy(native, returnValue, label) {
                return new Proxy(native, {
                    apply: function(target, thisArg, args) {
                        console.info('[uBol] ' + label + ' blocked:', args[0]);
                        return returnValue;
                    },
                    get(target, prop) {
                        if ( prop === 'toString' ) { return target.toString.bind(target); }
                        return Reflect.get(target, prop);
                    },
                });
            }
            window.confirm = _makeDialogProxy(window.confirm, false,  'confirm');
            window.prompt  = _makeDialogProxy(window.prompt,  null,   'prompt');
        })();
