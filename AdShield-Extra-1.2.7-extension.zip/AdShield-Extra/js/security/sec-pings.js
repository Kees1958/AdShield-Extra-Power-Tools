/* Blocks hyperlink-auditing pings without affecting navigator.sendBeacon(). */
'use strict';
(function(){
    'use strict';
    function clearPing(anchor) {
        if ( anchor instanceof HTMLAnchorElement && anchor.hasAttribute('ping') ) {
            anchor.removeAttribute('ping');
        }
    }
    document.addEventListener('click', event => {
        clearPing(event.target?.closest?.('a[ping]'));
    }, true);
    document.addEventListener('auxclick', event => {
        clearPing(event.target?.closest?.('a[ping]'));
    }, true);
})();
