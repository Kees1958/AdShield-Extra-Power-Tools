/*
 * sec-adult-fingerprint.js — Security scriptlet: blockAdultFingerprinting toggle
 *
 * Applies fingerprinting-detection mitigations directly and unconditionally
 * to the same curated high-risk site list blockAdultNoEval already uses
 * (see SECURITY_SCRIPTLET_BUILTIN_MATCHES in compiled-filters.js — one
 * shared list, not a second copy of it): canvas/WebGL, navigator.plugins,
 * battery status, timezone, audio, WebRTC.
 *
 * Categories chosen per JShelter's own classification: canvas, WebGL,
 * battery status, timezone, and audio are all established fingerprinting
 * vectors in the literature, not just the "big 3" (canvas/audio/WebGL) —
 * see CHANGELOG for the specific research this was based on. Deliberately
 * excludes non-fingerprinting categories (beacon, permissions, clipboard,
 * idle, NFC) — those are separate privacy concerns, not identity-revealing
 * signals, and are left to Privacy Inspector's per-site, evidence-based
 * Select flow instead of being applied blanket here.
 *
 * hardwareConcurrency, deviceMemory, maxTouchPoints, connection, and
 * getGamepads are ALSO deliberately excluded — all are legitimately used
 * by widespread, unrelated-to-fingerprinting code (worker-pool sizing,
 * adaptive video quality/bitrate, touch/responsive-UI detection, gamepad-
 * presence UI); blocking two of them confirmed broke real sites. Battery
 * status is kept: Firefox and Safari removed the Battery Status API
 * entirely, specifically because battery level + charging time turned out
 * to be a precise cross-session fingerprint, with no comparably strong
 * legitimate use case.
 *
 * Timezone and audio were previously excluded too, on the reasoning below
 * — since re-added, tested, and confirmed not breaking sites:
 *   - Timezone: the earlier version's interceptor didn't return anything,
 *     so resolvedOptions() returned `undefined` instead of a real options
 *     object — real sites reading `.locale` off that to pick a display
 *     language broke. That was a bug in the interceptor, not a reason to
 *     avoid timezone entirely: this version returns the REAL resolved
 *     options unchanged (locale, calendar, numberingSystem, etc.) and only
 *     overwrites `timeZone` with a fixed value, so language detection
 *     keeps working.
 *   - Audio: only OfflineAudioContext/webkitOfflineAudioContext are
 *     intercepted, not AudioContext/webkitAudioContext — offline contexts
 *     are never connected to actual speaker output (non-realtime
 *     rendering only), so blocking them can't silence real playback;
 *     that's the dominant audio-fingerprinting vector, and it's the one
 *     regular AudioContext is not. A construct trap must return an
 *     object (the JS spec throws on any other return value), so instead
 *     of throwing, the replacement constructor returns a self-consistent
 *     stub (oscillator/gain/analyser nodes as no-ops, startRendering
 *     resolving to an empty buffer) that lets typical fingerprinting-
 *     script call patterns complete without erroring.
 *
 * Canvas and WebRTC mitigations below are modeled directly on this
 * project's own real, already-shipped AdGuard corelib scriptlets
 * (prevent-canvas, nowebrtc) rather than a bespoke implementation — those
 * are the same mitigations Privacy Inspector's Select button applies, and
 * they're deliberately designed to degrade gracefully (return a spec-legal
 * null / a harmless no-op stub) instead of throwing, specifically so
 * ordinary page scripts that don't expect an exception don't get one.
 *
 * Uses Object.getPrototypeOf(navigator) rather than the bare `Navigator`
 * global — this content-script environment's lint globals only declare the
 * lowercase `navigator` instance, not the `Navigator` interface constructor.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 */
'use strict';
(function(){
    'use strict';

    // ── Canvas / WebGL fingerprinting ───────────────────────────────────────
    // Only getContext() is intercepted, matching this project's real
    // prevent-canvas corelib scriptlet exactly — NOT toDataURL/toBlob/
    // getImageData, which that scriptlet also deliberately leaves alone.
    // getContext() returning `null` is spec-legal (the documented response
    // when a context type isn't available), so any well-behaved caller
    // already has to handle it — unlike throwing, or returning `undefined`
    // (which isn't a documented getContext() outcome and can itself
    // trigger a different, uncontrolled exception downstream, e.g.
    // `canvas.getContext('2d').fillRect(...)` on `undefined`).
    const canvasProto = window.HTMLCanvasElement && window.HTMLCanvasElement.prototype;
    if ( canvasProto && canvasProto.getContext ) {
        canvasProto.getContext = new Proxy(canvasProto.getContext, {
            apply: function() {
                console.info('[uBol] blocked canvas fingerprint read');
                return null;
            },
        });
    }

    // ── Timezone fingerprinting (locale preserved) ──────────────────────────
    // Real resolvedOptions() output returned unchanged except `timeZone`,
    // which is overwritten with a fixed value — `locale` (what breaks
    // language detection if faked/dropped) stays exactly as the real
    // implementation reports it.
    const dtfProto = window.Intl && window.Intl.DateTimeFormat && window.Intl.DateTimeFormat.prototype;
    if ( dtfProto && dtfProto.resolvedOptions ) {
        const origResolvedOptions = dtfProto.resolvedOptions;
        dtfProto.resolvedOptions = new Proxy(origResolvedOptions, {
            apply: function(target, thisArg, args) {
                const real = Reflect.apply(target, thisArg, args);
                console.info('[uBol] spoofed timezone fingerprint read');
                return Object.assign({}, real, { timeZone: 'UTC' });
            },
        });
    }

    // ── Audio fingerprinting (OfflineAudioContext only) ─────────────────────
    // Never touches AudioContext/webkitAudioContext — real playback keeps
    // working. Stub is self-consistent (nodes support connect/disconnect/
    // start/stop, startRendering resolves rather than rejects) so ordinary
    // fingerprinting-script call sequences complete without throwing.
    const offlineCtxName = window.OfflineAudioContext
        ? 'OfflineAudioContext'
        : window.webkitOfflineAudioContext ? 'webkitOfflineAudioContext' : '';
    if ( offlineCtxName !== '' ) {
        function audioNoop() {}
        function stubAudioNode() {
            return {
                connect: audioNoop, disconnect: audioNoop,
                start: audioNoop, stop: audioNoop,
                gain: { value: 0 }, frequency: { value: 0 },
            };
        }
        function offlineCtxReplacement() {
            console.info('[uBol] blocked audio fingerprint: ' + offlineCtxName);
        }
        offlineCtxReplacement.prototype = {
            createOscillator: stubAudioNode,
            createGain: stubAudioNode,
            createBufferSource: stubAudioNode,
            createScriptProcessor: stubAudioNode,
            createAnalyser: function() {
                return Object.assign(stubAudioNode(), {
                    fftSize: 2048,
                    frequencyBinCount: 1024,
                    getByteFrequencyData: audioNoop,
                    getFloatFrequencyData: audioNoop,
                });
            },
            destination: {},
            startRendering: function() {
                return Promise.resolve({
                    getChannelData: function() { return new Float32Array(0); },
                    length: 0,
                    sampleRate: 44100,
                    numberOfChannels: 1,
                });
            },
        };
        window[offlineCtxName] = offlineCtxReplacement;
    }

    // ── navigator.plugins / mimeTypes fingerprinting ────────────────────────
    // hardwareConcurrency and deviceMemory deliberately NOT included here
    // (nor tracked in Privacy Inspector at all anymore — see
    // privacy-probe.js) — both are legitimately used by ordinary site code
    // (Web Worker pool sizing, adaptive video-quality/rendering tiers), so
    // excluded here for the same reason, not just because the throwing
    // mitigation broke sites. plugins/mimeTypes stay: no meaningful
    // legitimate use since plugins were deprecated (~2020).
    const navigatorProto = Object.getPrototypeOf(navigator);

    [ 'plugins', 'mimeTypes' ].forEach(function(prop) {
        try {
            Object.defineProperty(navigatorProto, prop, {
                configurable: true,
                get: function() {
                    console.info('[uBol] blocked navigator.' + prop + ' read');
                    return [];
                },
            });
        } catch {
            // property already locked down (non-configurable) by another
            // wrapper on this page — not fatal, just leave it as-is.
        }
    });
    if ( typeof navigatorProto.getBattery === 'function' ) {
        navigatorProto.getBattery = new Proxy(navigatorProto.getBattery, { apply: function() {
            console.info('[uBol] blocked navigator.getBattery read');
            return Promise.reject(new TypeError('getBattery is blocked on this site'));
        } });
    }

    // ── WebRTC fingerprinting / IP leak ──────────────────────────────────────
    // Modeled directly on this project's real nowebrtc corelib scriptlet: a
    // construct trap legally MUST return an object (returning null/a
    // primitive throws a TypeError from the JS engine itself — not
    // something a try/catch around this scriptlet can avoid), so instead of
    // throwing deliberately, the replacement constructor returns a harmless
    // stub with no-op methods for the handful of calls real page scripts
    // commonly make (close, createDataChannel, createOffer,
    // setRemoteDescription) — code proceeds without erroring, it just never
    // gets a working connection.
    const rtcPropertyName = window.RTCPeerConnection
        ? 'RTCPeerConnection'
        : window.webkitRTCPeerConnection ? 'webkitRTCPeerConnection' : '';
    if ( rtcPropertyName !== '' ) {
        function noopFunc() {}
        function rtcReplacement() {
            console.info('[uBol] blocked WebRTC fingerprint/IP leak');
        }
        rtcReplacement.prototype = {
            close: noopFunc,
            createDataChannel: function() { return { close: noopFunc, send: noopFunc }; },
            createOffer: noopFunc,
            setRemoteDescription: noopFunc,
        };
        window[rtcPropertyName] = rtcReplacement;
    }
})();
