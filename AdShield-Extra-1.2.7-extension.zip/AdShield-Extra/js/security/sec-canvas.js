/*
 * sec-canvas.js — Security scriptlet: blockWebGL toggle
 *
 * Proxies HTMLCanvasElement.getContext() so any call requesting a 'webgl',
 * 'webgl2', or 'webgpu' context receives null instead of a live context
 * object. Prevents GPU fingerprinting via pixel readback and blocks the
 * WebGPU compute-shader fingerprinting vector.
 *
 * Note: uses new RegExp() rather than a regex literal — Brave's inline-code
 * validator rejects regex literals inside registered content script files.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 *
 * Uses const/let, not var: this whole file's body sits inside the
 * (function(){...})() IIFE below, so each re-injection gets a fresh
 * function scope — no top-level redeclaration hazard to guard against.
 */
'use strict';
(function(){'use strict';
            const _ctxPattern = new RegExp('webgl|webgpu', 'i');
            const _origGetContext = HTMLCanvasElement.prototype.getContext;
            HTMLCanvasElement.prototype.getContext = new Proxy(_origGetContext, {
                apply: function(target, thisArg, args) {
                    if ( typeof args[0] === 'string' && _ctxPattern.test(args[0]) ) {
                        console.info('[uBol] blocked canvas context:', args[0]);
                        return null;
                    }
                    return Reflect.apply(target, thisArg, args);
                },
            });
        })();
