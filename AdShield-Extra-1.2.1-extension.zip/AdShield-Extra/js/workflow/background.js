/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/*******************************************************************************

    STATE / GUARDS / TIMERS REFERENCE
    ==================================
    (Kept up to date manually - see the code-quality audit that introduced
    this block for the methodology.)

    STATE OVERVIEW
    --------------
    - Persisted (chrome.storage.local, survives browser restart):
      rulesetConfig (config.js), filteringModeDetails (mode-manager.js),
      sandboxFilters.dnrRules (filter-manager.js / compiled-filters.js -
      network + cosmetic rules compiled from the sandbox ABP editor; the
      userScripts permission and its sandboxFilters.userScripts key were
      removed in v3.12), custom per-hostname filters under "site.*" keys,
      userDnrRules.
    - Persisted (chrome.storage.session, survives SW restart but not browser
      restart): a session-only mirror of rulesetConfig/filteringModeDetails,
      used so a SW restart doesn't need to re-derive everything from local
      storage on every wakeup - see config.js/_loadRulesetConfig() and
      mode-manager.js/readFilteringModeDetails().
    - In-memory only (lost on SW restart, and why that's safe):
        * action.js: reverseMode (bool) - recomputed and corrected on the
          very next registerToolbarIconToggler() call after restart.
        * background.js: lastIconLevelByTab (Map<tabId, level>) - a dedup
          cache only; losing it just costs one redundant (not incorrect)
          browser.action.setIcon() call per tab after a restart.
        * compiled-filters.js: pendingRegister (Promise) - a same-lifetime
          sequencing helper for compile/register calls, not meant to
          survive restart.
        * onPermissionsChanged.pending (Array<Promise>) - same-lifetime
          sequencing only, self-clears as each promise settles (see the
          RACE CONDITION GUARDS section below).
        * block-monitor.js: activeSession (Object|null) - the live monitor
          session. Lost on SW restart intentionally: the webRequest listener
          is also lost, so no orphan listener is possible. The panel detects
          the lost session via MSG_GET_MONITOR_DATA returning null.
        * block-monitor.js: monitorListener (Function|null) - the webRequest
          onBeforeRequest handler. Registered/removed per session.
        * block-monitor.js: entries (Array, max 100) - FIFO capture buffer.
          Lost on SW restart intentionally; purely display data.
        * block-monitor.js: sessionTimeoutHandle (number|null) - the primary
          5-minute session setTimeout. Cleared in endSession/pauseMonitor.
        * block-monitor.js: watchdogHandle (number|null) - setInterval that
          runs for the SW lifetime as a fallback timer. Never cleared
          intentionally (see startWatchdog comment).

    STATE GUARDS
    ------------
    - swLifecycle (config.js): single state vector for the SW startup lane.
      phase progresses booting → starting → ready (or error on throw).
      startPhase tracks the sub-step within 'starting' so a hang during
      startup is immediately pinpointed in devtools.
      All event listeners gate on swLifecycle.phase === SW_PHASES.READY via
      the isFullyInitialized promise.
    - swLifecycle.firstRun / .wakeupRun: set once by loadRulesetConfig(),
      distinguish fresh-install from SW-wakeup so one-time setup doesn't re-run.
      Exposed as `process` alias for backward compat with call sites.

    RACE CONDITION GUARDS
    ----------------------
    - onPermissionsChanged() (this file): queues permission-change handlers
      onto a shared `pending` array and awaits all previous ones before
      starting the next, so overlapping permission events can't interleave.
      Each queued promise removes itself from the array once settled, so
      the array never grows unbounded.
    - compiled-filters.js: pendingRegister chain serialises
      updateCompiledFilters() calls, so a sandbox save that arrives
      mid-compile doesn't race the previous one. (registerUserScripts() was
      removed in v3.12 along with the userScripts permission; security
      scriptlet registration now goes through
      scripting-manager.js/registerSecurityContentScripts(), which does its
      own targeted get/diff/update cycle scoped to sec-* content script IDs
      and needs no serialisation lock — it does not share state with the
      compile pipeline.)

    ENDLESS LOOP GUARDS
    --------------------
    - popup.js: tryInit() retries at most INIT_RETRY_MAX_ATTEMPTS (20) times,
      INIT_RETRY_DELAY_MS (100ms) apart, rather than forever, if init()
      keeps throwing.

    TIMER REFERENCE
    ---------------
    - TAB_RELOAD_DELAY_MS (data/ext.js, 437ms, exported alongside
      reloadTab()): the short delay before reloading/navigating a tab
      after a filtering-relevant change, to give the just-updated content
      scripts/DNR rules a moment to register first. Used by reloadTab()'s
      three real callers — onPermissionGrantedThruBrowser() below,
      matrix-routes.js's handleReloadMatrixTab(), and
      core/site-mode-manager.js's applySiteMode() (which calls reloadTab()
      directly rather than a plain browser.tabs.reload(), for the same
      reason). Centralised as one constant specifically so none of these
      call sites can silently drift apart. (This comment previously named
      a fourth caller, "popup.js: commitFilteringMode()" — that function
      does not exist anywhere in this fork; it was upstream uBOL's
      location for the same reload, before this fork moved site-mode
      application into site-mode-manager.js. Corrected here rather than
      left to describe a file that was never actually checked.)
    - OFFSCREEN_COMPILE_TIMEOUT_MS (compiled-filters.js, 60000ms): upper
      bound while waiting for the offscreen document to finish compiling
      sandbox filters, cleared via clearTimeout() in a `finally` block the
      moment the real result arrives (or the offscreen document fails).
    - INIT_RETRY_DELAY_MS / INIT_RETRY_MAX_ATTEMPTS (popup.js): see ENDLESS
      LOOP GUARDS above.
    - The debounce timer in develop.js (editor auto-save) guards against re-entrancy by
      checking/clearing their own timer id before scheduling a new one.
    - SESSION_TIMEOUT_MS (block-monitor.js, 300000ms / 5 minutes): primary
      session timeout, stored as sessionTimeoutHandle. Cleared in endSession()
      and pauseMonitor(). Rescheduled in onMonitorCommitted() with remaining
      time after any accumulated pause duration.
    - watchdogHandle (block-monitor.js, setInterval at SESSION_TIMEOUT_MS):
      belt-and-suspenders fallback that catches sessions the primary
      setTimeout might miss. Runs for the SW lifetime. See startWatchdog().

*******************************************************************************/

// ── Tier 5 — data/ ──────────────────────────────────────────────────────────

// Dispatcher refactor (see dispatcher-refactor-plan.md) — routing metadata
// lives in its own module; handler logic (below) stays in background.js.
import { dispatchRoutedMessage } from './message-routes.js';

import {
    handleClearMatrixBlockRules,
    handleDeleteMatrixBlockRule,
    handleGetMatrixBlockRules,
    handleGetMatrixData,
    handleMatrixSetOverride,
    handleReloadMatrixTab,
    handleStartMatrix,
    handleStopMatrix,
    handleGetDomainRuleDetail,
} from './matrix-routes.js';

import {
    handleGetSecurityAllowlist,
    handleGetSecurityConfig,
    handleSetSecurityAllowlist,
    handleSetSecurityConfig,
} from './security-routes.js';

import {
    handleGetAllDynamicRules,
    handleGetAllSessionRules,
    handleUpdateUserDnrRules,
    handleGetEffectiveUserRules,
    handleGetEnabledRulesets,
    handleSetRulesetEnabled,
    handleGetWorryFreeFamiliarTlds,
    handleSetWorryFreeFamiliarTlds,
    handleRestoreWorryFreeFamiliarTlds,
} from './ruleset-routes.js';

import {
    handleSiteModeGet,
    handleSiteModeGetAll,
    handleSiteModeSet,
    handleSiteModeSetAll,
    handleGetFilteringMode,
    handleSetFilteringMode,
    handleGetFilteringModeDetails,
    handleSetFilteringModeDetails,
    handleGetDefaultFilteringMode,
    handleSetDefaultFilteringMode,
} from './mode-routes.js';

import {
    handleInsertCSS,
    handleRemoveCSS,
    handleInjectCSSProceduralAPI,
    handleStartCustomFilters,
    handleTerminateCustomFilters,
    handleInjectCustomFilters,
    handleAddCustomFilters,
    handleClearCosmeticRules,
    handleDeleteCosmeticRule,
    handleGetCustomCosmeticRules,
} from './filter-routes.js';

import {
    handlePrivacyInspectorEvent,
    handleGetMatchingScriptletRules,
    handleStartPrivacyInspector,
    handleStopPrivacyInspector,
    handlePausePrivacyInspector,
    handleResumePrivacyInspector,
    handleGetPrivacyInspectorData,
    handleAddPrivacyScriptletRule,
    handleApplyPrivacyExtras,
    handleGetPrivacyScriptletRules,
    handleDeletePrivacyScriptletRule,
    handleClearPrivacyScriptletRules,
} from './privacy-inspector-routes.js';

import {
    handleTempDisableGet,
    handleTempDisableStart,
    handleTempDisableStartUntilRestart,
    handleTempDisableCancel,
    handleTempDisableExpire,
} from './temp-disable-routes.js';

import {
    browser,
    localRead, localRemove, localWrite,
    runtime,
    sessionAccessLevel,
    reloadTab,
} from '../data/ext.js';

import {
    loadRulesetConfig,
    process,
    swLifecycle,
    SW_PHASES,
    rulesetConfig,
    saveRulesetConfig,
    saveSecurityConfig,
    saveSecurityAllowlist,
    securityConfig,
    securityAllowlist,
    GOV_DOMAIN_ALLOWLIST,
} from '../data/config.js';

import {
    processDueJobs,
    resetJobsAlarm,
} from '../data/alarms.js';

import { dnr } from '../data/ext-compat.js';
import { openOrFocusPanel } from '../util/panel-window.js';
import {
    MONITOR_RULES_RETIRED_BASE_ID,
    MONITOR_RULES_RETIRED_MAX_DNR,
    GPC_RULES_RETIRED_BASE_ID,
    GPC_RULES_RETIRED_MAX_DNR,
    LOGIN_WITH_RULES_RETIRED_BASE_ID,
    LOGIN_WITH_RULES_RETIRED_MAX_DNR,
    WORRY_FREE_EXTRA_RULES_BASE_ID,
    STRICT_3P_RULES_BASE_ID,
} from '../core/dnr-budgets.js';

import {
    MSG_GET_CUSTOM_COSMETIC_RULES,
    MSG_DELETE_COSMETIC_RULE,
    MSG_CLEAR_COSMETIC_RULES,
    MSG_GET_MATRIX_BLOCK_RULES,
    MSG_DELETE_MATRIX_BLOCK_RULE,
    MSG_CLEAR_MATRIX_BLOCK_RULES,
    MSG_GET_ENABLED_RULESETS,
    MSG_SET_RULESET_ENABLED,
    MSG_SITE_MODE_GET,
    MSG_SITE_MODE_SET,
    MSG_GET_PRIVACY_SCRIPTLET_RULES,
    MSG_DELETE_PRIVACY_SCRIPTLET_RULE,
    MSG_CLEAR_PRIVACY_SCRIPTLET_RULES,
    MSG_GET_MATCHING_SCRIPTLET_RULES,
    MSG_START_PRIVACY_INSPECTOR,
    MSG_STOP_PRIVACY_INSPECTOR,
    MSG_PAUSE_PRIVACY_INSPECTOR,
    MSG_RESUME_PRIVACY_INSPECTOR,
    MSG_GET_PRIVACY_INSPECTOR_DATA,
    MSG_ADD_PRIVACY_SCRIPTLET_RULE,
    MSG_APPLY_PRIVACY_EXTRAS,
    MSG_START_MATRIX,
    MSG_STOP_MATRIX,
    MSG_GET_MATRIX_DATA,
    MSG_MATRIX_SET_OVERRIDE,
    MSG_RELOAD_MATRIX_TAB,
    MSG_GET_DOMAIN_RULE_DETAIL,
    MSG_EXPORT_CUSTOM_RULES,
    MSG_IMPORT_CUSTOM_RULES,
    MSG_DELETE_FILTERED_CUSTOM_RULES,
    MSG_COOKIE_CLICKER_ADD_RULE,
    MSG_GET_COOKIE_CLICKER_RULES,
    MSG_DELETE_COOKIE_CLICKER_RULE,
    MSG_CLEAR_COOKIE_CLICKER_RULES,
    MSG_COOKIE_CLICKER_AUTODENY_GET,
    MSG_COOKIE_CLICKER_AUTODENY_START,
    MSG_COOKIE_CLICKER_AUTODENY_CANCEL,
    MSG_COOKIE_CLICKER_LAUNCH_PICKER,
    MSG_WORRY_FREE_LAUNCH_PICKER,
} from '../data/message-types.js';

// ── Tier 4 — util/ ──────────────────────────────────────────────────────────
import {
    hostnameFromMatch,
} from '../util/utils.js';

// ── Tier 3 — core/ ──────────────────────────────────────────────────────────
import {
    injectCustomScriptletsForFrame,
    addCustomScriptletRule,
    getPrivacyInspectorScriptletRules,
    deleteCustomScriptletRule,
    deletePrivacyScriptletRulesMatching,
    getCustomScriptletRules,
    backfillScriptletRuleDates,
} from '../core/custom-scriptlets.js';

import {
    getDefaultFilteringMode,
    getFilteringMode,
    syncWithBrowserPermissions,
} from '../core/mode-manager.js';

import {
    deleteCustomFiltersMatching,
    getAllCustomFiltersWithDates,
    importCosmeticFilters,
    backfillCosmeticRuleDates,
} from '../core/filter-manager.js';

import {
    updateDynamicRules,
    updateSecurityRules,
    updateUserRules,
    applyBadgeCountVisibility,
} from '../core/ruleset-manager.js';

import {
    getRegisteredContentScripts,
    pruneCSSCache,
    registerContentScripts,
    registerScriptletContentScripts,
    registerCosmeticContentScripts,
    registerSecurityContentScripts,
    registerCookieClickerContentScripts,
    getScriptingManagerLockState,
} from '../core/scripting-manager.js';

import {
    updateCompiledFilters,
} from '../core/compiled-filters.js';

import { setToolbarIconForLevel } from '../core/action.js';

import { setRulesetEnabled, restoreEnabledRulesetsFromStorage } from '../core/static-rulesets.js';
import { ensureFamiliarTldRules } from '../core/worry-free-familiar-tld-manager.js';
import {
    getMatrixBlockRules,
    deleteMatrixOverridesMatching,
    restoreMatrixBlockRules,
    importMatrixOverrides,
    backfillMatrixOverrideDates,
} from '../core/matrix-block-rules.js';
import { updateBuiltinWhitelistRules } from '../core/builtin-whitelist-rules.js';
import { updateBuiltinFixExceptions } from '../core/builtin-fix-exceptions.js';
import {
    getAllCookieClickerRules,
    deleteCookieClickerRulesMatching,
    importCookieClickerRules,
    backfillCookieClickerRuleDates,
} from '../core/cookie-clicker-rules.js';
import {
    handleCookieClickerAddRule,
    handleCookieClickerPickCancelled,
    handleGetCookieClickerRules,
    handleDeleteCookieClickerRule,
    handleClearCookieClickerRules,
    handleCookieClickerAutoDenyGet,
    handleCookieClickerAutoDenyStart,
    handleCookieClickerAutoDenyCancel,
    handleCookieClickerAutoDenyExpire,
    handleCookieClickerLaunchPicker,
    handleWorryFreeLaunchPicker,
} from './cookie-clicker-routes.js';
import {
    startWatchdog as startMatrixWatchdog,
    reconcileMatrixCaches,
} from '../core/matrix-panel.js';

// block-monitor.js (the standalone "DDG Tracker Radar" session monitor)
// removed in uBlock-Stripped-Dynamic — superseded by the Matrix panel,
// which shows ALL connections (not just known trackers). The Matrix
// panel's own "known DDG Tracker" column (which briefly reused
// tracker-radar-lookup.js directly) has since been removed too — see
// CHANGELOG. Nothing in this project reads DuckDuckGo Tracker Radar
// data anymore.

import {
    startWatchdog as startPrivacyInspectorWatchdog,
} from '../core/privacy-inspector.js';

import {
    getSiteMode,
    setIconForMode,
} from '../core/site-mode-manager.js';

import {
    clearTempDisableOnBrowserStartup,
} from '../core/temp-disable-manager.js';

import { deleteHistoryOnBrowserStartup } from '../core/history-cleaner.js';
import { clearAutoDenyOnBrowserStartup, getAutoDenyState, startAutoDeny } from '../core/cookie-clicker-autodeny-manager.js';
import { reconcileWorryFreeExtraSuppressionRule } from '../core/worry-free-extra-manager.js';
import { reconcileWorryFreeStrict3pRules } from '../core/worry-free-strict-3p-manager.js';

/******************************************************************************/

const UBOL_ORIGIN = runtime.getURL('').replace(/\/$/, '').toLowerCase();
function canShowBlockedCount() { return typeof dnr.setExtensionActionOptions === 'function'; }

// DEVTOOLS DEBUGGING AID — this project's first instance of this pattern
// (no prior convention to match; established here per explicit request).
// ES module exports are NOT automatically visible to a service worker's
// DevTools console REPL — only names explicitly attached to `self` are.
// getScriptingManagerLockState() (scripting-manager.js) existed but was
// unreachable from the console for exactly this reason — the underlying
// phase-tagged lock mechanism (js/util/async-lock.js's createLock(),
// implemented in 5.0.16-5.0.17) was always correct, only the "devtools
// visibility" half of that original ask was still missing. Exposed here,
// not called by any other code in this codebase — inspect via the SW's
// "Inspect" DevTools console: getScriptingManagerLockState().
self.getScriptingManagerLockState = getScriptingManagerLockState;

/******************************************************************************/

function getCurrentVersion() {
    return runtime.getManifest().version;
}

/******************************************************************************/

// refreshToolbarIconsForOpenTabs() moved to mode-routes.js, alongside its
// only caller (handleSetFilteringModeDetails).

/******************************************************************************/

// reloadTab() now lives in ../data/ext.js — shared by this file
// (onPermissionGrantedThruBrowser below, and matrix-routes.js's
// handleReloadMatrixTab) and js/core/site-mode-manager.js's applySiteMode()
// (workflow/ and core/ can both reach data/, but core/ cannot reach
// workflow/ — see ARCHITECTURE.md's five-tier model).

/******************************************************************************/

// When a new host permission is granted through the browser
async function onPermissionGrantedThruBrowser(origins) {
    const modified = await syncWithBrowserPermissions();
    if ( modified === false ) { return; }
    await registerContentScripts();
    if ( rulesetConfig.autoReload !== true ) { return; }
    if ( origins.length !== 1 ) { return; }
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    const tabId = tabs?.[0]?.id;
    if ( typeof tabId !== 'number' || tabId === -1 ) { return; }
    const results = await browser.scripting.executeScript({
        target: { tabId, frameIds: [ 0 ] },
        func: ( ) => document.location.hostname,
    }).catch(( ) => {
    });
    const tabHostname = results?.[0]?.result;
    if ( typeof tabHostname !== 'string' ) { return; }
    const hostname = hostnameFromMatch(origins[0]);
    if ( tabHostname.endsWith(hostname) === false ) { return; }
    const pos = tabHostname.length - hostname.length;
    if ( pos !== 0 && tabHostname.charAt(pos-1) !== '.' ) { return; }
    await reloadTab(tabId);
}

// https://github.com/uBlockOrigin/uBOL-home/issues/280
async function onPermissionsAdded(permissions) {
    const { origins = [] } = permissions;
    return onPermissionGrantedThruBrowser(origins);
}

async function onPermissionsRemoved() {
    const modified = await syncWithBrowserPermissions();
    if ( modified === false ) { return false; }
    registerContentScripts();
    return true;
}

async function onPermissionsChanged(op, permissions) {
    await isFullyInitialized;
    const { pending } = onPermissionsChanged;
    await Promise.all(pending);
    const promise = op === 'removed'
        ? onPermissionsRemoved()
        : onPermissionsAdded(permissions);
    pending.push(promise);
    promise.finally(( ) => {
        const i = pending.indexOf(promise);
        if ( i !== -1 ) { pending.splice(i, 1); }
    });
}
onPermissionsChanged.pending = [];

/******************************************************************************/

/******************************************************************************/

// ── STAGE 0 ROUTED HANDLERS ──────────────────────────────────────────────
// handleInsertCSS, handleRemoveCSS, handleInjectCSSProceduralAPI moved to
// filter-routes.js (see this file's ROUTE_HANDLERS below).

// ── STAGE 1 ROUTED HANDLERS ──────────────────────────────────────────────
// handleStartCustomFilters, handleTerminateCustomFilters,
// handleInjectCustomFilters moved to filter-routes.js.

// handlePrivacyInspectorEvent, handleGetMatchingScriptletRules,
// handleStartPrivacyInspector, handleStopPrivacyInspector,
// handlePausePrivacyInspector, handleResumePrivacyInspector,
// handleGetPrivacyInspectorData, handleAddPrivacyScriptletRule,
// handleApplyPrivacyExtras, handleGetPrivacyScriptletRules,
// handleDeletePrivacyScriptletRule, handleClearPrivacyScriptletRules
// moved to privacy-inspector-routes.js.

// handleGetCustomCosmeticRules, handleDeleteCosmeticRule,
// handleClearCosmeticRules moved to filter-routes.js.

// handleGetMatrixBlockRules, handleDeleteMatrixBlockRule,
// handleClearMatrixBlockRules moved to matrix-routes.js (see this file's
// ROUTE_HANDLERS below).

// Export format version — bump this if the payload shape below ever
// changes incompatibly, so a future import can tell an old export apart
// from a new one instead of guessing from field presence. Single source
// of truth for both handlers below, not a literal repeated in each.
const CUSTOM_RULES_EXPORT_FORMAT = 1;

// Combined export across all FOUR Manage Custom Rules sections at once
// (Cosmetic, Cookie/consent-clicker, Dynamic DNR, Privacy/scriptlet) —
// deliberately NOT per-section like the "Clear all" buttons are; one
// file, everything in it, matching the single Export button in the
// dashboard toolbar.
// Field shapes are chosen to round-trip losslessly through
// handleImportCustomRules() below with no reshaping needed on either
// side: matrixOverrides is exactly getMatrixBlockRules()'s own array
// shape, scriptletRules strips only the regenerate-on-import fields
// (uid, source), cookieClickerRules strips uid/id the same way (a fresh
// id is minted per rule on import — see importCookieClickerRules()'s
// own comment in cookie-clicker-rules.js).
async function handleExportCustomRules() {
    const [ matrixRules, cosmeticEntries, scriptletRules, cookieClickerRules ] = await Promise.all([
        getMatrixBlockRules(),
        getAllCustomFiltersWithDates(),
        getPrivacyInspectorScriptletRules(),
        getAllCookieClickerRules(),
    ]);

    const cosmeticRules = {};
    for ( const [ hostname, entries ] of cosmeticEntries ) {
        cosmeticRules[hostname] = entries; // [ { selector, createdAt } ]
    }

    return {
        ok: true,
        exportFormat: CUSTOM_RULES_EXPORT_FORMAT,
        extensionVersion: getCurrentVersion(),
        exportedAt: new Date().toISOString(),
        matrixOverrides: matrixRules.map(({ site, domain, all, code, createdAt }) => ({ site, domain, all, code, createdAt })),
        cosmeticRules,
        scriptletRules: scriptletRules.map(({ hostname, name, args, createdAt }) => ({ hostname, name, args, createdAt })),
        cookieClickerRules: cookieClickerRules.map(({ siteHostname, frameHostname, selector, textFilter, enabled, createdAt }) => (
            { siteHostname, frameHostname, selector, textFilter, enabled, createdAt }
        )),
    };
}

// Counterpart to handleExportCustomRules() above — same combined, all-
// three-sections-at-once scope. MERGES into whatever is already on this
// install (an import is meant to bring rules IN, not silently replace
// everything already set up here) by delegating to each section's own
// existing, already-validated add path: importMatrixOverrides() for
// Dynamic DNR, addCustomFilters() per hostname for Cosmetic,
// addCustomScriptletRule() per rule for Privacy/scriptlet — the same
// functions a normal (non-import) add through any of those features
// already goes through, so import can't bypass any validation a manual
// add would be subject to. request.payload is untrusted file content,
// not trusted internal data — every field is type/shape-checked before
// use, nothing is assumed.
async function handleImportCustomRules(request) {
    const payload = request.payload;
    if ( !payload || typeof payload !== 'object' ) {
        return { ok: false, error: 'Not a valid custom-rules export file.' };
    }

    const counts = { matrixOverrides: 0, cosmeticHostnames: 0, scriptletRules: 0, cookieClickerRules: 0 };
    const errors = [];

    if ( Array.isArray(payload.matrixOverrides) ) {
        counts.matrixOverrides = await importMatrixOverrides(payload.matrixOverrides);
    }

    if ( Array.isArray(payload.cookieClickerRules) ) {
        counts.cookieClickerRules = await importCookieClickerRules(payload.cookieClickerRules);
        if ( counts.cookieClickerRules > 0 ) {
            await registerCookieClickerContentScripts();
        }
    }

    if ( payload.cosmeticRules && typeof payload.cosmeticRules === 'object' ) {
        for ( const [ hostname, rawEntries ] of Object.entries(payload.cosmeticRules) ) {
            if ( typeof hostname !== 'string' || hostname === '' ) { continue; }
            if ( !Array.isArray(rawEntries) ) { continue; }
            // Accepts both the current { selector, createdAt } shape AND
            // a plain string array — an export made before this
            // date-tracking feature existed. A bare string just carries
            // no createdAt, which importCosmeticFilters() already
            // treats the same as any other missing/invalid date
            // (stamps today).
            const entries = rawEntries
                .map(e => typeof e === 'string' ? { selector: e, createdAt: undefined } : e)
                .filter(e => e && typeof e.selector === 'string' && e.selector !== '');
            if ( entries.length === 0 ) { continue; }
            const added = await importCosmeticFilters(hostname, entries);
            // importCosmeticFilters() reports whether anything NEW
            // landed for this hostname (dedup + the global cosmetic-rule
            // cap can both mean 0 of N were actually new) — counted per
            // hostname touched, not per selector, since that boolean
            // alone can't say exactly how many made it past dedup.
            if ( added ) { counts.cosmeticHostnames++; }
        }
    }

    if ( Array.isArray(payload.scriptletRules) ) {
        for ( const rule of payload.scriptletRules ) {
            if ( !rule || typeof rule !== 'object' ) { continue; }
            const result = await addCustomScriptletRule(rule, 'import');
            if ( result.ok ) { counts.scriptletRules++; }
            else if ( result.error ) { errors.push(result.error); }
        }
    }

    return { ok: true, counts, errors };
}

// Toolbar's "Delete rules" button — smart-deletes across all FOUR
// sections at once, scoped to whatever domain filter is currently active
// in the dashboard (request.filter === '' means no filter, i.e. delete
// everything — the same scope the old per-section Clear all buttons
// covered individually, now unified into this one filter-aware action).
// filter is matched case-insensitively as a plain "contains" — see each
// of the four delete*Matching() functions' own comments for exactly
// which field(s) it's checked against per section.
async function handleDeleteFilteredCustomRules(request) {
    const filter = typeof request.filter === 'string' ? request.filter : '';
    const [ cosmeticHostnames, matrixOverrides, scriptletRules, cookieClickerRules ] = await Promise.all([
        deleteCustomFiltersMatching(filter),
        deleteMatrixOverridesMatching(filter),
        deletePrivacyScriptletRulesMatching(filter),
        deleteCookieClickerRulesMatching(filter),
    ]);
    if ( cookieClickerRules > 0 ) {
        await registerCookieClickerContentScripts();
    }
    return { ok: true, counts: { cosmeticHostnames, matrixOverrides, scriptletRules, cookieClickerRules } };
}

// ── Stage 2, batch 2: 4-way site mode / allowlist ────────────────────────
// handleSiteModeGet, handleSiteModeSet, handleSiteModeGetAll,
// handleSiteModeSetAll (below the temp-disable cluster) moved to
// mode-routes.js.

// ── "Buying, booking, banking mode" — timed global filtering pause ──────
// handleTempDisableGet, handleTempDisableStart,
// handleTempDisableStartUntilRestart, handleTempDisableCancel,
// handleTempDisableExpire moved to temp-disable-routes.js.

// Single source of truth mapping a routed `request.what` to its handler.
// Grows alongside MESSAGE_ROUTES in message-routes.js as later stages
// migrate more cases — add both in the same commit, never one without the
// other (a route with no handler, or a handler with no route, is a wiring
// bug the dispatcher will flag via console.warn).
// ── Stage 2, batch 3: everything else ────────────────────────────────────
// security config, filtering mode, rulesets, sandbox filters, monitor.
// This completes the dispatcher refactor — see message-routes.js for the
// matching route declarations.

async function handleGetCurrentConfig() {
    return rulesetConfig;
}

// handleGetSecurityConfig, handleSetSecurityConfig, handleGetSecurityAllowlist,
// handleSetSecurityAllowlist moved to security-routes.js (see this file's
// ROUTE_HANDLERS below), along with the SECURITY_SCRIPTLET_TOGGLE_KEYS /
// SECURITY_HYBRID_TOGGLE_KEYS / SECURITY_STARTUP_ONLY_KEYS dispatch sets
// those handlers own.

async function handleGetOptionsPageData() {
    const defaultFilteringMode = await getDefaultFilteringMode();
    process.firstRun = false;
    return {
        defaultFilteringMode,
        autoReload: rulesetConfig.autoReload,
        showBlockedCount: rulesetConfig.showBlockedCount,
        canShowBlockedCount: canShowBlockedCount(),
        firstRun: process.firstRun,
    };
}

async function handlePopupPanelData(request) {
    const level = await getFilteringMode(request.hostname);
    return {
        level,
        autoReload: rulesetConfig.autoReload,
    };
}

// handleGetFilteringMode, handleSetFilteringMode, handleGetDefaultFilteringMode,
// handleSetDefaultFilteringMode, handleGetFilteringModeDetails,
// handleSetFilteringModeDetails moved to mode-routes.js.

// handleGetAllDynamicRules, handleGetAllSessionRules,
// handleGetEffectiveUserRules, handleUpdateUserDnrRules moved to
// ruleset-routes.js (see this file's ROUTE_HANDLERS below), along with
// handleGetEnabledRulesets/handleSetRulesetEnabled further below.

// handleAddCustomFilters moved to filter-routes.js.

// handleGetSandboxFilters / handleSetSandboxFilters REMOVED — BRAVE VARIANT:
// the dashboard's "Import ABP rules" tab (sandboxEditor, dashboard.html)
// and its message-driven load/save path are dropped entirely for this
// variant, per explicit request. A follow-up deep-dive traced every
// remaining caller of getSandboxFilters()/setSandboxFilters() themselves
// (filter-manager.js) and found none once these two message handlers were
// gone — they, and the cosmetic-EXCEPTION-rule support that depended on
// them (which had no other authoring path), were removed entirely too.
// See CHANGELOG for the full scope note on what was deliberately kept
// (picker/import-authored apply-type cosmetic rules, unaffected) vs.
// removed.

async function handlePruneCSSCache() {
    return pruneCSSCache();
}

// This is used to ensure we are not suspended while busy fetching filter
// lists from remote servers.
async function handleKeepAlive() {
    return;
}

// ── Static ruleset toggles ────────────────────────────────────────────────
// handleGetEnabledRulesets, handleSetRulesetEnabled moved to
// ruleset-routes.js (see this file's ROUTE_HANDLERS below).

// ── Block Monitor ─────────────────────────────────────────────────────────
// (Standalone "DDG Tracker Radar" session monitor removed — see the
// block-monitor.js import-site comment near the top of this file.)

// ── Matrix panel ─────────────────────────────────────────────────────────
// handleStartMatrix, handleStopMatrix, handleGetMatrixData,
// handleMatrixSetOverride, handleReloadMatrixTab moved to matrix-routes.js
// (see this file's ROUTE_HANDLERS below), alongside
// handleGetMatrixBlockRules/handleDeleteMatrixBlockRule/
// handleClearMatrixBlockRules above.

const ROUTE_HANDLERS = {
    insertCSS: handleInsertCSS,
    removeCSS: handleRemoveCSS,
    injectCSSProceduralAPI: handleInjectCSSProceduralAPI,
    startCustomFilters: handleStartCustomFilters,
    terminateCustomFilters: handleTerminateCustomFilters,
    injectCustomFilters: handleInjectCustomFilters,
    privacyInspectorEvent: handlePrivacyInspectorEvent,
    [MSG_GET_MATCHING_SCRIPTLET_RULES]: handleGetMatchingScriptletRules,
    [MSG_COOKIE_CLICKER_ADD_RULE]: handleCookieClickerAddRule,
    cookieClickerPickCancelled: handleCookieClickerPickCancelled,
    [MSG_START_PRIVACY_INSPECTOR]: handleStartPrivacyInspector,
    [MSG_STOP_PRIVACY_INSPECTOR]: handleStopPrivacyInspector,
    [MSG_PAUSE_PRIVACY_INSPECTOR]: handlePausePrivacyInspector,
    [MSG_RESUME_PRIVACY_INSPECTOR]: handleResumePrivacyInspector,
    [MSG_GET_PRIVACY_INSPECTOR_DATA]: handleGetPrivacyInspectorData,
    [MSG_ADD_PRIVACY_SCRIPTLET_RULE]: handleAddPrivacyScriptletRule,
    [MSG_APPLY_PRIVACY_EXTRAS]: handleApplyPrivacyExtras,
    [MSG_GET_PRIVACY_SCRIPTLET_RULES]: handleGetPrivacyScriptletRules,
    [MSG_DELETE_PRIVACY_SCRIPTLET_RULE]: handleDeletePrivacyScriptletRule,
    [MSG_CLEAR_PRIVACY_SCRIPTLET_RULES]: handleClearPrivacyScriptletRules,
    [MSG_GET_CUSTOM_COSMETIC_RULES]: handleGetCustomCosmeticRules,
    [MSG_DELETE_COSMETIC_RULE]: handleDeleteCosmeticRule,
    [MSG_CLEAR_COSMETIC_RULES]: handleClearCosmeticRules,
    [MSG_GET_COOKIE_CLICKER_RULES]: handleGetCookieClickerRules,
    [MSG_DELETE_COOKIE_CLICKER_RULE]: handleDeleteCookieClickerRule,
    [MSG_CLEAR_COOKIE_CLICKER_RULES]: handleClearCookieClickerRules,
    [MSG_GET_MATRIX_BLOCK_RULES]: handleGetMatrixBlockRules,
    [MSG_DELETE_MATRIX_BLOCK_RULE]: handleDeleteMatrixBlockRule,
    [MSG_CLEAR_MATRIX_BLOCK_RULES]: handleClearMatrixBlockRules,
    [MSG_EXPORT_CUSTOM_RULES]: handleExportCustomRules,
    [MSG_IMPORT_CUSTOM_RULES]: handleImportCustomRules,
    [MSG_DELETE_FILTERED_CUSTOM_RULES]: handleDeleteFilteredCustomRules,
    [MSG_SITE_MODE_GET]: handleSiteModeGet,
    [MSG_SITE_MODE_SET]: handleSiteModeSet,
    siteModeGetAll: handleSiteModeGetAll,
    siteModeSetAll: handleSiteModeSetAll,
    getCurrentConfig: handleGetCurrentConfig,
    getSecurityConfig: handleGetSecurityConfig,
    setSecurityConfig: handleSetSecurityConfig,
    getSecurityAllowlist: handleGetSecurityAllowlist,
    setSecurityAllowlist: handleSetSecurityAllowlist,
    getOptionsPageData: handleGetOptionsPageData,
    popupPanelData: handlePopupPanelData,
    getFilteringMode: handleGetFilteringMode,
    setFilteringMode: handleSetFilteringMode,
    getDefaultFilteringMode: handleGetDefaultFilteringMode,
    setDefaultFilteringMode: handleSetDefaultFilteringMode,
    getFilteringModeDetails: handleGetFilteringModeDetails,
    setFilteringModeDetails: handleSetFilteringModeDetails,
    getAllDynamicRules: handleGetAllDynamicRules,
    getAllSessionRules: handleGetAllSessionRules,
    getEffectiveUserRules: handleGetEffectiveUserRules,
    updateUserDnrRules: handleUpdateUserDnrRules,
    addCustomFilters: handleAddCustomFilters,
    pruneCSSCache: handlePruneCSSCache,
    keepAlive: handleKeepAlive,
    tempDisableGet: handleTempDisableGet,
    tempDisableStart: handleTempDisableStart,
    tempDisableStartUntilRestart: handleTempDisableStartUntilRestart,
    tempDisableCancel: handleTempDisableCancel,
    tempDisableExpire: handleTempDisableExpire,
    [MSG_COOKIE_CLICKER_AUTODENY_GET]: handleCookieClickerAutoDenyGet,
    [MSG_COOKIE_CLICKER_AUTODENY_START]: handleCookieClickerAutoDenyStart,
    [MSG_COOKIE_CLICKER_AUTODENY_CANCEL]: handleCookieClickerAutoDenyCancel,
    cookieClickerAutoDenyExpire: handleCookieClickerAutoDenyExpire,
    [MSG_COOKIE_CLICKER_LAUNCH_PICKER]: handleCookieClickerLaunchPicker,
    [MSG_WORRY_FREE_LAUNCH_PICKER]: handleWorryFreeLaunchPicker,
    [MSG_GET_ENABLED_RULESETS]: handleGetEnabledRulesets,
    [MSG_SET_RULESET_ENABLED]: handleSetRulesetEnabled,
    getWorryFreeFamiliarTlds: handleGetWorryFreeFamiliarTlds,
    setWorryFreeFamiliarTlds: handleSetWorryFreeFamiliarTlds,
    restoreWorryFreeFamiliarTlds: handleRestoreWorryFreeFamiliarTlds,
    [MSG_START_MATRIX]: handleStartMatrix,
    [MSG_STOP_MATRIX]: handleStopMatrix,
    [MSG_GET_MATRIX_DATA]: handleGetMatrixData,
    [MSG_MATRIX_SET_OVERRIDE]: handleMatrixSetOverride,
    [MSG_RELOAD_MATRIX_TAB]: handleReloadMatrixTab,
    [MSG_GET_DOMAIN_RULE_DETAIL]: handleGetDomainRuleDetail,
};

async function onMessage(request, sender) {

    const tabId = sender?.tab?.id ?? false;
    const frameId = tabId && (sender?.frameId ?? false);

    // Dispatcher refactor complete (see dispatcher-refactor-plan.md):
    // every `request.what` this listener handles has a declared route in
    // MESSAGE_ROUTES (message-routes.js). dispatchRoutedMessage() validates
    // requiresInit/allowedSenders generically instead of via switch-
    // statement position, then calls the matched handler below.
    const routed = await dispatchRoutedMessage(request, sender, {
        tabId,
        frameId,
        isFullyInitialized,
        isTrustedOrigin: ( ) => sender?.origin === undefined ||
            sender.origin.toLowerCase() === UBOL_ORIGIN,
    }, ROUTE_HANDLERS);
    if ( routed.handled ) { return routed.value; }

    // Stage B (content-script-sourced, no trusted-origin gate) is now fully
    // migrated to the routing table above — see MESSAGE_ROUTES in
    // message-routes.js. Stage C (genuine extension pages: popup,
    // dashboard, Monitor / Privacy Inspector panels) is likewise fully
    // migrated as of Stage 2, batch 3 — every `request.what` this listener
    // handles now has a declared route, and dispatchRoutedMessage() above
    // already applies the trusted-origin gate for EXTENSION_PAGE routes.
    // Nothing left to fall through to.

    // No route matched. Diagnostic only, per dispatcher-refactor-plan.md
    // §5 — never turn this into a thrown error or hard rejection. The
    // outer runtime.onMessage listener already filters out
    // `request.what.includes(':')` (the convention other listeners
    // coexisting on this same event use for their own namespaced
    // messages), so an unmatched, colon-free `what` reaching here is
    // unexpected, not necessarily invalid — likely a stale message from a
    // reloaded content script/page, or a genuine wiring bug worth noticing
    // during development.
    console.info(`[uBlock-Dynamic] onMessage: no route for '${request.what}' — ignored`);
    return;
}

/******************************************************************************/

// Sub-function: one-time migration tasks on version bump.
async function runVersionMigration(currentVersion) {
    rulesetConfig.version = currentVersion;

    // DEFENSIVE (v9.1.5) — clear every session-scoped DNR rule in this
    // project's own managed ranges before anything below re-establishes
    // the current correct set. Real incident this fixes: DNR session
    // rules do NOT clear on a Chrome Web Store auto-update — only on a
    // genuine browser restart (MDN: "not persisted across browser
    // sessions", but an auto-update doesn't restart the browser process
    // at all). worry-free-extra-manager.js's reconcile() and worry-free-
    // strict-3p-manager.js's own equivalent only ever know about the
    // CURRENT version's own id list (SUPPRESSION_RULES/
    // SCOPED_SUPPRESSION_RULES) — if a past version used a different id
    // or rule shape for something in this range, and a later version
    // renumbers or drops it, the old rule has no code path that would
    // ever remove it. It just sits there, silently, on any install that
    // updated without a restart — plausible root cause for "worked in
    // testing after a restart, broken for real users after an auto-
    // update" reports. RANGE-based (not the current id list) precisely
    // so it also catches ids from a version whose source this session
    // has no visibility into — a person or LLM assistant reconstructing
    // "the current known ids" from today's source can only ever clear
    // what today's source still remembers existed.
    //
    // Two ranges, matching dnr-budgets.js's own top-level allocation
    // bands: WORRY_FREE_EXTRA_RULES_BASE_ID (13 000 000) through the end
    // of that band (13 999 999, i.e. before STRICT_3P_RULES_BASE_ID's own
    // band starts), and STRICT_3P_RULES_BASE_ID (14 000 000) through its
    // own band's end (14 999 999). Both bands are, by dnr-budgets.js's
    // own documented convention, reserved exclusively for worry-free
    // session-rule mechanisms — nothing else in this codebase allocates
    // ids in either range, so a blanket range-clear here cannot collide
    // with an unrelated feature's own rules.
    try {
        const allSessionRules = await dnr.getSessionRules();
        const orphanCandidateIds = allSessionRules
            .map(r => r.id)
            .filter(id =>
                (id >= WORRY_FREE_EXTRA_RULES_BASE_ID && id < WORRY_FREE_EXTRA_RULES_BASE_ID + 1_000_000) ||
                (id >= STRICT_3P_RULES_BASE_ID && id < STRICT_3P_RULES_BASE_ID + 1_000_000)
            );
        if ( orphanCandidateIds.length > 0 ) {
            await dnr.updateSessionRules({ removeRuleIds: orphanCandidateIds });
        }
    } catch (reason) {
        console.error(`[uBlock-Dynamic] runVersionMigration/clear-orphaned-worryfree-session-rules/${reason}`);
    }

    // One-time cleanup of storage keys from removed features.
    // strictBlockMode: removed in v1.1 (bundled filter data gone).
    // excludedStrictBlockHostnames: orphaned storage from same feature.
    // defaultRulesetIds: tracked which stock rulesets were auto-enabled;
    //   no longer needed; Chrome persists static ruleset state via DNR.
    // enabledRulesets: field was used by an older build that had no static
    //   rulesets; now vestigial — deleted from rulesetConfig so it no longer
    //   accumulates in storage.
    delete rulesetConfig.strictBlockMode;
    delete rulesetConfig.enabledRulesets;
    localRemove([
        'excludedStrictBlockHostnames',
        'defaultRulesetIds',
    ]);
    saveRulesetConfig();

    // One-time retirement: blockWindowName / blockVisibilityChange were two
    // standalone global toggles; both are replaced by Privacy Inspector's
    // auto-apply model (applyPrivacyExtrasForHost() — see
    // js/core/custom-scriptlets.js), which now applies unconditionally on
    // "Block All" (7.0.0) rather than being gated on a dashboard toggle, so
    // there's no longer a toggle to best-effort turn on here — just delete
    // the two retired keys from both securityConfig and securityAllowlist so
    // they stop accumulating in storage (mirrors the strictBlockMode cleanup
    // pattern just above).
    let securityConfigChanged = false;
    if ( 'blockWindowName' in securityConfig || 'blockVisibilityChange' in securityConfig ) {
        delete securityConfig.blockWindowName;
        delete securityConfig.blockVisibilityChange;
        securityConfigChanged = true;
    }
    // One-time retirement (v9.1.7): worryFreeBlocklistEnabled — "Enable
    // extra blocklist" is gone entirely (EasyList adult ad-servers +
    // transcend.io, and the Disconnect+Ghostery social media list, both
    // removed per explicit request — see js/data/config.js's own header
    // comment on the retired key). Nothing reads this setting anymore;
    // delete it so it stops accumulating in storage, same pattern as the
    // blockWindowName/blockVisibilityChange cleanup just above.
    if ( 'worryFreeBlocklistEnabled' in securityConfig ) {
        delete securityConfig.worryFreeBlocklistEnabled;
        securityConfigChanged = true;
    }
    // One-time retirement (this release): worryFreeGhosteryOtherEnabled —
    // ruleset_ghostery_other removed entirely, per explicit request (see
    // dnr-budgets.js's WORRY_FREE_GHOSTERY_OTHER_RULES_RETIRED_BASE_ID
    // comment for the full history). Nothing reads this setting anymore;
    // delete it so it stops accumulating in storage, same pattern as the
    // worryFreeBlocklistEnabled cleanup just above.
    if ( 'worryFreeGhosteryOtherEnabled' in securityConfig ) {
        delete securityConfig.worryFreeGhosteryOtherEnabled;
        securityConfigChanged = true;
    }
    if ( securityConfigChanged ) {
        await saveSecurityConfig();
    }
    if ( 'blockWindowName' in securityAllowlist || 'blockVisibilityChange' in securityAllowlist ) {
        delete securityAllowlist.blockWindowName;
        delete securityAllowlist.blockVisibilityChange;
        await saveSecurityAllowlist();
    }

    // One-time retirement (7.0.0): "Block free hosting & DDNS domains"
    // (blockSuspiciousHosting) and the manual "Auto-apply window name and
    // tab protection" toggle (autoApplyPrivacyExtras) were both removed from
    // securityConfig's schema. Clean up:
    //   1. the two settings keys themselves, from both securityConfig and
    //      securityAllowlist, so they stop accumulating in storage;
    //   2. the cached domain list the free-hosting feature stored under its
    //      own key (never read by anything else);
    //   3. the two dynamic DNR rules the free-hosting feature may have
    //      registered while it was on — nothing else will ever remove these
    //      once suspicious-hosting.js itself is gone, so this has to happen
    //      here, once, on upgrade. IDs are the same fixed values that module
    //      used to import from dnr-budgets.js (now also removed there);
    //      hardcoded here since there's no longer a shared constant to name.
    //
    // SWITCH: runVersionMigration() re-runs in full on every future version
    // bump, forever — not just the one immediately after 7.0.0 — since it
    // accumulates every historical one-time cleanup in one function rather
    // than tracking "have I already done this specific step" separately.
    // Without this guard, the dnr.getDynamicRules() call below would fire
    // uselessly on every single upgrade this extension ever ships from now
    // on, even for installs many versions past 7.0.0 that cleaned up long
    // ago. blockSuspiciousHosting was a schema default (present — true or
    // false — on every pre-7.0.0 install, whether the feature was ever
    // switched on or not), so its continued presence reliably tells us
    // whether this specific install has been through this cleanup yet;
    // once the delete below runs, the key is gone from storage and this
    // whole block is skipped on every subsequent version bump for good.
    const hasLegacySuspiciousHostingState =
        ( 'blockSuspiciousHosting' in securityConfig ) ||
        ( 'autoApplyPrivacyExtras' in securityConfig ) ||
        ( 'blockSuspiciousHosting' in securityAllowlist );

    if ( hasLegacySuspiciousHostingState ) {
        const RETIRED_SUSPICIOUS_HOSTING_RULE_IDS = [ 6_005_000, 6_005_001 ];
        let retiredSettingsChanged = false;
        if ( 'blockSuspiciousHosting' in securityConfig || 'autoApplyPrivacyExtras' in securityConfig ) {
            delete securityConfig.blockSuspiciousHosting;
            delete securityConfig.autoApplyPrivacyExtras;
            retiredSettingsChanged = true;
        }
        if ( retiredSettingsChanged ) {
            await saveSecurityConfig();
        }
        if ( 'blockSuspiciousHosting' in securityAllowlist ) {
            delete securityAllowlist.blockSuspiciousHosting;
            await saveSecurityAllowlist();
        }
        await localRemove('suspiciousHostingDomains');
        const retiredHostingRules = await dnr.getDynamicRules({
            ruleIds: RETIRED_SUSPICIOUS_HOSTING_RULE_IDS,
        });
        if ( retiredHostingRules.length !== 0 ) {
            await dnr.updateDynamicRules({
                removeRuleIds: retiredHostingRules.map(rule => rule.id),
            }).catch(reason => {
                console.error(`[uBlock-Dynamic] runVersionMigration/retired-suspicious-hosting/${reason}`);
            });
        }
    }

    // One-time rename (uBlock-Stripped-Dynamic fork): blockPunycodeLinks
    // was replaced by the broader blockSuspicious3pLinks (punycode OR
    // IP-literal host OR non-standard explicit port, third-party scoped
    // only — was all-origin before). Carries the user's existing on/off
    // preference forward rather than silently resetting it to the new
    // default (false), same reasoning as every other migration in this
    // function — a toggle a user deliberately enabled shouldn't quietly
    // turn itself off on upgrade just because the underlying key was
    // renamed and broadened.
    if ( 'blockPunycodeLinks' in securityConfig ) {
        securityConfig.blockSuspicious3pLinks = securityConfig.blockPunycodeLinks;
        delete securityConfig.blockPunycodeLinks;
        await saveSecurityConfig();
    }
    if ( 'blockPunycodeLinks' in securityAllowlist ) {
        // Only carry the allowlist forward if it's not just the default
        // GOV_DOMAIN_ALLOWLIST value (which blockSuspicious3pLinks already
        // gets from config.js's own default) — avoids doubling it up.
        const oldList = securityAllowlist.blockPunycodeLinks;
        delete securityAllowlist.blockPunycodeLinks;
        if ( oldList && oldList !== GOV_DOMAIN_ALLOWLIST ) {
            securityAllowlist.blockSuspicious3pLinks = oldList;
        }
        await saveSecurityAllowlist();
    }

    // One-time fold (uBlock-Stripped-Dynamic fork): "Block 3P DDNS & Free
    // hosting" (blockDdnsFreeHosting) was its own separate toggle briefly
    // (0.2–0.7.x) before being folded into "Block suspicious 3P-links" as
    // a 4th pattern (see securityConfig's own comment in config.js for
    // why). Same "carry the user's on/off preference forward" reasoning
    // as the punycode-rename migration above: if EITHER of the two old
    // toggles was on, the combined toggle should end up on too — someone
    // who deliberately enabled DDNS blocking shouldn't have that
    // protection silently vanish just because it moved under a different
    // checkbox they may not have separately enabled.
    if ( 'blockDdnsFreeHosting' in securityConfig ) {
        if ( securityConfig.blockDdnsFreeHosting ) {
            securityConfig.blockSuspicious3pLinks = true;
        }
        delete securityConfig.blockDdnsFreeHosting;
        await saveSecurityConfig();
    }
    if ( 'blockDdnsFreeHosting' in securityAllowlist ) {
        delete securityAllowlist.blockDdnsFreeHosting;
        await saveSecurityAllowlist();
    }

    // One-time cleanup (uBlock-Stripped-Dynamic fork): the standalone "DDG
    // Tracker Radar" Block Monitor feature was removed — superseded by the
    // Matrix panel (see dnr-budgets.js's header and js/core/matrix-panel.js).
    // Same guard shape as the retired-suspicious-hosting block above:
    // presence of the old storage key is what tells us this install still
    // has leftover state to clean up, not a version-number comparison.
    const hasLegacyMonitorState = (await localRead('monitorBlockRules')) !== undefined;
    if ( hasLegacyMonitorState ) {
        await localRemove('monitorBlockRules');
        const retiredMonitorRuleIds = [];
        for ( let i = 0; i < MONITOR_RULES_RETIRED_MAX_DNR; i++ ) {
            retiredMonitorRuleIds.push(MONITOR_RULES_RETIRED_BASE_ID + i);
        }
        const retiredMonitorRules = await dnr.getDynamicRules({
            ruleIds: retiredMonitorRuleIds,
        });
        if ( retiredMonitorRules.length !== 0 ) {
            await dnr.updateDynamicRules({
                removeRuleIds: retiredMonitorRules.map(rule => rule.id),
            }).catch(reason => {
                console.error(`[uBlock-Dynamic] runVersionMigration/retired-monitor/${reason}`);
            });
        }
    }

    // One-time cleanup (uBlock-Stripped-Dynamic fork): Global Privacy
    // Control was removed as a feature — see dnr-budgets.js's retired-
    // range note for 12 000 000 and CHANGELOG for the full history. Same
    // presence-based guard shape as the retired-suspicious-hosting block
    // above: `enableGPC` being present in securityConfig at all — true or
    // false — is what tells us this install predates the removal and
    // still needs cleanup, not a version-number comparison. (Unlike the
    // Monitor cleanup above, there's no dedicated storage key for this
    // one — enableGPC always lived inside the general securityConfig
    // object, never its own key — so the guard checks for the stray
    // property directly instead.)
    const hasLegacyGPCState = 'enableGPC' in securityConfig;
    if ( hasLegacyGPCState ) {
        delete securityConfig.enableGPC;
        await saveSecurityConfig();
        const retiredGPCRuleIds = [];
        for ( let i = 0; i < GPC_RULES_RETIRED_MAX_DNR; i++ ) {
            retiredGPCRuleIds.push(GPC_RULES_RETIRED_BASE_ID + i);
        }
        const retiredGPCRules = await dnr.getDynamicRules({
            ruleIds: retiredGPCRuleIds,
        });
        if ( retiredGPCRules.length !== 0 ) {
            await dnr.updateDynamicRules({
                removeRuleIds: retiredGPCRules.map(rule => rule.id),
            }).catch(reason => {
                console.error(`[uBlock-Dynamic] runVersionMigration/retired-gpc/${reason}`);
            });
        }
    }

    // One-time cleanup (v8.5.7): "Block login-with" was removed as a
    // feature — see dnr-budgets.js's retired-range note for
    // LOGIN_WITH_RULES_RETIRED_BASE_ID and CHANGELOG for the full
    // history. Same presence-based guard shape as the GPC cleanup just
    // above: `blockLoginWith` being present in securityConfig at all —
    // true or false — is what tells us this install predates the
    // removal and still needs cleanup, not a version-number comparison.
    const hasLegacyLoginWithState = 'blockLoginWith' in securityConfig;
    if ( hasLegacyLoginWithState ) {
        delete securityConfig.blockLoginWith;
        await saveSecurityConfig();
        const retiredLoginWithRuleIds = [];
        for ( let i = 0; i < LOGIN_WITH_RULES_RETIRED_MAX_DNR; i++ ) {
            retiredLoginWithRuleIds.push(LOGIN_WITH_RULES_RETIRED_BASE_ID + i);
        }
        const retiredLoginWithRules = await dnr.getDynamicRules({
            ruleIds: retiredLoginWithRuleIds,
        });
        if ( retiredLoginWithRules.length !== 0 ) {
            await dnr.updateDynamicRules({
                removeRuleIds: retiredLoginWithRules.map(rule => rule.id),
            }).catch(reason => {
                console.error(`[uBlock-Dynamic] runVersionMigration/retired-login-with/${reason}`);
            });
        }
    }

    // One-time addition: government-domain default allowlist (see
    // GOV_DOMAIN_ALLOWLIST in config.js for the full rationale/contents).
    // This only needs to run for people who already had a saved
    // securityAllowlist from before this constant existed — a fresh
    // install already gets it as securityAllowlist's default value in
    // config.js, so this step is a no-op there (every entry already
    // contains it, and the guard below skips anything that already does).
    // Appends rather than overwrites, so any hostnames a user already
    // added of their own are kept untouched.
    let allowlistChanged = false;
    for ( const key of Object.keys(securityAllowlist) ) {
        const current = securityAllowlist[key] ?? '';
        if ( current.includes('gov.it') ) { continue; } // already present, guard against re-adding
        securityAllowlist[key] = current
            ? `${current}\n${GOV_DOMAIN_ALLOWLIST}`
            : GOV_DOMAIN_ALLOWLIST;
        allowlistChanged = true;
    }
    if ( allowlistChanged ) {
        await saveSecurityAllowlist();
    }

    // One-time cleanup: remove any already-saved custom scriptlet rule
    // using one of the three confirmed-breaking abort-on-property-read
    // combinations — navigator.maxTouchPoints (broke nos.nl),
    // navigator.deviceMemory (also broke nos.nl), navigator.sendBeacon
    // (broke bnr.nl). Privacy Inspector no longer offers these as a Select
    // mitigation (see CATEGORY_SCRIPTLET_MAP in privacy-inspector.js), but
    // that only stops NEW rules from being created — anyone who already
    // selected one of these, on bnr.nl/nos.nl or any other site, still has
    // a live rule that throws on every page load until removed. Deletes
    // regardless of hostname or source (privacy-inspector, sandbox, or
    // auto-privacy) — none of these three combinations has a legitimate
    // reason to exist as a rule anymore, so there's no "preserve intent"
    // step needed here, unlike the blockWindowName/blockVisibilityChange
    // retirement above.
    const KNOWN_BREAKING_RULE_ARGS = new Set([
        'navigator.maxTouchPoints', 'navigator.deviceMemory', 'navigator.sendBeacon',
    ]);
    const existingRules = await getCustomScriptletRules();
    for ( const rule of existingRules ) {
        if ( rule.name !== 'abort-on-property-read' ) { continue; }
        if ( !KNOWN_BREAKING_RULE_ARGS.has(rule.args?.[0]) ) { continue; }
        await deleteCustomScriptletRule(rule.uid);
    }

    // Clean up any dynamic/session rules left by older versions.
    updateDynamicRules();

    // One-time-per-rule backfill: Manage Custom Rules' "created" date
    // column. Stamps the DATE OF THIS UPDATE onto any existing rule that
    // predates the feature (exactly as requested — there's no way for
    // this code to know a rule's actual original creation date, so the
    // update date is the honest answer, not a fabricated earlier one).
    // Each function already skips any entry that already has a valid
    // date, so — unlike the retirement/rename migrations above, which
    // guard on legacy-key presence specifically to avoid firing forever
    // — these three are already cheap, idempotent no-ops on every future
    // version bump once every rule has been stamped, and don't need a
    // separate guard flag on top of that.
    await backfillMatrixOverrideDates();
    await backfillScriptletRuleDates();
    await backfillCosmeticRuleDates();
    await backfillCookieClickerRuleDates();
}

// Sub-function: (re)register content scripts after a version bump or permission change.
async function syncScriptRegistrations(isNewVersion, permissionsUpdated) {
    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/scripting/RegisteredContentScript#persistacrosssessions
    // "When an extension updates, content scripts are cleared"
    // This includes the sec-* security/privacy scriptlets (WebGL, WebRTC,
    // eval, dialogs, window.name, visibility-change) — without re-asserting
    // registerSecurityContentScripts() here too, any toggle a user had
    // enabled before the update silently stops actually running after the
    // update, even though securityConfig (and the dashboard checkbox) still
    // shows it as enabled, since that's a separate, persisted piece of
    // state from the live browser.scripting registration.
    if ( isNewVersion || permissionsUpdated ) {
        await Promise.all([
            registerContentScripts(),
            registerSecurityContentScripts(),
            updateUserRules(),
        ]);
    }
}

async function startSession() {
    const currentVersion = getCurrentVersion();
    const isNewVersion = currentVersion !== rulesetConfig.version;

    if ( isNewVersion ) {
        swLifecycle.startPhase = 'migration';
        await runVersionMigration(currentVersion);
    }
    // BRAVE VARIANT — the 'locale' startPhase (auto-enabling a language
    // filter on first run) is intentionally removed: no language filters
    // remain in this variant. See static-rulesets.js's header comment.

    // Permissions may have been removed while the extension was disabled.
    swLifecycle.startPhase = 'permissions';
    const permissionsUpdated = await syncWithBrowserPermissions();

    swLifecycle.startPhase = 'scripts';
    await syncScriptRegistrations(isNewVersion, permissionsUpdated);

    swLifecycle.startPhase = 'finalising';

    // (Tracker Radar's restoreMonitorBlockRules() call removed along with
    // the rest of block-monitor.js — see the import-site comment near the
    // top of this file. The NEW 3P Matrix rules restore themselves via
    // restoreMatrixBlockRules() instead — see Stage 5 below.)
    restoreMatrixBlockRules();

    // Global CRITICAL RESOURCE exemption (BUILTIN_DOMAINS) — bundled/
    // static data, never changes at runtime, so (unlike
    // restoreMatrixBlockRules() above) this never needs re-triggering
    // outside of an SW restart re-running this same startup path.
    updateBuiltinWhitelistRules();

    // Built-in, domain-scoped exceptions for known upstream filter-list
    // miscategorizations (v9.3.0) — same bundled/static-data lifecycle as
    // updateBuiltinWhitelistRules() just above; applies regardless of
    // which default-filter or worry-free checkboxes are on/off. See
    // js/core/builtin-fix-exceptions.js's own header.
    updateBuiltinFixExceptions();

    // Familiar-TLD dynamic allow rules (BRAVE VARIANT — replaces the two
    // former static tldallow rulesets). Dynamic rules persist across a
    // plain SW restart (unlike session rules), so this only needs to run
    // here — a fresh install or version bump, exactly like every other
    // one-time DNR setup call in this function.
    await ensureFamiliarTldRules();

    // Re-apply the user's static-ruleset enable/disable choices — Chrome
    // resets these to the manifest's declared defaults on a version update
    // (see restoreEnabledRulesetsFromStorage()'s own comment for why).
    // startSession() itself only runs on a fresh install or version bump
    // (see start() below), which is exactly when this reset can happen, so
    // no extra isNewVersion check is needed here. Awaited (unlike
    // restoreMatrixBlockRules() above) because registerScriptletContentScripts()
    // and registerCosmeticContentScripts() right below both read the
    // enabled-ruleset set — running them before this resolves would race
    // against Chrome's own updateEnabledRulesets() calls and could register
    // content scripts for the pre-restore (wrong) set.
    await restoreEnabledRulesetsFromStorage();

    // Register pre-compiled scriptlet + cosmetic content scripts for enabled rulesets.
    registerScriptletContentScripts();
    registerCosmeticContentScripts();

    // Register the cookie/consent-clicker content script (a no-op,
    // idempotent unregister when no rules exist yet — see
    // registerCookieClickerContentScriptsImpl()'s own RELEASE guard).
    // Same "always re-assert every startup" reasoning as the two lines
    // just above: registerContentScripts() itself already re-registers
    // this group too (see its own Promise.all), but Chrome clears every
    // registered content script on an extension update (see
    // syncScriptRegistrations()'s own MDN citation above) — this call
    // guarantees a plain same-version SW wakeup (which skips
    // syncScriptRegistrations() entirely) still re-asserts it.
    registerCookieClickerContentScripts();

    // Allow content scripts to read from session storage.
    sessionAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });

    // Apply DNR-based security rules from security config.
    updateSecurityRules();

    // Icon badge count — single source of truth is ruleset-manager.js's
    // applyBadgeCountVisibility() (see that function's own comment —
    // it used to also account for enableGPC before GPC was removed as a
    // feature; now back to a straightforward passthrough of
    // rulesetConfig.showBlockedCount, kept as a real function since a
    // second call site may reasonably exist again in the future).
    applyBadgeCountVisibility();

    swLifecycle.startPhase = null;
}

/******************************************************************************/

async function start() {
    swLifecycle.phase = SW_PHASES.BOOTING;
    await loadRulesetConfig();

    // Always run startSession on a fresh install or version bump.
    // On a plain SW wakeup (same version) skip it — all persisted state is
    // already in place and re-running would needlessly rewrite DNR rules.
    swLifecycle.phase = SW_PHASES.STARTING;
    const isNewVersion = getCurrentVersion() !== rulesetConfig.version;
    if ( process.wakeupRun === false || isNewVersion ) {
        await startSession();
    }

    const scripts = await getRegisteredContentScripts();
    if ( scripts.length === 0 ) {
        await registerContentScripts();
    }

    // Reconcile the Worry-free extra suppression rule against the
    // persisted session state — covers fresh install and version bumps
    // (session rules start empty either way) — see worry-free-extra-
    // manager.js's own header on why this reconciliation exists.
    const autoDenyState = await getAutoDenyState();
    await reconcileWorryFreeExtraSuppressionRule(autoDenyState?.active === true);
    // Same reconciliation, same reasoning, for the strict 3P block rules
    // (v8.4.10) — see worry-free-strict-3p-manager.js's own header.
    await reconcileWorryFreeStrict3pRules(autoDenyState?.active === true);
    // Same reconcile-on-every-SW-wake pattern, third instance — Matrix
    // panel's own blockedDomains/matrixOverridesCache caches (see
    // matrix-panel.js's reconcileMatrixCaches() for the real bug this
    // fixes: a mid-session SW restart silently emptied both, with
    // nothing to rebuild them for the rest of that session). No
    // autoDenyState/isActive parameter needed here — reconcileMatrixCaches()
    // determines "is there anything to reconcile" from Matrix's own
    // session state internally, not an externally-supplied flag.
    await reconcileMatrixCaches();
}

/******************************************************************************/

// https://github.com/uBlockOrigin/uBOL-home/issues/199
// Force a restart of the extension once when an "internal error" occurs

const isFullyInitialized = start().then(( ) => {
    swLifecycle.phase      = SW_PHASES.READY;
    swLifecycle.startPhase = null;
    swLifecycle.errorReason = null;
    localRemove('goodStart');
    return false;
}).catch(reason => {
    swLifecycle.phase       = SW_PHASES.ERROR;
    swLifecycle.errorReason = String(reason);
    console.error(
        `[uBlock-Dynamic] startup failed at startPhase='${swLifecycle.startPhase}':`,
        reason
    );
    swLifecycle.startPhase = null;
    if ( process.wakeupRun ) { return; }
    return localRead('goodStart').then(goodStart => {
        if ( goodStart === false ) {
            localRemove('goodStart');
            return false;
        }
        return localWrite('goodStart', false).then(( ) => true);
    });
}).then(restart => {
    if ( restart !== true ) { return; }
    runtime.reload();
});

runtime.onMessage.addListener((request, sender, callback) => {
    if ( typeof request?.what !== 'string' || request.what.includes(':') ) { return; }
    onMessage(request, sender).then(
        response => callback(response),
        reason => {
            console.error('[uBlock-Dynamic] onMessage rejected:', request?.what, reason);
            callback({ error: String(reason?.message || reason) });
        }
    );
    return true;
});

// userScripts message listener removed in v3.12 (userScripts permission dropped)

browser.permissions.onRemoved.addListener((...args) => {
    isFullyInitialized.then(( ) => {
        onPermissionsChanged('removed', ...args);
    });
});

browser.permissions.onAdded.addListener((...args) => {
    isFullyInitialized.then(( ) => {
        onPermissionsChanged('added', ...args);
    });
});

// Chrome resets a tab's per-tab toolbar icon override whenever that tab
// navigates. Re-apply the correct icon on every navigation directly from
// here, so it never depends on a content script's registration having
// already propagated (which can otherwise race with a fast manual reload).
const lastIconLevelByTab = new Map();

browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if ( changeInfo.status !== 'complete' ) { return; }
    isFullyInitialized.then(( ) => {
        const url = tab.url;
        let hostname;
        try {
            hostname = new URL(url).hostname;
        } catch {
            return;
        }
        // Non-HTTP pages (new tab, chrome://, etc.) are not filterable —
        // show the disabled icon so the user knows the extension is inactive.
        if ( hostname === '' ) {
            setToolbarIconForLevel(tabId, 0);
            return;
        }
        getFilteringMode(hostname).then(level => {
            if ( lastIconLevelByTab.get(tabId) === level ) { return; }
            lastIconLevelByTab.set(tabId, level);
            setToolbarIconForLevel(tabId, level);
        });
    });
});

browser.tabs.onRemoved.addListener(tabId => {
    lastIconLevelByTab.delete(tabId);
});

// Re-apply site-mode scriptlets for the newly-committed hostname on every
// main-frame navigation. (The Tracker Radar monitor's own
// onMonitorCommitted() call, previously piggybacked on this same
// listener, was removed with block-monitor.js — see the import-site
// comment near the top of this file.)
browser.webNavigation.onCommitted.addListener(details => {
    if ( details.frameId !== 0 ) { return; }
    isFullyInitialized.then(async () => {
        try {
            const tab = await browser.tabs.get(details.tabId);
            const hostname = new URL(tab.url).hostname;
            if ( hostname ) {
                const mode = await getSiteMode(hostname);
                await setIconForMode(details.tabId, mode);
            }
        } catch {}
    });
});

// Dispatch custom-rule scriptlets on every committed navigation, main frame
// and subframes alike (matching the security scriptlets' allFrames:true
// convention) — see js/core/custom-scriptlets.js. Kept as its own listener,
// separate from the monitor/site-mode one above, so this feature's own
// failure mode can never affect that one or vice versa.
browser.webNavigation.onCommitted.addListener(details => {
    isFullyInitialized.then(() => {
        try {
            const hostname = new URL(details.url).hostname;
            injectCustomScriptletsForFrame({
                tabId: details.tabId,
                frameId: details.frameId,
                hostname,
            });
        } catch {}
    });
});

// Start the watchdog timer — belt-and-suspenders fallback to force-close
// sessions that the primary setTimeout might have missed (e.g. after a
// brief SW restart that re-initialized with activeSession already set).
// (Tracker Radar's own equivalent watchdog was removed alongside the rest
// of block-monitor.js — see the import-site comment above. The Matrix
// panel's own watchdog takes its place, started alongside Privacy
// Inspector's for the identical reason.)
isFullyInitialized.then(( ) => {
    startPrivacyInspectorWatchdog();
    startMatrixWatchdog();
});

browser.alarms.onAlarm.addListener(alarm => {
    if ( alarm.name !== 'deferredJobs' ) { return; }
    isFullyInitialized.then(( ) => {
        if ( process.wakeupRun === false && process.firstAlarm !== true ) {
            process.firstAlarm = true;
            return resetJobsAlarm();
        }
        processDueJobs(onMessage);
    });
});

// "Buying, booking, banking mode" is meant to last only as long as the
// browsing session it was started in. onStartup fires only on a genuine
// browser launch — never on the routine service-worker sleep/wake cycles
// MV3 triggers constantly within one continuous session — so this is the
// correct, narrow hook for "the browser restarted, end any leftover
// pause immediately" without accidentally cutting a pause short just
// because the SW went idle and woke back up minutes later in the same
// session.
browser.runtime.onStartup.addListener(( ) => {
    isFullyInitialized.then(async ( ) => {
        clearTempDisableOnBrowserStartup();
        // "Delete browser history, cookies and cache (except passwords
        // and site permissions) at start" — same onStartup-only hook,
        // same reasoning as the line above: a genuine browser launch,
        // not a routine SW wakeup. See history-cleaner.js.
        deleteHistoryOnBrowserStartup();
        // Worry-free session — like temp-disable above, meant to last only
        // as long as the browsing session it was started in. A genuine
        // restart ends any leftover session outright (clearAutoDenyOnBrowserStartup()
        // handles storage, the deferred alarm job, content-script
        // unregistration, security rules, AND the suppression rule
        // together — see its own comment in cookie-clicker-autodeny-
        // manager.js for the bug this fixes). The general SW-cold-start/
        // version-bump reconciliation in start() above is unrelated and
        // stays as-is — that path can legitimately see a still-active
        // session (a plain SW wakeup, not a browser restart) and must
        // keep it running.
        // "Enable Worry-free Safe Surfing at browser startup" (v8.5.5) —
        // same onStartup-only hook as every other startup-only preference
        // above, consulted AFTER clearAutoDenyOnBrowserStartup() so this
        // always begins from a genuinely fresh session (correct untilMs,
        // freshly-registered content scripts) rather than reasoning about
        // whatever the pre-restart state happened to be. Passing no
        // explicit duration deliberately falls through to startAutoDeny()'s
        // own AUTO_DENY_DURATION_DEFAULT_MINUTES — whatever the current
        // default is (currently `null`, "until next session"), so this
        // setting doesn't hardcode a duration decision that could drift
        // from the picker's own default.
        //
        // FIX (real bug, reported live): clearAutoDenyOnBrowserStartup()
        // is async and was previously called WITHOUT await — this
        // comment's own stated "consulted AFTER" intent was never
        // actually enforced by the code. Both functions write to the
        // same stored state as their very first step; without this
        // await, they raced, and clearAutoDenyOnBrowserStartup()'s own
        // writeState(null) (behind one extra readState() call) tended to
        // land AFTER startAutoDeny()'s writeState({active:true}),
        // silently reverting it — checkbox on, genuine restart, Worry-
        // free ends up inactive anyway. Awaiting it here is the entire
        // fix; no other logic needed to change.
        await clearAutoDenyOnBrowserStartup();
        if ( securityConfig.startWorryFreeOnBrowserStartup === true ) {
            startAutoDeny();
        }
    });
});

/******************************************************************************/
// Right-click context menu — "Cookie consent clicker" / "Dynamic DNR
// filtering" / "Privacy Inspector" (v8.6.3). Every entry launches the
// exact same tool its matching popup menu item does (see
// popup/popup.js's #gotoCookieClicker, #gotoMatrixPanel,
// #gotoPrivacyInspector) — same handler functions, same target shape —
// so each feature has only ever one real launch path with two entry
// points into it, not a second copy that could drift apart (this
// project's own C21 principle). BRAVE VARIANT — "Cosmetic element
// picker" entry removed along with the feature entirely, per explicit
// request.
//
// contextMenus.create() must be called from onInstalled — Chrome persists
// the menu items themselves across every later service-worker wake/sleep
// cycle, so calling create() again on every wake (e.g. from a general
// startup routine) would throw a duplicate-ID error the second time
// onward. onInstalled fires exactly once per install and once per
// version update — the right, narrow hook for "(re)declare the menu
// structure," mirroring this file's own onStartup listener just above,
// which is the same "once per the right kind of lifecycle event, not
// every SW wake" posture, just for a different event.
//
// The click LISTENER itself, by contrast, is registered unconditionally
// at this file's own top level (not inside onInstalled) — MV3 requires
// every event listener a service worker cares about to be attached
// synchronously on every fresh script evaluation, so a click arriving
// right after a cold SW wake (before onInstalled would ever re-fire) is
// never missed. One listener, one switch statement routing on
// menuItemId — same "single router" convention this file's own message
// dispatch table (see message-routes.js) already follows for messages,
// applied here to context-menu clicks instead (C3).
/******************************************************************************/

// ── CONTEXT_MENU_IDS ─────────────────────────────────────────────────────
// Single declared place for every right-click menu item id this file
// creates, and every item's own title text (kept identical to its sibling
// popup menu item's label — see popup/popup.html — per C22 cross-variant
// consistency: same feature, same label, wherever it's launched from).
// CONTEXT_MENU_ID_PICKER's own string value (not the JS name it was
// previously bound to) is unchanged from v8.5.6 — right-click menu ids
// aren't a stored/messaged contract, but keeping the value stable avoids
// any risk of a stale duplicate entry surviving a service-worker update.
const CONTEXT_MENU_IDS = Object.freeze({
    COOKIE_CLICKER:    'uBolStrippedDynamic.cookieConsentClicker',
    DYNAMIC_FILTERING: 'uBolStrippedDynamic.dynamicDnrFiltering',
    PRIVACY_INSPECTOR: 'uBolStrippedDynamic.privacyInspector',
});

const CONTEXT_MENU_ITEMS = Object.freeze([
    {
        id: CONTEXT_MENU_IDS.COOKIE_CLICKER,
        title: 'Cookie consent clicker',
        contexts: [ 'page', 'frame' ],
    },
    {
        id: CONTEXT_MENU_IDS.DYNAMIC_FILTERING,
        title: 'Dynamic DNR filtering',
        contexts: [ 'page', 'frame' ],
    },
    {
        id: CONTEXT_MENU_IDS.PRIVACY_INSPECTOR,
        title: 'Privacy Inspector',
        contexts: [ 'page', 'frame' ],
    },
]);

browser.runtime.onInstalled.addListener(( ) => {
    isFullyInitialized.then(( ) => {
        // Guard: removeAll() first — an update (not a fresh install) would
        // otherwise hit the same duplicate-ID error create() throws for an
        // already-existing ID; this makes the whole block safely re-runnable
        // on every onInstalled firing, not just the very first one.
        browser.contextMenus.removeAll(( ) => {
            for ( const item of CONTEXT_MENU_ITEMS ) {
                browser.contextMenus.create(item);
            }
        });
    });
});

// Guard: every branch validates `tab.id` before doing anything — a
// context-menu click can theoretically fire without a resolvable tab
// (e.g. certain non-page surfaces), and each handler below needs a real
// tabId either to inject into (picker) or to resolve a hostname from
// (the other three, inside their own handleStart*() functions).
function onContextMenuClicked(info, tab) {
    if ( tab instanceof Object === false || typeof tab.id !== 'number' ) { return; }

    switch ( info.menuItemId ) {
    case CONTEXT_MENU_IDS.COOKIE_CLICKER: {
        // Same one-shot, fire-and-forget shape as popup.js's own
        // #gotoCookieClicker handler: the actual detect/toggle/inject
        // sequence lives in handleCookieClickerLaunchPicker() and keeps
        // running in the service worker regardless of anything on this
        // end, so there is nothing further to await here.
        handleCookieClickerLaunchPicker({ tabId: tab.id });
        break;
    }
    case CONTEXT_MENU_IDS.DYNAMIC_FILTERING: {
        handleStartMatrix({ tabId: tab.id }).then(result => {
            if ( result?.ok !== true ) { return; }
            openOrFocusPanel(browser.runtime.getURL('matrix/matrix-panel.html'));
        });
        break;
    }
    case CONTEXT_MENU_IDS.PRIVACY_INSPECTOR: {
        handleStartPrivacyInspector({ tabId: tab.id }).then(result => {
            if ( result?.ok !== true ) { return; }
            openOrFocusPanel(browser.runtime.getURL('privacy/privacy-inspector.html'));
        });
        break;
    }
    default:
        break;
    }
}
browser.contextMenus.onClicked.addListener(onContextMenuClicked);
