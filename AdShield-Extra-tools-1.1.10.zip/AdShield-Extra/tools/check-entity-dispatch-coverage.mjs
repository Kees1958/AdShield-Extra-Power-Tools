#!/usr/bin/env node
// check-entity-dispatch-coverage.mjs — guards against the bug class
// documented in ARCHITECTURE.md's HARD CONSTRAINT: "every compiled
// hostname dispatch table must account for entity-style (name.*) keys."
// Found and fixed twice independently in this codebase (v9.5.2, ported
// from uBS) — cosmetic (buildCosmeticSpecificData()'s hasEntities flag
// hardcoded false) and scriptlet (buildScriptletFile()'s dispatch loop
// never derived an entity form at all) — two structurally different
// mechanisms, same underlying mistake.
//
// Static check on BUILD OUTPUT, not a runtime simulation: run
// `node tools/build-rulesets.mjs` first (rulesets/ is a build artifact,
// not committed) — a fresh checkout with no rulesets/ present yet is
// reported as skipped, not failed.
//
//   - For every *-cosmetic-specific.json: if any hostname key ends in
//     '.*' (and isn't the bare '*' wildcard itself), hasEntities must be
//     true.
//   - For every *-scriptlets.js: if any dispatch-table key ends in
//     '.*', the generated source must contain the entity-aware dispatch
//     branch (identified by its lastIndexOf('.') probe — see
//     buildScriptletFile()'s own comment in build-rulesets.mjs for the
//     exact generated shape).
//
// Usage: node tools/check-entity-dispatch-coverage.mjs   (also runs as
// step 35 of `npm run check` / tools/complete-check.mjs)

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const ROOT = path.resolve(import.meta.dirname, '..');
const isMainModule = process.argv[1] !== undefined &&
    fileURLToPath(import.meta.url) === path.resolve(process.argv[1]);

const RULESETS_DIR = path.join(ROOT, 'rulesets');
// Identifies the entity-aware branch buildScriptletFile() emits — see
// that function's own comment in build-rulesets.mjs for the exact
// generated text this must match.
const ENTITY_BRANCH_MARKER = 'p.lastIndexOf(".")';

function isEntityHostname(h) {
    return typeof h === 'string' && h.endsWith('.*') && h !== '*';
}

if ( isMainModule ) {
    if ( fs.existsSync(RULESETS_DIR) === false ) {
        console.log('rulesets/ does not exist yet — run `node tools/build-rulesets.mjs` first. Skipping (not a failure on a fresh checkout).');
        process.exit(0);
    }

    let failures = 0;
    let cosmeticChecked = 0;
    let scriptletChecked = 0;

    for ( const file of fs.readdirSync(RULESETS_DIR) ) {
        if ( file.endsWith('-cosmetic-specific.json') ) {
            cosmeticChecked++;
            const data = JSON.parse(fs.readFileSync(path.join(RULESETS_DIR, file), 'utf8'));
            const hostnames = Array.isArray(data?.hostnames) ? data.hostnames : [];
            const hasEntityKey = hostnames.some(isEntityHostname);
            if ( hasEntityKey && data.hasEntities !== true ) {
                failures++;
                console.log(`✗ ${file}: contains an entity-style hostname key (e.g. "${hostnames.find(isEntityHostname)}") but hasEntities is ${JSON.stringify(data.hasEntities)}, not true. It will never match any page.`);
            } else {
                console.log(`✓ ${file}: hasEntities=${data.hasEntities} — ${hasEntityKey ? 'correctly true, entity key(s) present' : 'no entity keys, correctly false/absent'}`);
            }
        }

        if ( file.endsWith('-scriptlets.js') ) {
            scriptletChecked++;
            const text = fs.readFileSync(path.join(RULESETS_DIR, file), 'utf8');
            // Dispatch-table keys look like 'somehost.*':[ ... ] in the
            // generated source — same literal shape buildScriptletFile()
            // emits (see its own comment for the exact format).
            const hasEntityKey = /'[^']*\.\*':/.test(text);
            const hasEntityBranch = text.includes(ENTITY_BRANCH_MARKER);
            if ( hasEntityKey && hasEntityBranch === false ) {
                failures++;
                console.log(`✗ ${file}: contains an entity-style dispatch key but the generated dispatch loop has no entity-aware branch. It will never match any page.`);
            } else {
                console.log(`✓ ${file}: ${hasEntityKey ? 'entity key(s) present, entity-aware branch confirmed in generated code' : 'no entity keys in this dispatch table'}`);
            }
        }
    }

    console.log(`\nChecked ${cosmeticChecked} cosmetic-specific file(s), ${scriptletChecked} scriptlet dispatch file(s).`);
    if ( failures > 0 ) {
        console.log(`\n${failures} entity-dispatch coverage failure(s) — do not zip until resolved.`);
        process.exit(1);
    }
    console.log('\nAll compiled hostname dispatch tables correctly account for entity-style keys.');
    process.exit(0);
}
