// Behavioral proof for v9.5.4 porting item 1's correction: block and
// allow rules must get IDENTICAL $domain=example.* wildcard-expansion
// treatment — an earlier version (v9.5.2) dropped block-rule wildcard
// tokens unconditionally while validating allow-rule ones against
// top-1M data. Guards against silently regressing back to that
// asymmetric design.
//
// tools/build-rulesets.mjs runs its whole build unconditionally at
// import (network fetches, file writes — no isMainModule guard), so
// this test can't safely `import` it directly. Instead it extracts just
// resolveWildcardDomainTokens() and WILDCARD_EXPANSION_TLD_CANDIDATES'
// source text and evaluates them in isolation — the same technique used
// to verify this fix by hand before writing this permanent test.
import assert from 'assert';
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');

console.log('=== e2e: $domain=example.* wildcard resolution — block/allow symmetry ===\n');

let failures = 0;
function check(name, cond) {
    if ( cond ) { console.log(`  PASS: ${name}`); }
    else { failures++; console.log(`  FAIL: ${name}`); }
}

const src = fs.readFileSync(path.join(ROOT, 'tools/build-rulesets.mjs'), 'utf8');

const constStart = src.indexOf('const WILDCARD_EXPANSION_TLD_CANDIDATES');
const fnStart = src.indexOf('function resolveWildcardDomainTokens');
if ( constStart === -1 || fnStart === -1 ) {
    throw new Error('Could not locate expected markers (WILDCARD_EXPANSION_TLD_CANDIDATES / resolveWildcardDomainTokens) — build-rulesets.mjs may have been restructured; update this test\'s extraction points.');
}
const constEnd = src.indexOf('];', constStart) + 2;
const fnEnd = src.indexOf('\n}\n', fnStart) + 3;
const constCode = src.slice(constStart, constEnd);
const fnCode = src.slice(fnStart, fnEnd);

const buildResolver = new Function(
    'droppedWildcardDomains', 'expandedWildcardDomains',
    `${constCode}\n${fnCode}\nreturn { resolveWildcardDomainTokens, WILDCARD_EXPANSION_TLD_CANDIDATES };`
);

const dropped = [];
const expanded = [];
const { resolveWildcardDomainTokens, WILDCARD_EXPANSION_TLD_CANDIDATES } = buildResolver(dropped, expanded);

check('WILDCARD_EXPANSION_TLD_CANDIDATES is a non-empty array', Array.isArray(WILDCARD_EXPANSION_TLD_CANDIDATES) && WILDCARD_EXPANSION_TLD_CANDIDATES.length > 0);

// A candidate confirmed in a mock top-1M set.
const topSitesConfirmed = new Set([ 'teststie.com' ]);
const blockConfirmed = resolveWildcardDomainTokens('teststie', { isException: false, topSites: topSitesConfirmed, listName: 'test', line: 'block-line' });
const allowConfirmed = resolveWildcardDomainTokens('teststie', { isException: true, topSites: topSitesConfirmed, listName: 'test', line: 'allow-line' });

check('block rule with a confirmed candidate EXPANDS (not unconditionally dropped)', blockConfirmed.length > 0);
check('block and allow rules produce IDENTICAL expansion for the same confirmed candidate', JSON.stringify(blockConfirmed) === JSON.stringify(allowConfirmed));
check('the confirmed expansion is the expected concrete domain', blockConfirmed.includes('teststie.com'));

// No candidate confirmed anywhere — both rule types must drop identically.
const topSitesEmpty = new Set();
const blockUnconfirmed = resolveWildcardDomainTokens('nosuchsite', { isException: false, topSites: topSitesEmpty, listName: 'test', line: 'block-line-2' });
const allowUnconfirmed = resolveWildcardDomainTokens('nosuchsite', { isException: true, topSites: topSitesEmpty, listName: 'test', line: 'allow-line-2' });

check('block rule with no confirmed candidate drops to empty', blockUnconfirmed.length === 0);
check('block and allow rules produce IDENTICAL (empty) result when nothing confirms', JSON.stringify(blockUnconfirmed) === JSON.stringify(allowUnconfirmed));

// Registrable-domain reduction: a multi-label base's own last label is
// what gets checked, not the literal full base.
const topSitesRegistrable = new Set([ 'amazon.com' ]);
const multiLabelResult = resolveWildcardDomainTokens('read.amazon', { isException: true, topSites: topSitesRegistrable, listName: 'test', line: 'allow-line-3' });
check('registrable-domain reduction: "read.amazon" checks "amazon.com", not literal "read.amazon.com"', multiLabelResult.includes('read.amazon.com'));

// Report accumulators actually recorded both cases, with distinguishable rule-kind wording.
check('dropped-report entries exist for both block and allow drops', dropped.length === 2);
check('expanded-report entries exist for both block and allow expansions', expanded.length === 3);
check('expanded-report entries tag rule kind (block vs allow) distinctly', new Set(expanded.map(e => e.ruleKind)).size === 2);

console.log(`\n${failures === 0 ? 'PASS' : 'FAIL'}: e2e wildcard-domain block/allow symmetry check (${failures} failure(s))`);
process.exit(failures === 0 ? 0 : 1);
