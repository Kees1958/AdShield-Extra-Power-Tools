#!/usr/bin/env node
// check-scripting-batch-calls.mjs — guards against the regression this
// project's own v9.5.1 porting note (item 2) describes: a per-directive
// loop calling browser.scripting.registerContentScripts([directive]) /
// .updateContentScripts([directive]) once per item, instead of batching
// the whole array into one call each via the shared
// registerOrUpdateContentScripts() helper in js/core/scripting-manager.js.
//
// This is a static, heuristic scan: it flags any registerContentScripts()/
// updateContentScripts() call whose argument is a single-identifier array
// literal — `[ someVariable ]` — outside the one file/function that's
// allowed to make calls in that exact shape (registerOrUpdateContentScripts()
// itself, which legitimately falls back to one-call-per-directive as an
// atomic-rejection safety net — see that function's own comment) and the
// three known single-directive groups (cookie-clicker, autodeny, css-user
// registration — each of these only EVER has one directive to register in
// the first place, so a single-item array there was never the bug this
// check guards against, and batching it would be meaningless).
//
// Usage: node tools/check-scripting-batch-calls.mjs   (also runs as
// step 34 of `npm run check` / tools/complete-check.mjs)

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const ROOT = path.resolve(import.meta.dirname, '..');
const isMainModule = process.argv[1] !== undefined &&
    fileURLToPath(import.meta.url) === path.resolve(process.argv[1]);

// Matches a single-identifier array literal argument: `[ foo ]`, not
// `[ ...toRegister ]` or a bare array variable — deliberately narrow, so
// it only catches the exact "one call per directive" shape, not every
// call that happens to pass a short array.
const SINGLE_ITEM_CALL_RE = /\b(?:browser|chrome)\.scripting\.(registerContentScripts|updateContentScripts)\s*\(\s*\[\s*[A-Za-z0-9_$]+\s*\]\s*\)/;

// file (relative to ROOT) -> Set<enclosingFunctionName> allowed to make
// single-item calls in this shape.
const ALLOWLIST = new Map([
    [ 'js/core/scripting-manager.js', new Set([
        // The shared batching helper's own atomic-rejection fallback —
        // see its header comment. Deliberately per-directive here: this
        // is the safety net for when the batched call itself fails.
        'registerOrUpdateContentScripts',
        // Single-directive groups — each of these only EVER has one
        // directive to register, so there is no "N calls instead of 1"
        // cost to fix here; batching a single item is a no-op by
        // definition.
        'registerCookieClickerContentScriptsImpl',
        'registerCookieClickerAutoDenyContentScriptsImpl',
        'registerCustomFiltersDirective',
    ]) ],
]);

const FUNC_DECL_RE = /(?:^|\s)(?:export\s+)?(?:async\s+)?function\s+([A-Za-z0-9_$]+)\s*\(/;

function enclosingFunctionName(lines, callLineIndex) {
    for ( let i = callLineIndex; i >= 0; i-- ) {
        const m = FUNC_DECL_RE.exec(lines[i]);
        if ( m ) { return m[1]; }
    }
    return null;
}

function listFiles(dir, skipDirNames) {
    const out = [];
    for ( const entry of fs.readdirSync(dir, { withFileTypes: true }) ) {
        if ( skipDirNames.includes(entry.name) ) { continue; }
        const full = path.join(dir, entry.name);
        if ( entry.isDirectory() ) { out.push(...listFiles(full, skipDirNames)); }
        else if ( entry.name.endsWith('.js') ) { out.push(full); }
    }
    return out;
}

if ( isMainModule ) {
    const jsDir = path.join(ROOT, 'js');
    const files = listFiles(jsDir, [ 'lib', 'generated' ]);

    let failures = 0;
    let scanned = 0;

    for ( const file of files ) {
        const relPath = path.relative(ROOT, file).split(path.sep).join('/');
        const text = fs.readFileSync(file, 'utf8');
        const lines = text.split('\n');
        lines.forEach((line, i) => {
            const trimmed = line.trim();
            if ( trimmed.startsWith('//') || trimmed.startsWith('*') || trimmed.startsWith('/*') ) { return; }
            if ( SINGLE_ITEM_CALL_RE.test(line) === false ) { return; }
            scanned++;
            const func = enclosingFunctionName(lines, i);
            const allowedFuncs = ALLOWLIST.get(relPath);
            if ( func !== null && allowedFuncs?.has(func) ) { return; }
            failures++;
            console.log(`✗ ${relPath}:${i + 1} — inside function "${func ?? '(unknown)'}"`);
            console.log(`    ${trimmed}`);
            console.log(`    Single-directive registerContentScripts()/updateContentScripts() call outside the allowlist.`);
            console.log(`    If this is a genuine new single-directive group, add its function name to ALLOWLIST in this file.`);
            console.log(`    If this is a loop over multiple directives, route it through registerOrUpdateContentScripts() instead.`);
        });
    }

    console.log(`\nScanned ${files.length} files under js/ — found ${scanned} single-directive registerContentScripts()/updateContentScripts() call site(s), ${failures} not allowlisted.`);
    if ( failures > 0 ) {
        console.log(`\n${failures} unbatched call site(s) — do not zip until resolved.`);
        process.exit(1);
    }
    console.log('\nAll registerContentScripts()/updateContentScripts() calls are either batched or allowlisted single-directive groups.');
    process.exit(0);
}
