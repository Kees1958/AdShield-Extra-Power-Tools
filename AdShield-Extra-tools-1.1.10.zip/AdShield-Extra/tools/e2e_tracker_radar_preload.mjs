// Behavioral proof for v9.4.9 porting item 2 (Tracker Radar dataset:
// load once at session start, not on every SW cold start). Exercises
// the real exported functions from tracker-radar-lookup.js — not just
// "does it parse" — and asserts on real output at each stage:
//   - lookupTracker() must never throw and must return null before any
//     preload has resolved (the safe-degrade requirement)
//   - preloadTrackerRadarData() must actually load real data once
//     awaited
//   - a second preloadTrackerRadarData() call in the same lifetime must
//     reuse the cached promise, not re-import
//   - resetTrackerRadarCache() must drop both the built Map and the
//     cached promise, so a subsequent preload starts fresh
import assert from 'assert';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');

console.log('=== e2e: tracker-radar-lookup.js preload/lookup behavior ===\n');

let failures = 0;
function check(name, cond) {
    if ( cond ) { console.log(`  PASS: ${name}`); }
    else { failures++; console.log(`  FAIL: ${name}`); }
}

const modUrl = `file://${path.join(ROOT, 'js/core/tracker-radar-lookup.js')}?t=${Date.now()}`;
const { lookupTracker, preloadTrackerRadarData, resetTrackerRadarCache } = await import(modUrl);

// Before any preload call: must not throw, must return null.
let threwBeforePreload = null;
let before;
try {
    before = lookupTracker('google.com');
} catch (err) {
    threwBeforePreload = err;
}
check('lookupTracker() does not throw before any preload call', threwBeforePreload === null);
check('lookupTracker() returns null before any preload call (safe degrade)', before === null);

// Kick off preload — check it's still safe mid-flight (before this
// synchronous check yields to the microtask queue, the dynamic import
// cannot have resolved yet).
const preloadPromise = preloadTrackerRadarData();
let midFlight;
let threwMidFlight = null;
try {
    midFlight = lookupTracker('google.com');
} catch (err) {
    threwMidFlight = err;
}
check('lookupTracker() does not throw mid-flight (preload in progress)', threwMidFlight === null);
check('lookupTracker() still returns null mid-flight (preload not yet resolved)', midFlight === null);

await preloadPromise;

const after = lookupTracker('google.com');
check('lookupTracker() returns real data after preload resolves (known domain)', after !== null && typeof after === 'object');
check('resolved data has the expected shape', after && 'owner' in after && 'onPGL' in after && 'fingerprinting' in after);

const unknown = lookupTracker('this-domain-does-not-exist-in-the-dataset.invalid');
check('lookupTracker() returns null for a domain genuinely not in the dataset', unknown === null);

const secondPromise = preloadTrackerRadarData();
check('a second preloadTrackerRadarData() call reuses the cached promise (no re-import)', secondPromise === preloadPromise);

resetTrackerRadarCache();
const afterReset = lookupTracker('google.com');
check('lookupTracker() returns null again after resetTrackerRadarCache()', afterReset === null);

const thirdPromise = preloadTrackerRadarData();
check('preloadTrackerRadarData() after a reset returns a NEW promise, not the old cached one', thirdPromise !== preloadPromise);
await thirdPromise;
check('lookup works again after a post-reset preload', lookupTracker('google.com') !== null);

console.log(`\n${failures === 0 ? 'PASS' : 'FAIL'}: e2e tracker-radar preload check (${failures} failure(s))`);
process.exit(failures === 0 ? 0 : 1);
