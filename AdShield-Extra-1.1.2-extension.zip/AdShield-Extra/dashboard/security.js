/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

*******************************************************************************/

import { dom, qsa$ } from '../js/ui/dom.js';
import { sendMessage, localRead, localWrite } from '../js/data/ext.js';

/******************************************************************************/
// GATE_KEY — persisted via chrome.storage.local (localRead()/localWrite(),
// this project's single storage layer — see C4 in the programming-
// principles audit) rather than window.localStorage.
//
// Real bug fixed here (9.2.3): this checkbox was the one holdout on the
// entire Security & Privacy panel still using raw window.localStorage —
// every sibling setting (securityConfig/securityAllowlist) already went
// through chrome.storage.local. window.localStorage is a separate,
// browser-managed storage partition from chrome.storage.local; MDN's own
// storage.local docs explicitly advise against using window.localStorage
// in extension code for exactly this kind of divergence. Reported as
// "the Security & Privacy panel state isn't remembered after updates".
const GATE_KEY = 'ubol.advancedUserUnlocked';

// One-time-only migration: pre-9.2.3 installs stored this same boolean
// under this same key name in window.localStorage instead. Read it
// forward exactly once — see loadGateState() below — so an existing
// "advanced user" unlock isn't silently lost by this migration itself
// (same "carry the user's preference forward" convention
// runVersionMigration() uses in background.js for securityConfig keys).
const LEGACY_LOCALSTORAGE_GATE_KEY = GATE_KEY;

const section  = document.querySelector('section[data-pane="security"]');
const gateBox  = document.querySelector('#advancedUserCheck');

// Grey out all options until the user confirms the gate checkbox (label
// text — see dashboard.html's #advancedUserGateLabel — acknowledges the
// extra protections below could affect a sketchy site, not "advanced
// user" status specifically; renamed in v8.3.11, this function/variable
// naming kept unchanged since nothing about the underlying mechanism
// changed).
function applyGateState(unlocked) {
    if ( unlocked ) {
        section.classList.remove('security-locked');
    } else {
        section.classList.add('security-locked');
    }
}

// WARNING FOR IMPLEMENTATION IMPACT: reading the gate's state is now
// async (chrome.storage.local, not a synchronous localStorage.getItem()
// call), so dashboard.html now ships with the section already
// class="security-locked" by default (fail-safe) instead of relying on
// this script to lock it before first paint. If this read is slow, the
// visible effect is the section staying greyed-out slightly longer on
// page load, never a moment where it's unexpectedly interactive.
async function loadGateState() {
    let unlocked = await localRead(GATE_KEY);
    if ( unlocked === undefined ) {
        const legacy = window.localStorage.getItem(LEGACY_LOCALSTORAGE_GATE_KEY);
        if ( legacy !== null ) {
            unlocked = legacy === 'true';
            await localWrite(GATE_KEY, unlocked);
        } else {
            unlocked = false;
        }
        // RELEASE — drop the old copy once migrated forward so it can't
        // linger as a stale, unread duplicate of the real value.
        window.localStorage.removeItem(LEGACY_LOCALSTORAGE_GATE_KEY);
    }
    gateBox.checked = unlocked === true;
    applyGateState(unlocked === true);
}

loadGateState();

dom.on('#advancedUserCheck', 'change', async ev => {
    const unlocked = ev.target.checked;
    await localWrite(GATE_KEY, unlocked);
    applyGateState(unlocked);
    // Checking the gate box (label text updated in v8.3.11 — see
    // dashboard.html's #advancedUserGateLabel) now also enables every
    // protection by default, not just unlocks the ability to check them
    // one at a time — every toggle here is deliberately low-breakage-risk
    // (see CHANGELOG), so requiring a second pass of individual clicks
    // after confirming added friction without adding safety.
    // Unchecking the gate only re-locks the UI; it does NOT revert any
    // toggle back off, since that could silently disable protections the
    // user is now relying on — same asymmetry as the rest of this project's
    // "never silently undo a user's own choice" convention.
    if ( unlocked ) {
        await enableAllProtections();
    }
});

/******************************************************************************/
// Bulk-enable — see the gate's change handler above for the rationale.

async function enableAllProtections() {
    // Scoped to #security-columns specifically, NOT the whole
    // section[data-pane="security"] — #deleteHistoryGate's checkbox lives
    // outside #security-columns precisely so it isn't swept into this
    // bulk-enable: history deletion carries a completely different risk
    // (irreversible loss of the user's own data, not "might break a
    // site") — it shouldn't be silently turned on just because the user
    // confirmed understanding of resource-blocking risk specifically.
    // (Previously also mentioned #gpcGate here for the same reason —
    // Global Privacy Control was removed as a feature, see CHANGELOG.)
    // See dashboard.html's own comment on the remaining gate's placement.
    const inputs = qsa$('#security-columns input[type="checkbox"][data-setting]');
    for ( const input of inputs ) {
        if ( input.checked ) { continue; } // already on — don't re-send/re-flicker it
        input.checked = true;
        input.disabled = true;
        try {
            await sendMessage({ what: 'setSecurityConfig', key: input.dataset.setting, value: true });
        } finally {
            input.disabled = false;
        }
    }
}

/******************************************************************************/
// Load current security config and reflect in the UI checkboxes.

async function renderSecurityConfig() {
    const config = await sendMessage({ what: 'getSecurityConfig' });
    if ( !config ) { return; }
    for ( const input of qsa$('section[data-pane="security"] input[data-setting]') ) {
        const key = input.dataset.setting;
        if ( Object.hasOwn(config, key) ) {
            input.checked = config[key];
        }
    }
}

/******************************************************************************/
// Handle toggle changes.

dom.on(
    'section[data-pane="security"]',
    'change',
    'input[type="checkbox"][data-setting]',
    async ev => {
        const input = ev.target;
        const key = input.dataset.setting;
        const value = input.checked;
        input.disabled = true;
        try {
            await sendMessage({ what: 'setSecurityConfig', key, value });
        } finally {
            input.disabled = false;
        }
    }
);

/******************************************************************************/

renderSecurityConfig();

/******************************************************************************/
